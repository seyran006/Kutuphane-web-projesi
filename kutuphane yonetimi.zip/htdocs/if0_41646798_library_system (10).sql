-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql113.infinityfree.com
-- Generation Time: May 04, 2026 at 05:45 PM
-- Server version: 11.4.10-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_41646798_library_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `name`) VALUES
(127, 'Ahmet Hamdi Tanpınar'),
(148, 'Ahmet Mithat Efendi'),
(85, 'Alberto Moravia'),
(124, 'Aleksandr Puşkin'),
(89, 'Alessandro Baricco'),
(75, 'Alessandro Manzoni'),
(105, 'Ali Şeriati'),
(60, 'Anthony Burgess'),
(123, 'Anton Çehov'),
(41, 'Antonio Machado'),
(37, 'Antonio Munoz Molina'),
(35, 'Arturo Perez-Reverte'),
(22, 'Ashlee Vance'),
(66, 'Aurelius Augustinus'),
(40, 'Benito Perez Galdos'),
(42, 'Camilo Jose Cela'),
(76, 'Carlo Collodi'),
(31, 'Carlos Ruiz Zafon'),
(30, 'Carmen Laforet'),
(88, 'Cesare Pavese'),
(50, 'Charles Dickens'),
(48, 'Charlotte Brontë'),
(70, 'D. Brendan Nagle'),
(57, 'Daniel Defoe'),
(73, 'Dante Alighieri'),
(106, 'Devletabadi'),
(95, 'Dino Buzzati'),
(58, 'Doris Lessing'),
(36, 'Eduardo Mendoza'),
(79, 'Elena Ferrante'),
(47, 'Emily Brontë'),
(29, 'Federico Garcıa Lorca'),
(108, 'Feridüddin Attar'),
(98, 'Firdevsi'),
(72, 'Frederic M. Wheelock'),
(115, 'Fyodor Dostoyevski'),
(67, 'Gaius Petronius'),
(68, 'Gaius Plinius Secundus'),
(64, 'Geoffrey Chaucer'),
(45, 'George Orwell'),
(71, 'Gilbert Lawall'),
(74, 'Giovanni Boccaccio'),
(78, 'Giuseppe Tomasi di Lampedusa'),
(104, 'Gulam Hüseyin Sadi'),
(101, 'Hafız-ı Şirazi'),
(134, 'Haldun Taner'),
(140, 'Halide Edib Adıvar'),
(145, 'Halit Ziya Uşaklıgil'),
(80, 'Italo Calvino'),
(87, 'Italo Svevo'),
(117, 'İvan Turgenyev'),
(44, 'Jane Austen'),
(34, 'Javier Marıas'),
(56, 'Jonathan Swift'),
(32, 'Juan Ramon Jimenez'),
(49, 'Julius Caesar'),
(59, 'Juvenalis'),
(39, 'Leopoldo Alas'),
(116, 'Lev Tolstoy'),
(61, 'Lucius Annaeus Seneca'),
(63, 'Lucius Apuleius Madaurensis'),
(84, 'Luigi Pirandello'),
(96, 'Magtymguly Pyragy'),
(62, 'Marcus Tullius Cicero'),
(51, 'Mary Shelley'),
(128, 'Mehmet Akif Ersoy'),
(146, 'Mehmet Rauf'),
(99, 'Mevlana Celaleddin Rumi'),
(69, 'Michael Grant'),
(27, 'Michael J. Saylor'),
(28, 'Miguel de Cervantes'),
(38, 'Miguel Delibes'),
(119, 'Mihail Bulgakov'),
(129, 'Mustafa Kemal Atatürk'),
(137, 'Namık Kemal'),
(138, 'Necip Fazıl Kısakürek'),
(93, 'Niccolò Ammaniti'),
(118, 'Nikolay Gogol'),
(111, 'Nizami Gencevi'),
(110, 'Nizamî-i Gencevî'),
(112, 'Nizamülmülk'),
(126, 'Oğuz Atay'),
(151, 'Orhan Kemal'),
(150, 'Orhan Pamuk'),
(132, 'Orhan Veli Kanık'),
(55, 'Oscar Wilde'),
(46, 'Ovid'),
(107, 'Parinoush Saniee'),
(54, 'Publius Cornelius Tacitus'),
(26, 'Ray Kurzweil'),
(147, 'Recaizade Mahmut Ekrem'),
(139, 'Refik Halit Karay'),
(113, 'Rukiye Kebiri'),
(141, 'Sabahattin Ali'),
(100, 'Sadi-i Şirazi'),
(97, 'Sadık Hidayet'),
(109, 'Samed Behrengi'),
(136, 'Samipaşazade Sezai'),
(102, 'Şehrezuri'),
(114, 'Şehrnuş Parsipur'),
(103, 'Simin Danişver'),
(24, 'Stuart Russell & Peter Norvig'),
(52, 'Titus Livius'),
(131, 'Turgut Özakman'),
(77, 'Umberto Eco'),
(43, 'Virgil'),
(21, 'Walter Isaacson'),
(65, 'William Shakespeare'),
(133, 'Yahya Kemal Beyatlı'),
(125, 'Yaşar Kemal'),
(122, 'Yevgeni Zamyatin'),
(149, 'Yusuf Atılgan'),
(23, 'Yuval Noah Harari');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(180) NOT NULL,
  `author_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `isbn` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `image_path` varchar(255) DEFAULT NULL,
  `total_copies` int(11) NOT NULL DEFAULT 1,
  `available_copies` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author_id`, `category_id`, `isbn`, `description`, `summary`, `price`, `image_path`, `total_copies`, `available_copies`, `created_at`) VALUES
(204, 'Geleceği Keşfedenler', 21, 11, '9786053436156', 'Bilgisayarın ve internetin doğuşunu anlatan, teknoloji tarihine yön veren insanların hikayesi.', NULL, '25.00', 'assets/uploads/book_69e15bf8206323.76855402.png', 3, 3, '2026-04-16 22:00:01'),
(205, 'Elon Musk: Tesla, SpaceX ve Muhteşem Geleceğin Peşinde', 22, 11, '9789750521506', 'Elon Musk’ın teknoloji dünyasını nasıl değiştirdiğini anlatan popüler biyografi.', NULL, '30.00', 'assets/uploads/book_69e15c9aa55976.49517473.png', 4, 4, '2026-04-16 22:02:51'),
(206, 'Homo Deus: Yarının Kısa Bir Tarihi', 23, 12, '9786056665355', 'Yapay zeka ve veri çağında insanlığın geleceğini sorgulayan çok popüler bir kitap.', NULL, '28.00', 'assets/uploads/book_69e15d21695f66.36113475.png', 5, 5, '2026-04-16 22:04:35'),
(207, 'Yapay Zeka: Modern Bir Yaklaşım', 24, 13, '9780136042593', 'Yapay zeka alanında en kapsamlı ve dünyaca ünlü akademik kaynaklardan biri.', NULL, '35.00', 'assets/uploads/book_69e15dedaf9b94.03882844.png', 2, 2, '2026-04-16 22:06:30'),
(208, 'The Singularity is Near', 26, 12, '9780143037880', 'Teknolojinin insan zekasını aşacağı geleceği anlatan çığır açıcı bir eser.', NULL, '27.50', 'assets/uploads/book_69e15ee3ad3d06.59538804.png', 3, 3, '2026-04-16 22:10:56'),
(209, 'The Mobile Wave: How Mobile Intelligence Will Change Everything', 27, 15, '9781593157203', 'Mobil teknolojilerin dünyayı nasıl değiştirdiğini ve gelecekte iş, ekonomi ve günlük hayat üzerindeki etkilerini anlatan önemli bir teknoloji kitabı.', NULL, '26.00', 'assets/uploads/book_69e161bce48a78.28874058.png', 3, 3, '2026-04-16 22:25:01'),
(210, 'Don Quijote', 28, 1, '9781589770034', 'Don Quijote, şövalyelik hayallerine kapılan bir adamın gerçek dünyayla çatışmasını anlatan klasik bir romandır.', NULL, '40.00', 'assets/uploads/book_69e243bdadda83.89778508.png', 3, 3, '2026-04-17 14:27:09'),
(211, 'La Casa de Bernarda Alba', 29, 16, '9788420661049', 'La Casa de Bernarda Alba, baskıcı bir annenin evinde yaşayan kızlarının özgürlük arzusu ile otorite arasındaki çatışmayı anlatan bir tiyatro eseridir.', NULL, '30.00', 'assets/uploads/book_69e2455597ce84.79660037.png', 6, 6, '2026-04-17 14:36:06'),
(212, 'Nada', 30, 1, '9788423325108', 'Nada, savaş sonrası İspanya’da genç bir kadının yalnızlık ve kimlik arayışını anlatan bir romandır.', NULL, '45.00', 'assets/uploads/book_69e24fcb8f72e1.86756919.png', 5, 5, '2026-04-17 15:20:43'),
(213, 'Rüzgarın Gölgesi', 31, 1, '9786052984710', 'Rüzgarın Gölgesi, gizemli bir kitabın peşine düşen bir gencin geçmişte saklı karanlık sırları ortaya çıkarmasını konu alan bir romandır.', NULL, '20.00', 'assets/uploads/book_69e2519d1ed055.50538753.png', 2, 2, '2026-04-17 15:25:05'),
(214, 'Marina', 31, 1, '9788804593522', 'Marina, Barselona’da geçen ve bir gencin gizemli bir kızla tanışmasıyla karanlık bir sırrın peşine düşmesini anlatan bir romandır.', NULL, '35.00', 'assets/uploads/book_69e25177e72f27.46193484.png', 1, 1, '2026-04-17 15:27:52'),
(215, 'Arı Kovanı', 27, 1, '9786056663734', 'Arı Kovanı, savaş sonrası Madrid’de farklı insanların hayatlarını kesiştirerek toplumun zor koşullarını anlatan bir romandır.', 'Arı Kovanı, İspanya İç Savaşı sonrasında Madrid’de geçen ve birbirinden farklı çok sayıda insanın yaşamını bir araya getiren çarpıcı bir romandır. Romanın merkezinde tek bir kahraman yoktur; bunun yerine şehirde yaşayan sıradan insanların gündelik hayatları, dertleri, korkuları ve küçük umutları anlatılır. Camilo José Cela, savaşın ardından toplumda oluşan yoksulluğu, çaresizliği ve baskıyı çok gerçekçi bir şekilde yansıtır. Kitapta herkes kendi hayat mücadelesini verirken, aynı zamanda dönemin ağır toplumsal şartları da güçlü biçimde hissedilir.\r\n\r\nEserde pansiyonlarda kalanlar, kahvehanelerde vakit geçirenler, iş arayanlar, geçim sıkıntısı çeken kadınlar, küçük memurlar, öğrenciler ve daha birçok insanın hayatından kısa kesitler sunulur. Bu karakterlerin çoğu birbirini tanır, aynı sokaklarda dolaşır, aynı mekânlarda bulunur ya da dolaylı biçimde birbirlerinin hayatına dokunur. Böylece roman, bireysel hikâyelerden oluşan büyük bir şehir panoramasına dönüşür. Her karakterin yaşadığı yalnızlık, mutsuzluk ya da beklenti farklıdır; ama hepsi aynı boğucu atmosferin içinde yaşamaktadır.\r\n\r\nRoman boyunca büyük olaylardan çok günlük yaşamın içindeki küçük ama etkili anlar ön plana çıkar. İnsanların konuşmaları, suskunlukları, birbirlerine karşı tavırları ve hayata tutunma biçimleri üzerinden savaş sonrası toplumun ruh hâli gösterilir. Kimi karakterler geçmişin izlerini taşırken, kimileri sadece bugünü kurtarmaya çalışır. Sevgi, aldatma, açlık, ahlaki çöküş, hayal kırıklığı ve umut gibi temalar iç içe geçer. Bu yüzden kitap, sadece bir dönemi anlatmakla kalmaz; insan doğasının zayıflıklarını ve direnme gücünü de ortaya koyar.\r\n\r\nArı Kovanı’nın en dikkat çekici yönlerinden biri, Madrid’in adeta yaşayan bir karakter gibi anlatılmasıdır. Şehir kalabalıktır, hareketlidir, ama aynı zamanda insanların iç dünyasındaki yalnızlığı büyüten bir yerdir. Camilo José Cela, birbirine bağlanan bu çok katmanlı hikâyeler aracılığıyla toplumun her kesimini gözlemleyerek güçlü bir sosyal tablo çizer. Sonuç olarak Arı Kovanı, savaş sonrası bir toplumun parçalanmış yapısını, insanların ayakta kalma çabasını ve hayatın sert gerçeklerini etkileyici, derin ve unutulmaz bir biçimde anlatan önemli bir romandır.', '50.00', 'assets/uploads/book_69e25256b24965.71361066.png', 1, 1, '2026-04-17 15:31:35'),
(216, 'Platero ve Ben', 32, 17, '9789750811838', 'Platero ve Ben, bir yazar ile eşeği Platero arasındaki dostluk üzerinden sade ve duygusal yaşam kesitlerini anlatan bir eserdir.', NULL, '30.00', 'assets/uploads/book_69e252ee91ff46.27335879.png', 4, 4, '2026-04-17 15:34:06'),
(217, 'Kanlı Düğün', 29, 16, '9789754587432', 'Kanlı Düğün, bir düğün sırasında yaşanan yasak aşk ve aileler arası çatışmanın trajik sonuçlarını anlatan bir tiyatro eseridir.', NULL, '20.00', 'assets/uploads/book_69e253a72ed711.82318739.png', 3, 3, '2026-04-17 15:37:11'),
(218, 'Yarınki Yüzün', 34, 1, '9789753427968', 'Yarınki Yüzün, bir adamın geçmişi ve kimliği üzerine kurulu gizli görevler ve ihanetler arasında sıkışmasını anlatan bir romandır.', NULL, '40.00', 'assets/uploads/book_69e2542e972a54.20329757.png', 5, 5, '2026-04-17 15:39:26'),
(219, 'Aşkın Halleri', 34, 1, '9786257211291', 'Aşkın Halleri, insan ilişkileri ve aşkın farklı boyutlarını psikolojik derinliklerle ele alan bir romandır.', 'Aşkın Halleri, insan ilişkilerini ve aşkın farklı yüzlerini psikolojik derinliklerle ele alan etkileyici bir romandır. Eserde aşk yalnızca romantik bir duygu olarak değil; özlem, tutku, kırgınlık, bağlılık ve yalnızlık gibi birçok duyguyla birlikte anlatılır. Karakterler, kendi iç dünyalarıyla ve birbirleriyle kurdukları ilişkiler üzerinden aşkın ne kadar karmaşık ve değişken bir deneyim olduğunu gösterir.\r\n\r\nRoman boyunca kişiler arasındaki duygusal çatışmalar, geçmişten gelen izler ve içsel sorgulamalar ön plana çıkar. Bazı karakterler sevginin güven veren tarafını ararken, bazıları aşkın yıpratıcı ve belirsiz yönleriyle yüzleşir. Bu durum, eseri yalnızca bir aşk hikâyesi olmaktan çıkarıp insan ruhunu anlatan güçlü bir psikolojik anlatıya dönüştürür.\r\n\r\nAşkın Halleri, aşkın her insanda farklı biçimde yaşandığını ve her ilişkinin kendi içinde ayrı bir anlam taşıdığını gösterir. Yazar, sade ama etkileyici diliyle okuyucuyu karakterlerin duygularına yaklaştırır. Sonuç olarak eser, aşkı tek boyutlu değil; çok katmanlı, gerçekçi ve düşündürücü bir şekilde ele alan derinlikli bir romandır.', '25.00', 'assets/uploads/book_69e25505d2f8f9.14210011.png', 6, 6, '2026-04-17 15:43:02'),
(220, 'Kaptan Alatriste', 35, 19, '9780399156649', 'Kaptan Alatriste, 17. yüzyıl İspanya’sında geçen ve bir paralı asker olan Diego Alatriste’in savaşlar, entrikalar ve siyasi olaylar içindeki maceralarını anlatan tarihî bir romandır.', NULL, '25.00', 'assets/uploads/book_69e255701077a8.54634905.png', 2, 2, '2026-04-17 15:44:48'),
(221, 'Mucizeler Kenti', 36, 1, '9789755107752', 'Mucizeler Kenti, Barcelona’nın farklı dönemlerinde yaşayan insanların hayatları arasındaki kesişimleri ve şehrin değişimini anlatan bir romandır.', NULL, '45.00', 'assets/uploads/book_69e257ad2d5c25.90134159.png', 4, 4, '2026-04-17 15:54:21'),
(222, 'Güzel ve Karanlık', 37, 1, '9780316077057', 'Güzel ve Karanlık, insanın iç dünyasındaki çatışmaları, yalnızlık ve kimlik arayışı gibi temalar üzerinden psikolojik derinliklerle anlatan bir romandır.', NULL, '30.00', 'assets/uploads/book_69e25cbf3f82a3.17866305.png', 4, 4, '2026-04-17 16:15:59'),
(223, 'El Camino', 38, 1, '9789490347154', 'El Camino, köy yaşamı içinde büyüyen bir çocuğun hayata bakışının şekillenmesini ve yetişkinliğe geçiş sürecini anlatan bir İspanyol romanıdır.', NULL, '50.00', 'assets/uploads/book_69e25d6a83d755.72124548.png', 2, 2, '2026-04-17 16:18:50'),
(224, 'Cinco Horas con Mario', 38, 1, '9780245504013', 'Cinco Horas con Mario, bir kadının ölen eşiyle ilgili düşüncelerini ve evlilikleri boyunca yaşanan çatışmaları iç monolog tekniğiyle anlatan bir romandır.', NULL, '20.00', 'assets/uploads/book_69e25e62d2fe78.40599098.png', 1, 1, '2026-04-17 16:22:58'),
(225, 'La Regenta', 39, 1, '9788432085116', 'La Regenta, küçük bir İspanyol şehrinde geçen, baskıcı toplum yapısı içinde bir kadının iç çatışmalarını ve toplumsal ikiyüzlülüğü ele alan bir romandır.', NULL, '45.00', 'assets/uploads/book_69e25ee0304ae9.09941132.png', 5, 5, '2026-04-17 16:25:04'),
(226, 'Fortunata y Jacinta', 40, 1, '9788497403061', 'Fortunata y Jacinta, 19. yüzyıl Madrid’inde farklı sosyal sınıflardan iki kadının hayatları üzerinden aşk, toplum ve sınıf farklarını anlatan bir romandır.', NULL, '60.00', 'assets/uploads/book_69e25f47baa839.69613113.png', 2, 2, '2026-04-17 16:26:47'),
(227, 'Campos de Castilla', 41, 9, '9788420660554', 'Campos de Castilla, İspanya’nın Kastilya bölgesinin doğası, insanları ve toplumsal yapısını yansıtan şiirlerden oluşan bir eserdir.', NULL, '50.00', 'assets/uploads/book_69e26013c79fe5.65506897.png', 4, 4, '2026-04-17 16:30:11'),
(228, 'Niebla', 41, 1, '9788414337035', 'Niebla, bir adamın kendi varoluşunu sorgulaması ve gerçeklik ile kurgu arasındaki sınırların belirsizleşmesini konu alan felsefi bir romandır.', NULL, '55.00', 'assets/uploads/book_69e2608c9d3491.82085145.png', 8, 8, '2026-04-17 16:32:12'),
(229, 'La Colmena', 42, 1, '9788423345397', 'La Colmena, savaş sonrası Madrid’de farklı insanların hayatlarını kısa sahnelerle kesiştirerek toplumun zorluklarını ve yoksulluğunu anlatan bir romandır.', NULL, '30.00', 'assets/uploads/book_69e26118c43d72.37715286.png', 6, 6, '2026-04-17 16:34:32'),
(230, 'The Aeneid', 43, 9, '9780140449327', 'Roma’nın kuruluş mitini anlatan epik bir şiirdir. Vergilius’un en önemli eserlerinden biridir.', 'Bu eser, Truva’nın yıkılmasının ardından hayatta kalan kahraman Aeneas’ın kaderini ve Roma’nın mitolojik kökenini anlatır. Aeneas, tanrıların buyruğuyla yeni bir yurt bulmak üzere Akdeniz’de uzun ve zorlu bir yolculuğa çıkar. Yolculuk boyunca tanrıça Juno’nun düşmanlığı nedeniyle sürekli engellerle karşılaşır. Kartaca Kraliçesi Dido ile yaşadığı trajik aşk, bireysel duygular ile kader arasındaki çatışmayı temsil eder. Aeneas sonunda İtalya’ya ulaşır ancak burada da yerli halklarla savaşmak zorunda kalır. Eserin ikinci yarısı, bu savaşları ve Aeneas’ın Roma’nın temellerini atacak düzeni kurmasını anlatır. Şiir, Roma’nın ilahi kaderini, fedakârlık ve görev bilinci (pietas) kavramları üzerinden yüceltir. Aynı zamanda imparatorluk ideolojisini destekleyen bir “kuruluş miti” işlevi görür.', '55.00', 'assets/uploads/book_69e3a225c3ee26.46075185.jpg', 6, 6, '2026-04-18 13:35:22'),
(231, 'Aşk ve Gurur', 44, 1, '9750739906', '19. yüzyıl İngiliz toplumunda evlilik ve sınıf ilişkilerini ele alır. Toplumsal normlara karşı bireysel düşüncenin önemini vurgular.', 'Roman, Elizabeth Bennet ve ailesinin yaşadığı dönemde evlilik ve sosyal statünün ne kadar önemli olduğunu göstererek başlar. Elizabeth, zeki ve bağımsız bir karakterdir ve toplumun dayattığı kurallara her zaman sorgulayıcı yaklaşır. Zengin ve gururlu Mr. Darcy ile tanıştığında, onu ilk başta kibirli ve itici bulur. Ancak zamanla Darcy’nin gerçek karakteri ortaya çıkar ve Elizabeth’in önyargıları sarsılır. İkisi de yaşadıkları olaylar sayesinde kendi hatalarını fark eder ve değişim geçirir. Romanın sonunda, aşkın ancak anlayış ve kişisel gelişimle mümkün olduğu vurgulanır.', '45.20', 'assets/uploads/book_69e3a6ca95aba4.93402064.jpg', 7, 7, '2026-04-18 13:36:23'),
(232, '1984', 45, 1, '9780451524935', 'Totaliter bir rejimde bireyin yok edilişini anlatır. Gözetim ve propaganda temalarını işler.', 'Winston Smith, her şeyin devlet tarafından kontrol edildiği baskıcı bir dünyada yaşamaktadır ve sistemin doğrularından şüphe duymaya başlar. Gizlice düşüncelerini korumaya ve özgürlüğünü kazanmaya çalışırken yasaklı bir ilişkiye de sürüklenir. Ancak devletin gücü karşısında direnmek neredeyse imkânsızdır ve hikâye, bireyin sistem karşısındaki çaresizliğini gözler önüne serer.', '50.00', 'assets/uploads/book_69e3a0da5b2287.73258395.jpg', 9, 8, '2026-04-18 13:43:00'),
(233, 'Metamorphoses', 46, 9, '9780140447897', 'Mitolojik dönüşüm hikâyelerini içeren şiirsel bir eserdir. Antik mitolojinin önemli kaynaklarındandır.', 'Eser, dünyanın yaratılışından başlayarak birçok mitolojik olayı birbirine bağlayan hikâyelerden oluşur. Bu hikâyelerin ortak noktası dönüşüm temasıdır ve karakterler farklı varlıklara dönüşür. Tanrıların insanlara müdahalesi çoğu zaman cezalandırma veya ödüllendirme şeklinde olur. Aşk, kıskançlık ve güç gibi duygular olayların temelini oluşturur. Her dönüşüm bir anlam taşır ve insan doğasına dair mesaj verir. Son bölümde anlatı Roma tarihine bağlanarak tamamlanır.', '60.00', 'assets/uploads/book_69e3a25e8c7734.76943336.jpg', 10, 10, '2026-04-18 13:44:39'),
(234, 'Uğultulu Tepeler', 47, 1, '9750738918', 'Tutkulu ama yıkıcı bir aşk hikayesini konu alır. İnsan doğasının karanlık yönlerini gösterir.', 'Heathcliff, küçük yaşta Wuthering Heights’a getirilen gizemli bir çocuktur ve burada Catherine ile güçlü bir bağ kurar. Ancak sosyal sınıf farkları ve yanlış seçimler bu aşkın önüne geçer ve Heathcliff’in hayatı intikam duygusuyla şekillenir. Hikâye ilerledikçe bu kin ve acı, sonraki nesilleri de etkileyen karanlık bir döngüye dönüşür.', '55.00', 'assets/uploads/book_69e3a83976ab15.96405526.jpg', 5, 5, '2026-04-18 13:47:29'),
(235, 'De Bello Gallico', 49, 3, '9780140444339', 'Galya Savaşları’nı anlatan tarihsel bir eserdir. Aynı zamanda propaganda amacı taşır.', 'Julius Caesar’ın kaleme aldığı bu eser, Galya’daki askeri seferlerini yıl yıl detaylandırır. Metin, sade ve doğrudan diliyle dikkat çeker. Caesar, kendisini hem stratejik hem de kararlı bir lider olarak sunar. Galya kabilelerinin kültürleri ve savaş yöntemleri de anlatının önemli bir parçasıdır. Eser, yalnızca askeri bir rapor değil, aynı zamanda politik bir araçtır. Roma halkına kendi başarılarını meşrulaştırmak için yazılmıştır. Savaş sahneleri canlı ve teknik detaylarla doludur. Okuyucu, Roma ordusunun disiplinini ve gücünü yakından hisseder. Aynı zamanda düşmanların bakış açısına da yer verilmesi eseri zenginleştirir. Caesar’ın objektif görünme çabası, metni daha etkileyici kılar. Ancak satır aralarında güçlü bir propaganda dili hissedilir. Bu yönüyle eser, tarih ve siyaset arasındaki ince çizgiyi gözler önüne serer.', '30.00', 'assets/uploads/book_69e3a2a7511063.57095210.jpg', 4, 4, '2026-04-18 13:54:45'),
(236, 'Jane Eyre', 48, 1, '978-0140366785', 'Bağımsız bir kadının hayat mücadelesini anlatır. Aşk ve ahlaki değerler arasındaki dengeyi işler.', 'Charlotte Brontë’nin romanı, yetim bir kız olan Jane Eyre’in çocukluktan yetişkinliğe uzanan hayatını anlatır. Jane, zor bir çocukluk geçirir ve bağımsız bir kadın olarak kendi kimliğini oluşturur. Thornfield Hall’da mürebbiye olarak çalışırken gizemli Mr. Rochester ile tanışır ve aralarında güçlü bir bağ oluşur. Ancak Rochester’ın sakladığı sır, ilişkilerini zorlar. Roman; kadın bağımsızlığı, ahlak, din ve sınıf farkları gibi temaları işler. Jane’in içsel gücü ve prensiplerine bağlılığı eserin merkezindedir.\r\nJane, sürekli olarak kendi değerlerini korumaya çalışır. Rochester ile ilişkisi eşitlik arayışı üzerine kuruludur. Gotik unsurlar hikâyeye gizem katar. Jane’in yolculuğu aynı zamanda bir olgunlaşma sürecidir. Toplumun kadınlara bakışı eleştirilir. Sonunda Jane kendi mutluluğunu kendi kararlarıyla bulur.', '45.00', 'assets/uploads/book_69e38d3f2c41b4.68844683.jpg', 8, 8, '2026-04-18 13:55:11'),
(237, 'Büyük Umutlar', 50, 1, '9789750766763', 'Bir çocuğun büyüyüp olgunlaşma sürecini anlatır. Sınıf ve zenginlik kavramlarını sorgular.', 'Charles Dickens’ın bu romanı, Pip adlı yetimin büyüme ve olgunlaşma sürecini anlatır. Pip, mütevazı bir köyden çıkarak gizemli bir hayırsever sayesinde Londra’da “beyefendi” olma fırsatı yakalar. Ancak zamanla zenginlik ve sosyal statünün mutluluk getirmediğini fark eder. Estella’ya olan aşkı ve geçmişiyle yüzleşmesi, onun kişisel gelişimini şekillendirir. Roman; sınıf sistemi, suçluluk, pişmanlık ve gerçek kimlik arayışı gibi temaları işler. Dickens, Viktorya dönemi toplumunu eleştirir.\r\nPip’in hayalleri zamanla değişir ve olgunlaşır. Estella’nın duygusal soğukluğu önemli bir semboldür. Magwitch karakteri hikâyeye büyük bir sürpriz katar. Londra’nın karanlık yönü detaylı şekilde gösterilir. Pip, gerçek değerlerin para olmadığını öğrenir. Sonunda içsel huzuru bulmaya çalışır.', '25.50', 'assets/uploads/book_69e3aa0e3825f8.04775857.jpg', 7, 7, '2026-04-18 13:59:05'),
(238, 'Frankenstein', 51, 1, '‎ 0486282112', 'Bilimsel deneylerin etik sonuçlarını ele alır. İnsanlık ve sorumluluk kavramlarını sorgular.', 'Mary Shelley’nin bu gotik ve bilim-kurgu romanı, Victor Frankenstein’ın ölümden yaşam yaratma çabasını konu alır. Victor, bilimsel hırsıyla bir canavar yaratır ancak yarattığı varlığı reddeder. Bu yaratık toplum tarafından dışlanır ve yalnızlık içinde öfkeye sürüklenir. Sonuç olarak yaratıcı ile yaratılan arasında trajik bir çatışma ortaya çıkar. Roman, bilimsel sorumluluk, insan doğası, yalnızlık ve ahlaki sınırlar gibi temaları sorgular. Modern bilim kurgu edebiyatının temel taşlarından biridir.\r\nCanavar aslında kötü doğmaz, toplum tarafından kötüleşir. Victor’un sorumsuzluğu felakete yol açar. Hikâye kutu içinde anlatım tekniğiyle sunulur. Kuzey Kutbu’na kadar uzanan bir takip hikâyesi vardır. İnsan olmanın anlamı sorgulanır. Bilim ile ahlak arasındaki denge ana mesajdır.', '30.00', 'assets/uploads/book_69e38ee3904e04.39166131.jpg', 10, 10, '2026-04-18 14:02:10'),
(239, 'Ab Urbe Condita', 52, 3, '9780140448092', 'Roma’nın kuruluşundan itibaren tarihini anlatır. Mitoloji ve gerçek olaylar birlikte sunulur.', 'Roma’nın kuruluş efsanelerinden başlayarak uzun bir tarihsel süreç sunan bu eser, kahramanlık ve erdem temaları etrafında şekillenir. Romulus ve Remus’un hikâyesiyle başlayan anlatı, zamanla daha tarihsel bir çizgiye oturur. Livy, geçmişi anlatırken okuyucuya ahlaki dersler vermeyi amaçlar. Roma’nın yükselişini, disiplin ve değerler üzerinden açıklar. Siyasi mücadeleler ve savaşlar önemli yer tutar. Ancak bireysel karakterlerin hikâyeleri de anlatıyı zenginleştirir. Livy’nin anlatımı akıcı ve dramatiktir. Tarih, yalnızca olayların kronolojisi değil, aynı zamanda bir öğretidir. Roma’nın büyüklüğü, vatandaşlarının erdemlerine bağlanır. Eserde nostaljik bir ton da hissedilir. Yazar, eski Roma değerlerinin kaybolduğunu ima eder. Bu yönüyle eser, hem tarih hem de bir ahlak manifestosudur.', '50.00', 'assets/uploads/book_69e3a2d515c283.36240524.jpg', 8, 8, '2026-04-18 14:03:44'),
(240, 'Hayvan Çiftliği', 45, 1, '9789750719387', 'Bir devrimin nasıl yozlaştığını anlatır. Siyasi sistemlere eleştirel bir bakış sunar.', 'George Orwell’in bu alegorik novellası, bir çiftlikteki hayvanların insan sahiplerine karşı ayaklanmasını anlatır. Hayvanlar başlangıçta eşitlikçi bir toplum kurmayı amaçlar, ancak zamanla domuzların liderliği ele geçirmesiyle yeni bir diktatörlük oluşur. “Bütün hayvanlar eşittir ama bazıları daha eşittir” sözü, sistemin yozlaşmasını özetler. Eser, Sovyetler Birliği’nin tarihine eleştirel bir gönderme yapar. Güç, propaganda ve devrimin yozlaşması ana temalardır.\r\nNapoleon karakteri Stalin’i temsil eder. Snowball ile olan çatışma politik ayrışmayı simgeler. Hayvanlar giderek gerçekleri unutmaya başlar. Dil manipülasyonu burada da önemli bir araçtır. Devrim idealleri tamamen bozulur. Sonunda insanlar ve domuzlar birbirine benzer hale gelir', '45.00', 'assets/uploads/book_69e39117d58787.94240225.jpg', 7, 7, '2026-04-18 14:09:37'),
(241, 'The Annals', 54, 3, '9780140440607', 'Tacitus’un Roma İmparatorluğu’nun erken dönemini anlattığı önemli bir tarih eseridir. İmparatorların yönetim tarzları eleştirel bir bakışla incelenir. Güç ve yozlaşma temaları öne çıkar.', 'Tacitus, Roma İmparatorluğu’nun en çalkantılı dönemlerini keskin bir gözlem gücüyle anlatır. İmparatorların gücü nasıl kullandığı ve bunun toplum üzerindeki etkileri detaylı biçimde işlenir. Entrikalar, ihanetler ve politik oyunlar anlatının merkezindedir. Tacitus’un dili yoğun ve çarpıcıdır. Karakter analizleri derinliklidir. Gücün yozlaştırıcı etkisi sürekli vurgulanır. Halkın sessizliği ve korkusu önemli bir tema olarak öne çıkar. Tarihsel olaylar dramatik bir gerilimle sunulur. Tacitus, resmi anlatıların ötesine geçmeye çalışır. Eleştirel bakış açısı onu diğer tarihçilerden ayırır. Okuyucu, Roma’nın ihtişamı ile çöküşü arasındaki çelişkiyi hisseder. Bu eserler, yalnızca tarih değil, aynı zamanda insan doğasının karanlık yönlerinin bir incelemesidir.', '70.00', 'assets/uploads/book_69e3a3140638b8.15199422.jpg', 4, 4, '2026-04-18 14:12:07'),
(242, 'Dorian Gray’in Portresi', 55, 1, '9789750763342', 'Dorian Gray genç kalmak ister. Bir tablo onun yerine yaşlanır. Ahlaki çöküşü giderek artar.', 'Oscar Wilde’ın romanı, genç ve yakışıklı Dorian Gray’in ruhunu bir portreye yansıtmasıyla başlayan hikâyesini anlatır. Dorian, sonsuz gençlik uğruna ahlaki yozlaşmaya sürüklenir ve günahları portrede görünür hale gelir. Kendisi ise dışarıdan değişmez. Lord Henry’nin hedonist fikirleri Dorian’ı etkiler. Roman, estetikçilik, ahlak, güzellik ve çöküş temalarını işler. İnsan ruhunun karanlık yönlerini felsefi bir bakışla ele alır.\r\nDorian zamanla vicdanını tamamen kaybeder. Portre onun iç dünyasının aynası olur. İşlediği suçlar arttıkça portre çirkinleşir. Toplum ise onun değişmediğini düşünür. Wilde, yüzeysel güzellik kavramını eleştirir. Sonunda Dorian kendi sonunu getirir.', '35.48', 'assets/uploads/book_69e391e1be24c7.03829295.jpg', 7, 7, '2026-04-18 14:14:57'),
(243, 'Gulliver’in Gezileri', 56, 1, '9786052950982', 'Gulliver farklı ülkelere yolculuk yapar. Her yerde farklı toplumlarla karşılaşır. Bu deneyimler insan doğasını eleştirir.', 'Jonathan Swift’in satirik romanı, Lemuel Gulliver’ın fantastik ülkelere yaptığı yolculukları anlatır. Lilliput’ta küçük insanlar, Brobdingnag’da devler, Laputa’da ise tuhaf bilim insanlarıyla karşılaşır. Her bölüm, insan toplumunun farklı yönlerini hicveder. Swift, özellikle siyaset, bilim ve insan doğasındaki saçmalıkları eleştirir. Eser, hem macera hem de güçlü bir toplumsal eleştiridir.\r\nHer ülke farklı bir insan hatasını temsil eder. Lilliput politik kavgaları simgeler. Brobdingnag insan küçüklüğünü vurgular. Laputa bilimsel aşırılığı eleştirir. Gulliver zamanla insanlıktan uzaklaşır. Roman sonunda insan doğasına dair karamsar bir bakış ortaya çıkar.', '25.00', 'assets/uploads/book_69e392d76b7fc7.83153755.png', 5, 5, '2026-04-18 14:17:59'),
(244, 'The Histories', 54, 3, '9780140449648', 'Roma’daki iç savaş dönemini konu alır ve siyasi çöküş süreçlerini anlatır. Tacitus bu dönemi oldukça dramatik ve eleştirel bir şekilde aktarır. İmparatorluk içindeki kaos detaylandırılır.', 'Tacitus’un bu iki eseri, Roma İmparatorluğu’nun özellikle erken dönemlerini ele alır. İmparatorluk sisteminin iç yüzü, entrikalar ve güç mücadeleleri üzerinden anlatılır. Annals, Tiberius’tan Nero’ya kadar olan dönemi inceler. Histories ise daha erken imparatorluk krizlerini konu alır. Tacitus’un üslubu yoğun, eleştirel ve karamsardır. Güç, yozlaşmanın ana kaynağı olarak gösterilir. Senato’nun zayıflığı ve halkın pasifliği dikkat çeker. İmparatorların tiranlaşma süreci detaylandırılır. Tarih anlatımı aynı zamanda ahlaki bir yargıdır. Olaylar dramatik bir gerilimle sunulur. Roma’nın ihtişamı ile çöküşü arasındaki çelişki sürekli vurgulanır. Tacitus, antik dünyanın en keskin tarih eleştirmenlerinden biridir.', '30.00', 'assets/uploads/book_69e3932e203782.89060664.jpg', 8, 8, '2026-04-18 14:20:29'),
(245, 'Robinson Crusoe', 57, 1, '0553213733', 'Crusoe ıssız bir adada mahsur kalır. Kendi başına yaşam kurar. Zamanla yalnızlıkla baş etmeyi öğrenir.', 'Daniel Defoe’nun romanı, Robinson Crusoe’nun bir gemi kazası sonrası ıssız bir adada hayatta kalma mücadelesini anlatır. Crusoe, doğayı kontrol etmeyi öğrenir, kendi düzenini kurar ve hayatta kalır. Daha sonra Cuma adlı bir yerliyle karşılaşır ve onu medenileştirmeye çalışır. Roman, bireyselcilik, sömürgecilik ve insanın doğa üzerindeki hâkimiyeti gibi temaları işler. Aynı zamanda erken dönem macera romanlarının en önemli örneklerinden biridir.\r\nCrusoe’nun dini inancı güçlenir. Zamanla yalnızlığa alışır ve sistem kurar. Ada onun için küçük bir dünya olur. Cuma ile ilişkisi güç ve kültür farkını gösterir. Roman sömürgeci bakış açısını da yansıtır. Hayatta kalma becerisi temel temadır.', '55.00', 'assets/uploads/book_69e39394684cf6.20537800.jpg', 10, 10, '2026-04-18 14:22:11'),
(246, 'Altın Defter', 58, 1, '9755108469', 'Kadın kimliği ve zihinsel bölünmeyi ele alır. Toplumsal baskıları sorgular.', 'Doris Lessing’in bu modernist romanı, yazar Anna Wulf’un parçalanmış hayatını ve yazı defterleri aracılığıyla kimliğini birleştirme çabasını anlatır. Anna, yaşamını farklı defterlerde bölümlere ayırır: aşk, politika, yazarlık ve kişisel yaşam. Ancak bu bölünme, onun içsel krizini yansıtır. Roman, kadın kimliği, psikolojik parçalanma ve modern dünyanın karmaşasını işler. Deneysel anlatımıyla dikkat çeker.\r\nAnna’nın zihinsel dağınıklığı modern yaşamı temsil eder. Yazma süreci onun için terapi gibidir. Politik görüşleri de kimliğini etkiler. Erkek-kadın ilişkileri sürekli sorgulanır. Gerçeklik ile kurgu iç içe geçer. Sonunda bütünlük arayışı ön plana çıkar.', '40.00', 'assets/uploads/book_69e394991a3dd8.67107709.jpg', 7, 7, '2026-04-18 14:25:50'),
(247, 'Satires', 59, 9, '9780140448061', 'Juvenalis’in Roma toplumunu eleştirdiği hiciv şiirlerinden oluşur. Toplumsal yozlaşma, adaletsizlik ve ahlaki çöküş konuları işlenir. Sert ve alaycı bir dil kullanılır.', 'Roma İmparatorluğu’nun toplumsal bozulmasını sert, acımasız ve yer yer öfkeli bir dille eleştiren hiciv şiirlerinden oluşur. Juvenal, eserinde Roma’nın altın çağından uzaklaşıp ahlaki çöküşe sürüklendiğini savunur ve bu çöküşü toplumun her katmanına yayılmış bir hastalık gibi tasvir eder. Şehir hayatı özellikle hedef alınır; Roma, kalabalık, kaotik, güvensiz ve yozlaşmış bir yer olarak resmedilir.\r\n\r\nEserde zenginlik ve güç sahibi insanların açgözlülüğü, sahtekârlığı ve ahlaki çöküntüsü sık sık eleştirilir. Yeni zenginler, liyakat yerine hile ve şansla yükselen kişiler olarak gösterilir. Bu durum, eski Roma erdemleriyle (dürüstlük, ölçülülük, sadelik) keskin bir karşıtlık oluşturur. Juvenal, bu çelişkiyi abartılı sahneler ve keskin benzetmelerle daha da çarpıcı hale getirir.\r\n\r\nSiyaset dünyası da sert eleştirilerden nasibini alır. İktidar sahiplerinin adaletsizliği, halkın ise sessizliği ve korkusu vurgulanır. Özellikle patron–müşteri ilişkisi üzerinden Roma toplumundaki bağımlılık ve eşitsizlik yapısı gözler önüne serilir. İnsanların çıkar için birbirini kullanması, gerçek dostluk ve erdemin kaybolmasına neden olur.\r\n\r\nKadınlar ve aile yapısı da bazı satirlerde eleştirel bir bakışla işlenir; özellikle ahlaki yozlaşma teması üzerinden Roma toplumunun “doğal düzeni”nden uzaklaştığı ima edilir. Eğitimli ama ahlaksız insanlar, sahte filozoflar ve gösteriş düşkünleri sık sık alaya alınır. Juvenal, bilgi ve erdemin birbirinden koptuğu bir toplum tablosu çizer.\r\n\r\nEserin en önemli özelliklerinden biri, güçlü bir “ahlaki öfke” tonudur. Juvenal yalnızca güldürmeyi değil, aynı zamanda rahatsız etmeyi ve düşündürmeyi amaçlar. Abartı, ironi ve sert dil, onun eleştirel mesajını güçlendirir. Bu nedenle Satires, yalnızca bir hiciv değil, aynı zamanda Roma toplumunun karanlık bir aynası olarak kabul edilir.\r\n\r\nGenel olarak eser, bireysel ahlakın çöküşüyle birlikte devletin ve toplumun da nasıl yozlaştığını gösterir. Juvenal’in mesajı açıktır: erdem kaybolduğunda, toplum kaçınılmaz olarak çürür.', '25.00', 'assets/uploads/book_69e3a36add34c8.36722002.jpg', 7, 7, '2026-04-18 14:30:31'),
(248, 'Otomatik Portakal', 60, 1, '6052957921', 'Alex şiddet dolu bir hayat sürer. Devlet onu değiştirmeye çalışır. Özgür irade sorgulanır.', 'Anthony Burgess’in romanı, Alex adlı bir genç ve çetesinin şiddet dolu yaşamını anlatır. Alex, suç işledikten sonra devlet tarafından “yeniden programlama” adı verilen bir yöntemle şiddete karşı koşullandırılır. Ancak bu yöntem özgür irade sorununu gündeme getirir. Roman, bireysel özgürlük, devlet kontrolü ve şiddetin doğası üzerine felsefi bir tartışma sunar. Distopik yapısıyla dikkat çeker.\r\nAlex klasik müzikten hoşlanır. Şiddet onun için bir eğlence biçimidir. Tedavi süreci onu mekanik bir insana çevirir. Özgür irade tamamen ortadan kalkar. Toplum güvenlik için bireyi feda eder. Roman etik sorularla biter.', '25.00', 'assets/uploads/book_69e3a8a5f1a753.51985909.jpg', 3, 3, '2026-04-18 14:30:51'),
(249, 'Emma', 44, 1, '979-8388636751', 'Emma insanları eşleştirmeyi sever. Ancak çoğu zaman yanılır. Bu süreçte kendini tanır.', 'Jane Austen’ın romanı, zengin ve zeki Emma Woodhouse’un çevresindeki insanların aşk hayatını yönlendirmeye çalışmasını anlatır. Emma, başkalarının ilişkilerini düzenleme konusunda kendine aşırı güvenlidir ancak çoğu zaman yanlış kararlar verir. Zamanla kendi duygularını ve hatalarını fark eder. Roman, sosyal sınıf, yanlış anlamalar ve kişisel gelişim temalarını işler. Mizahi ve eleştirel bir dille yazılmıştır.\r\nEmma’nın müdahaleleri genellikle sorun yaratır. Knightley karakteri onun en büyük eleştirmenidir. Yanlış eşleştirmeler hikâyeyi ilerletir. Emma olgunlaşmayı öğrenir. Aşkı fark etmesi zaman alır. Sonunda kendi hatalarını kabul eder.', '30.00', 'assets/uploads/book_69e39639690d00.56516486.jpg', 11, 11, '2026-04-18 14:33:28'),
(250, 'Epistulae Morales ad Lucilium', 61, 4, '9781503128170', 'Stoacı felsefeyi anlatan mektuplardan oluşur. Ahlaki yaşam üzerine öğütler verir. İç huzuru merkeze alır. Günlük hayata uygulanabilir felsefe sunar.', 'Bu eser, Stoacı filozof Seneca’nın dostu Lucilius’a yazdığı mektuplardan oluşan felsefi bir derlemedir ve insanın nasıl daha erdemli, sakin ve bilinçli bir yaşam sürebileceğini anlatır. Seneca, mektuplarında günlük hayatın içinden örnekler vererek felsefeyi soyut bir teori olmaktan çıkarır ve pratik bir yaşam rehberine dönüştürür. En temel düşünce, insanın dış olayları kontrol edemeyeceği ama kendi zihnini ve tepkilerini kontrol edebileceğidir.\r\n\r\nEserde zenginlik, şöhret, korku ve ölüm gibi kavramlar sürekli sorgulanır. Seneca’ya göre mutluluk dış koşullara değil, insanın içsel tutumuna bağlıdır. Bu yüzden erdem, insan yaşamının en yüksek amacı olarak sunulur. Özellikle ölüm korkusu sık sık ele alınır ve ölümün doğal bir süreç olduğu, bu yüzden gereksiz kaygı yaratmaması gerektiği vurgulanır.\r\n\r\nSeneca ayrıca zamanın değerine büyük önem verir; insanın en büyük hatasının zamanı boşa harcamak olduğunu söyler. Günlük yaşamda disiplin, ölçülülük ve kendini tanıma Stoacı felsefenin temel taşlarıdır. Mektuplar ilerledikçe Seneca’nın felsefesi daha derinleşir ve insanın iç dünyasını yönetme sanatı üzerinde yoğunlaşır.\r\n\r\nAynı zamanda eser, Roma toplumunun ahlaki sorunlarına da dolaylı eleştiriler içerir. Gösteriş, aşırı zenginlik ve tutkuların insanı köleleştirdiği fikri sıkça tekrar edilir. Seneca, gerçek özgürlüğün ancak içsel bağımsızlıkla mümkün olduğunu savunur.\r\n\r\nGenel olarak Epistulae Morales ad Lucilium, hem felsefi bir rehber hem de insan doğasına dair derin bir gözlemdir. Stoacılığın en önemli metinlerinden biri olarak, bireyin kendi zihni üzerinde hâkimiyet kurmasını merkeze alır ve bugün bile geçerliliğini koruyan evrensel öğütler sunar.', '60.00', 'assets/uploads/book_69e3968ba9c138.96244552.jpg', 8, 8, '2026-04-18 14:34:51'),
(251, 'Akıl ve Tutku', 44, 1, '9789750761249', 'Mantık ve duygular arasındaki çatışmayı ele alır. Aşk ve aile ilişkilerini işler.', 'Jane Austen’ın bu romanı, Dashwood kardeşler Elinor ve Marianne’in aşk ve maddi zorluklarla mücadelesini anlatır. Elinor mantığı temsil ederken, Marianne duygularıyla hareket eder. İki farklı yaklaşımın sonuçları karşılaştırılır. Roman, evlilik, sosyal statü ve ekonomik bağımlılık gibi temaları işler. Duygu ve akıl arasındaki dengeyi sorgular.\r\nElinor duygularını bastırır. Marianne romantik bir bakışa sahiptir. İki kardeş farklı aşklar yaşar. Toplum baskısı sürekli hissedilir. Maddi sorunlar evlilikleri etkiler. Sonunda iki taraf da dengeyi öğrenir.', '25.00', 'assets/uploads/book_69e396f2c16b20.47562965.jpg', 8, 8, '2026-04-18 14:36:34'),
(252, 'De Amicitia', 62, 4, '9780140442267', 'Dostluk kavramını felsefi olarak inceleyen bir eserdir. İnsan ilişkilerinin ahlaki yönünü ele alır. Erdemi merkeze alır. Sosyal değerleri tartışır.', 'Bu eser, Cicero’nun dostluk kavramını felsefi bir diyalog şeklinde ele aldığı önemli bir metindir ve gerçek dostluğun ne olduğu, nasıl kurulması gerektiği ve hangi değerlere dayanması gerektiği üzerine yoğunlaşır. Hikâye, yaşlı bir Roma devlet adamı olan Laelius’un, yakın dostu Scipio Africanus’un ölümünden sonra dostluk üzerine düşüncelerini anlatmasıyla şekillenir.\r\n\r\nCicero’ya göre gerçek dostluk çıkar üzerine kurulamaz; çünkü çıkar değiştiğinde ilişki de bozulur. Dostluk ancak erdemli insanlar arasında mümkündür ve temelinde güven, dürüstlük ve karşılıklı saygı bulunur. Bu yüzden kötü karakterli insanlar gerçek anlamda dostluk kuramaz.\r\n\r\nEserde dostluk, insan hayatının en değerli bağlarından biri olarak sunulur. İnsan, yalnızca fayda için değil, karakter uyumu ve ahlaki yakınlık nedeniyle dost edinmelidir. Gerçek dost, zor zamanlarda yanında olan, kişiyi daha iyi biri olmaya teşvik eden kişidir.\r\n\r\nCicero ayrıca dostluğun sürekliliğine de vurgu yapar. Gerçek dostluk, ölümle bile tamamen yok olmaz; çünkü insanlar birbirlerinin değerlerini ve hatıralarını yaşatır. Bu yönüyle dostluk, yalnızca sosyal bir ilişki değil, ahlaki bir bağdır.\r\n\r\nEserde siyasi ilişkiler de dolaylı olarak eleştirilir; Roma siyasetinde görülen çıkar ilişkilerinin gerçek dostlukla karıştırılmaması gerektiği vurgulanır. Güç ve makam için kurulan ilişkiler sahte kabul edilir.\r\n\r\nGenel olarak De Amicitia, dostluğu felsefi bir ideal olarak tanımlar ve insan ilişkilerinde erdemi merkeze koyar. Cicero, dostluğu hem bireysel mutluluğun hem de ahlaki yaşamın temel unsurlarından biri olarak görür.', '70.00', 'assets/uploads/book_69e3a40c2a5aa7.16471333.jpg', 10, 10, '2026-04-18 14:38:39'),
(253, 'Oliver Twist', 50, 1, '9750738888', 'Zor şartlarda büyüyen bir çocuğun hikayesini anlatır. Toplumsal adaletsizliği eleştirir.', 'Charles Dickens’ın romanı, yetim Oliver’ın Londra’nın suç dolu sokaklarında hayatta kalma mücadelesini anlatır. Oliver, hırsızlardan oluşan bir çeteye dahil edilir ancak masumiyetini korumaya çalışır. Hikâye, çocuk işçiliği, yoksulluk ve sosyal adaletsizlik gibi temaları eleştirir. Aynı zamanda Viktorya dönemi İngiltere’sinin karanlık yönlerini gözler önüne serer.\r\nFagin karakteri suç dünyasını temsil eder. Oliver sürekli kaçmaya çalışır. Nancy karakteri trajik bir figürdür. Londra’nın karanlık sokakları detaylı anlatılır. Masumiyet sürekli tehdit altındadır. Sonunda gerçek kimliği ortaya çıkar.', '25.00', 'assets/uploads/book_69e3978d346814.87746616.jpg', 6, 6, '2026-04-18 14:39:08'),
(254, 'David Copperfield', 50, 1, '9786052959817', 'Bir bireyin yaşam boyu gelişimini anlatır. Zorluklara karşı direnci vurgular.', 'Charles Dickens’ın yarı otobiyografik romanı, David Copperfield’ın çocukluktan yetişkinliğe uzanan hayatını anlatır. Zor bir çocukluk geçiren David, eğitim ve kişisel deneyimlerle olgunlaşır. Arkadaşlıklar, aşk ve kayıplar onun karakterini şekillendirir. Roman, Viktorya dönemi toplumunu ve bireysel gelişimi detaylı şekilde işler.\r\nDavid birçok farklı çevrede büyür. Steerforth karakteri önemli bir dönüm noktasıdır. Uriah Heep entrikalarıyla dikkat çeker. Aşk hayatı karmaşıktır. Yazarlık onun hayatının merkezi olur. Sonunda kendi yolunu bulur.', '44.99', 'assets/uploads/book_69e3983ac41ed3.82727093.jpg', 6, 6, '2026-04-18 14:42:02'),
(255, 'The Golden Ass', 63, 1, '9780374531812', 'Antik Roma’nın günümüze ulaşan tek tam romanıdır. Fantastik ve mizahi unsurlar içerir. Dönüşüm teması üzerine kuruludur. Toplumsal eleştiri barındırır.', 'Bu eser, Latin edebiyatının günümüze ulaşan tek tam romanı olarak kabul edilir. Hikâye, büyüye meraklı Lucius’un yanlışlıkla eşeğe dönüşmesiyle başlar. Lucius, tekrar insan olabilmek için birçok macera yaşar ve farklı insanların hayatlarına tanık olur. Bu süreçte toplumun farklı kesimleri, ahlaki zaaflar ve insan doğası gözler önüne serilir. Eserde ayrıca “Cupid ve Psyche” gibi bağımsız bir aşk hikâyesi de yer alır. Roman, hem eğlenceli hem de sembolik bir anlatı sunar.', '45.00', 'assets/uploads/book_69e398596b3cf2.72764718.jpg', 4, 4, '2026-04-18 14:42:32'),
(256, 'Canterbury Hikâyeleri', 64, 9, '0140380531', 'Farklı karakterlerin anlattığı hikayelerden oluşur. Ortaçağ toplumunu yansıtır.', 'Geoffrey Chaucer’ın eseri, Canterbury’ye hac yolculuğuna çıkan bir grup insanın anlattığı hikâyelerden oluşur. Her karakter kendi sosyal sınıfını ve kişiliğini yansıtan bir hikâye anlatır. Eser, Orta Çağ İngiltere toplumunun geniş bir panoramasını sunar. Mizahi, eleştirel ve çeşitlilik içeren yapısıyla dikkat çeker.\r\nHikâyeler farklı türlerde yazılmıştır. Rahipler, şövalyeler ve tüccarlar temsil edilir. Her hikâye farklı bir ahlak dersi içerir. Dil çeşitliliği eseri zenginleştirir. Toplumsal eleştiri güçlüdür. Orta Çağ yaşamı ayrıntılı şekilde yansıtılır.', '25.00', 'assets/uploads/book_69e398df558046.13624195.jpg', 5, 5, '2026-04-18 14:44:46'),
(257, 'Hamlet', 65, 16, '‎ 979-8630242716', 'İntikam ve içsel çatışmayı konu alır. İnsan psikolojisini derinlemesine işler.', 'William Shakespeare’in trajedisi, Danimarka prensi Hamlet’in babasının ölümü ve annesinin amcasıyla evlenmesi sonrası intikam arayışını anlatır. Hamlet, hem ahlaki hem de zihinsel bir kriz yaşar. “Olmak ya da olmamak” monoloğu varoluş sorgulamasının sembolüdür. Oyun, intikam, delilik, ihanet ve ölüm temalarını işler.\r\nHamlet sürekli tereddüt eder. Hayalet ona gerçeği söyler. Ophelia trajik bir şekilde ölür. Claudius suçluluk taşır. Oyun içinde oyun tekniği kullanılır. Sonu büyük bir felaketle biter.', '45.00', 'assets/uploads/book_69e39990323f64.52843691.jpg', 10, 10, '2026-04-18 14:47:43'),
(258, 'Confessions', 66, 10, '9780140441147', 'Hristiyan düşüncesinin en önemli otobiyografik eserlerinden biridir. Yazarın yaşamı ve inanç yolculuğunu anlatır. Günah, pişmanlık ve dönüşüm temalarını işler. Felsefi ve dini bir metin olarak kabul edilir.', 'Augustinus’un Tanrı’ya hitaben yazdığı, hem otobiyografi hem de derin bir teolojik-felsefi sorgulama niteliği taşıyan eseridir. Kitap, yazarın çocukluk yıllarından başlayarak gençlik dönemindeki hatalarını, tutkularını ve içsel çatışmalarını samimi bir şekilde anlatmasıyla başlar. Augustinus, özellikle günah, arzu ve dünyevi zevklerin insan ruhunu nasıl saptırdığını detaylı biçimde ele alır.\r\n\r\nEserin önemli bölümlerinden biri, Augustinus’un entelektüel arayışıdır. Felsefe, retorik ve farklı düşünce okulları arasında dolaşırken içsel bir boşluk yaşadığını belirtir. Bu süreçte, insan aklının tek başına hakikati bulmakta yetersiz kaldığını düşünmeye başlar. Özellikle Maniheizm gibi öğretilere yönelmesi ve sonra bunlardan uzaklaşması, onun hakikat arayışının değişim sürecini gösterir.\r\n\r\nAugustinus’un dönüşümünde en kritik nokta, içsel bir kriz anıdır. Vicdan azabı ve ruhsal huzursuzluk içinde Tanrı’ya yönelir. Bu dönüşüm, sadece düşünsel değil, aynı zamanda duygusal ve ruhsal bir kırılma olarak anlatılır. “Tolle lege” (al ve oku) anı, onun İncil’i okumasıyla birlikte tamamen yeni bir yaşam anlayışına geçişini simgeler.\r\n\r\nEserde zaman, hafıza ve insan bilinci gibi felsefi kavramlar da derinlemesine tartışılır. Augustinus, zamanın insan zihninde algılandığını ve geçmiş, şimdi, gelecek kavramlarının zihinsel bir bütünlük içinde var olduğunu savunur. Hafıza ise insanın kimliğini oluşturan temel unsurlardan biri olarak ele alınır.\r\n\r\nTanrı ile insan arasındaki ilişki eserin merkezindedir. Augustinus’a göre insan kalbi, Tanrı’da huzur bulana kadar sürekli bir huzursuzluk içindedir. İnsan iradesi zayıftır ve çoğu zaman günaha eğilimlidir; ancak ilahi lütuf insanı kurtuluşa götürür. Bu nedenle eser hem bireysel hem de teolojik bir dönüşüm hikâyesidir.\r\n\r\nAnlatım boyunca Augustinus, kendi hatalarını açıkça kabul eder ve kendini sorgular. Bu samimiyet, eseri sadece bir biyografi değil, aynı zamanda bir içsel itiraf metni haline getirir. Okuyucu, bir insanın hatalarından arınma sürecine tanıklık eder.', '45.00', 'assets/uploads/book_69e3a477200194.55865693.jpg', 7, 7, '2026-04-18 14:49:24'),
(259, 'Macbeth', 65, 16, '978-1853260353', 'Güç hırsının insanı nasıl değiştirdiğini anlatır. Suç ve vicdan temalarını işler.', 'Shakespeare’in trajedisinde Macbeth, üç cadının kehanetleri ve hırsı nedeniyle kralı öldürür. Güç elde ettikten sonra paranoya ve suçluluk duygusu onu yavaşça çöküşe sürükler. Lady Macbeth de bu süreçte deliliğe sürüklenir. Oyun, hırs, iktidar ve vicdan temalarını işler.\r\nMacbeth sürekli korku içindedir. Cinayetler zincirleme devam eder. Lady Macbeth suçlulukla baş edemez. Cadılar kaderi temsil eder. Doğa olayları kaosu yansıtır. Sonunda Macbeth düşer.', '35.00', 'assets/uploads/book_69e39a2b1cff09.08523607.jpg', 7, 7, '2026-04-18 14:50:18'),
(260, 'İki Şehrin Hikâyesi', 50, 1, '6257070112', 'Fransız Devrimi sırasında Londra ve Paris’te geçen olayları konu alır. Adaletsizlik, fedakârlık ve insan hayatının zor şartlarda nasıl değiştiğini anlatır.', 'Charles Dickens’ın bu romanı, Fransız Devrimi öncesi ve sırasında Londra ile Paris arasında geçen olayları konu alır. Hikâye, “It was the best of times, it was the worst of times” cümlesiyle dönemin çelişkili yapısını vurgulayarak başlar. Romanın merkezinde Charles Darnay, Lucie Manette ve Sydney Carton karakterleri yer alır. Darnay, aristokrat geçmişini reddedip İngiltere’de yeni bir hayat kurmaya çalışırken, Fransa’da devrimci şiddetin hedefi haline gelir. Lucie, babası Dr. Manette ile birlikte sevgi ve bağlılığın sembolü olur. Sydney Carton ise ilk başta umursamaz görünen ama zamanla büyük bir fedakârlık yapacak bir karakterdir.\r\n\r\nRoman Fransız Devrimi’nin hem adalet arayışını hem de kontrolsüz şiddetini gösterir. Paris’teki giyotin sahneleri devrimci öfkenin ne kadar yıkıcı olabileceğini anlatır. Londra ise daha istikrarlı ama sınıfsal gerilimlerin olduğu bir zemin sunar. Dr. Manette’nin hapishane travması, bireysel acının politik olaylarla nasıl birleştiğini gösterir. Sydney Carton’un karakter gelişimi romanın en önemli dönüşümüdür. Sonunda Carton’un yaptığı fedakârlık, hikâyenin en güçlü duygusal zirvesini oluşturur.\r\n\r\nCarton, Darnay’ın yerine geçerek onun hayatını kurtarır ve kendi hayatını feda eder. Bu fedakârlık, aşkın ve insanlığın en yüksek formu olarak sunulur. Roman, adalet, intikam, yeniden doğuş ve fedakârlık temalarını işler. Dickens, devrimlerin hem umut hem de yıkım getirebileceğini vurgular. Lucie karakteri etrafında “ışık” ve “umut” sembolleri sürekli kullanılır. Hikâye, bireysel kurtuluş ile toplumsal kaos arasındaki dengeyi anlatır.', '45.00', 'assets/uploads/book_69e39b47027f17.95522603.jpg', 7, 7, '2026-04-18 14:54:47'),
(261, 'The Satyricon', 67, 1, '9780140444896', 'Roma toplumunu hiciv yoluyla eleştiren parçalı bir romandır. Mizah ve eleştiri birlikte kullanılır. Yozlaşmış toplumsal yapıyı anlatır. Antik roman türünün önemli örneklerindendir.', 'Roma İmparatorluğu döneminde yazılmış en erken Latin roman örneklerinden biri olup parçalı yapısı ve hiciv dolu anlatımıyla dikkat çeker. Eser, genç ve maceraperest karakterlerin başından geçen olaylar etrafında şekillenir ve belirli bir “kahramanlık hikâyesi” sunmak yerine düzensiz, bölümlü bir anlatı yapısı izler. Bu yapı, bilinçli olarak Roma toplumunun kaotik ve yozlaşmış doğasını yansıtmak için kullanılır.\r\n\r\nHikâyede özellikle Encolpius adlı anlatıcının yaşadığı maceralar merkezde yer alır. O ve arkadaşları, sürekli olarak aşk, para, hayatta kalma ve aldatma gibi sorunlarla karşılaşır. Bu yolculuklar sırasında farklı sosyal sınıflardan insanlar tanıtılır ve Roma toplumunun geniş bir panoraması sunulur. Zenginlerin aşırı gösterişi, fakirlerin çaresizliği ve genel ahlaki çöküş sık sık vurgulanır.\r\n\r\nEserin en ünlü bölümlerinden biri “Trimalchio’nun Ziyafeti”dir. Bu sahnede yeni zengin bir adamın aşırı lüks ve abartılı yaşamı mizahi ve eleştirel bir şekilde anlatılır. Trimalchio’nun gösterişi, Roma’daki sosyal yükselişin çoğu zaman gerçek erdemle değil servetle ilgili olduğunu gösterir. Bu bölüm, eserin en güçlü hiciv örneklerinden biridir.\r\n\r\nSatyricon aynı zamanda cinsellik, açgözlülük ve sahtekârlık gibi temaları açık bir şekilde işler. Karakterler çoğu zaman ahlaki sınırları olmayan, çıkar odaklı bireyler olarak tasvir edilir. Bu durum, Roma toplumunun “parçalanmış ahlak yapısı”nı gözler önüne serer.\r\n\r\nPetronius, eserinde ciddi bir anlatım yerine alaycı ve ironik bir ton kullanır. Bu sayede hem eğlenceli hem de eleştirel bir metin ortaya çıkar. Gerçeklik ile abartı sürekli iç içedir ve okuyucuya kasıtlı bir rahatsızlık hissi verilir.', '40.00', 'assets/uploads/book_69e3a4ab1f10e6.16976976.jpg', 4, 4, '2026-04-18 14:54:48'),
(262, 'Agricola', 54, 10, '9780521700290', 'Roma generali Agricola’nın hayatını anlatan biyografik eserdir. Askeri başarılar ve karakter analizi içerir. Roma yönetimine dolaylı eleştiri yapar. Tarihsel ve politik bir metindir.', 'Tacitus’un kayınpederi olan Gnaeus Julius Agricola’nın hayatını anlatan biyografik bir eserdir ve aynı zamanda Roma İmparatorluğu’nun siyasi atmosferine dair güçlü bir eleştiri metnidir. Eser, Agricola’nın gençlik yıllarından başlayarak askeri ve idari kariyerini adım adım takip eder. Onun özellikle Britanya’daki valiliği ve askeri başarıları detaylı şekilde anlatılır.\r\n\r\nAgricola, Roma’nın Britanya’yı fethetme sürecinde hem stratejik başarıları hem de yerel halklarla kurduğu dengeli ilişkilerle ideal bir Roma yöneticisi olarak sunulur. Tacitus, onu aşırı zulümden kaçınan, ölçülü ve yetenekli bir komutan olarak tasvir eder. Bu yönüyle Agricola, Roma erdemlerinin somut bir örneği haline gelir.\r\n\r\nEserde yalnızca bir biyografi anlatılmaz; aynı zamanda İmparator Domitian döneminin baskıcı yönetimi de sert bir şekilde eleştirilir. Tacitus, bu dönemde özgürlüğün bastırıldığını, senatonun etkisiz hale geldiğini ve korku ortamının hâkim olduğunu vurgular. Agricola’nın başarıları bu baskıcı siyasi ortamın gölgesinde daha da anlam kazanır.\r\n\r\nBritanya halklarının direnişi ve Roma’ya karşı mücadeleleri de eserde önemli bir yer tutar. Tacitus, hem Roma’nın fetih politikasını hem de yerli halkların özgürlük arzusunu dengeli bir şekilde anlatır. Bu sayede eser, sadece Roma merkezli bir bakış sunmaz.\r\n\r\nAgricola’nın kişiliği, Roma erdemleri ile imparatorluk baskısı arasında bir denge noktası olarak çizilir. Onun başarısı, bireysel yetenek ile ahlaki karakterin birleşimi olarak gösterilir. Ölümü ise hem kişisel bir kayıp hem de politik bir mesaj niteliği taşır.', '70.00', 'assets/uploads/book_69e39beb5a0dc3.71830753.jpg', 4, 4, '2026-04-18 14:57:46'),
(263, 'Germania', 54, 3, '9798840756126', 'Germen kabilelerinin yaşamını anlatan etnografik bir eserdir. Roma dışı toplumları inceler. Sosyal yapı ve gelenekler ele alınır. Karşılaştırmalı bir bakış sunar.', 'Tacitus’un Roma İmparatorluğu’nun dışında yaşayan Germen kabilelerini anlattığı etnografik bir eserdir. Yazar, bu toplulukların coğrafi konumlarını, yaşam tarzlarını, savaşçı kültürlerini ve sosyal yapılarını detaylı biçimde ele alır. Germenler genellikle sade, doğayla iç içe yaşayan ve güçlü aile bağlarına sahip halklar olarak tasvir edilir.\r\n\r\nTacitus, Germen toplumunu anlatırken sık sık Roma ile karşılaştırma yapar. Germenlerin basit ve disiplinli yaşamı, Roma’nın karmaşık ve yozlaşmış yapısına karşı bir zıtlık oluşturur. Özellikle Roma toplumundaki ahlaki çöküşe dolaylı eleştiriler bu karşılaştırmalar üzerinden verilir.\r\n\r\nEserde kadınların toplumdaki rolü, evlilik yapısı ve çocuk yetiştirme anlayışı da önemli bir yer tutar. Germen kadınları genellikle sadık, güçlü ve toplum içinde saygın bireyler olarak gösterilir. Bu durum, Roma’daki bazı sosyal normlara eleştiri niteliği taşır.\r\n\r\nAskerî yapı ve savaş kültürü de detaylı şekilde anlatılır. Germen kabilelerinin cesareti ve savaşçılığı vurgulanırken, aynı zamanda onların örgütlenme biçimleri de açıklanır. Coğrafya ve sert doğa koşulları yaşam biçimlerini doğrudan etkiler.', '25.00', 'assets/uploads/book_69e39d106bd795.43843271.jpg', 3, 3, '2026-04-18 15:02:39');
INSERT INTO `books` (`id`, `title`, `author_id`, `category_id`, `isbn`, `description`, `summary`, `price`, `image_path`, `total_copies`, `available_copies`, `created_at`) VALUES
(264, 'Naturalis Historia', 68, 3, '9780140444131', 'Antik dünyanın en kapsamlı doğa ansiklopedisidir. Doğa, bilim ve insan yaşamını kapsar. Farklı alanlardan bilgi derler. Bilim tarihi açısından önemli bir kaynaktır.', 'Plinius the Elder tarafından yazılmış ve antik dünyanın en kapsamlı bilgi derlemelerinden biri kabul edilen ansiklopedik bir eserdir. Yazar, doğa, coğrafya, astronomi, zooloji, botanik, mineralojı ve sanat gibi çok geniş bir alanı tek bir çalışmada toplamayı amaçlar. Eser, yaklaşık 37 kitaptan oluşan dev bir bilgi arşivi niteliğindedir.\r\n\r\nPlinius, bu eseri oluştururken kendi gözlemlerini, gezilerden edindiği bilgileri ve dönemin yazılı kaynaklarını bir araya getirir. Amaç, insanın doğayı anlamasını sağlayacak bütünsel bir bilgi sistemi oluşturmaktır. Bu yönüyle eser, antik dünyada “evrensel bilgi” fikrine en yakın çalışmalardan biridir.\r\n\r\nEserde hayvanlar ve bitkiler ayrıntılı biçimde sınıflandırılır. Birçok canlı türünün özellikleri, davranışları ve insanlarla ilişkileri anlatılır. Aynı şekilde taşlar, metaller ve değerli madenler de incelenir. Plinius, doğadaki her unsurun bir anlamı ve işlevi olduğuna inanır.\r\n\r\nCoğrafya bölümlerinde Roma İmparatorluğu’nun bilinen dünyası ayrıntılı şekilde tasvir edilir. Dağlar, nehirler, şehirler ve halklar hakkında bilgiler verilir. Bu kısım, antik dünyanın “dünya haritası” gibi düşünülebilir.\r\n\r\nEserde bilimsel doğruluk modern anlamda sistematik değildir; mitolojik ve efsanevi bilgiler de sıkça yer alır. Ancak bu durum, antik dönemin bilgi anlayışını yansıtır. Plinius için önemli olan, bilinen her şeyi kayıt altına almaktır.', '60.00', 'assets/uploads/book_69e39e7a382c10.56086353.jpg', 3, 3, '2026-04-18 15:08:41'),
(265, 'Ars Amatoria', 46, 9, '9786257462303', 'Ars Amatoria, Romalı şair Ovid tarafından yazılmış ve aşkı, flörtü ve ilişki kurma yöntemlerini şiirsel bir dille anlatan didaktik bir eserdir', 'Ars Amatoria, Ovid’in aşkı bir “sanat” gibi ele aldığı üç kitaplık şiir eseridir. Erkeklere nasıl etkileyici bir şekilde kadınları tanıyıp aşık edebileceklerini, ilişkiyi nasıl sürdürebileceklerini öğretir; üçüncü kitapta ise kadınlara aşk ve çekicilik üzerine tavsiyeler verir. Eserde aşk, eğlenceli ve stratejik bir oyun gibi anlatılır; duygusal derinlikten çok akılcı ve sosyal becerilere vurgu yapılır. Ovid, Roma toplumundaki flört kültürünü mizahi ve yer yer provokatif bir dille işler.\r\nOvid’in amacı yalnızca öğretmek değil, aynı zamanda Roma toplumundaki aşk ve flört anlayışını eğlenceli ve yer yer alaycı bir üslupla eleştirmektir. Bu yönüyle eser, hem edebi hem de kültürel açıdan Antik Roma’nın sosyal yaşamına dair önemli bir kaynak kabul edilir.', '35.00', 'assets/uploads/book_69e39f2c823752.19526838.jpg', 5, 5, '2026-04-18 15:11:39'),
(266, 'Latin Literature: An Anthology', 69, 3, '9780140443899', 'Latin edebiyatından seçilmiş metinlerden oluşan derleme bir kitaptır. Farklı yazarları bir araya getirir. Eğitim amaçlı kullanılır. Edebiyat tarihi için önemli bir kaynaktır.', 'Latin edebiyatının farklı dönemlerinden seçilmiş metinleri bir araya getiren bir derleme kitaptır. Bu eser tek bir yazarın hikâyesi ya da tek bir konuya odaklanan bir kitap değildir; bunun yerine Roma ve Latin dünyasının edebi çeşitliliğini göstermek amacıyla hazırlanmış seçkiler içerir.\r\n\r\nİçinde şiir, hitabet (retorik), felsefi metinler, tarih yazıları ve drama parçaları gibi farklı türlerden örnekler bulunur. Böylece okuyucu, Latin edebiyatının sadece tek bir tarzdan ibaret olmadığını; aksine çok geniş bir kültürel ve düşünsel alanı kapsadığını görür.\r\n\r\nEserde Virgil, Ovid, Cicero, Seneca, Horatius gibi birçok önemli yazarın metinlerine yer verilir. Bu sayede hem Roma Cumhuriyeti hem de İmparatorluk döneminin edebi gelişimi takip edilebilir. Metinler, genellikle tematik ya da kronolojik bir düzen içinde sunulur.\r\n\r\nBu tür antolojiler özellikle eğitim amaçlı kullanılır. Öğrencilerin Latin edebiyatını orijinal metinler üzerinden tanımasını ve farklı yazarların üslup farklarını görmesini sağlar. Aynı zamanda çeviri ve analiz pratiği için de temel bir kaynak oluşturur.', '25.50', 'assets/uploads/book_69e39ff232ec39.06748513.jpg', 3, 3, '2026-04-18 15:13:54'),
(267, 'A History of Ancient Rome', 70, 3, '9781597380423', 'Bu kitap, Antik Roma’nın kuruluşundan çöküşüne kadar uzanan tarihini siyasi, sosyal ve kültürel yönleriyle ele alan akademik bir eserdir.', 'A History of Ancient Rome, Roma’nın küçük bir şehir devletinden devasa bir imparatorluğa dönüşüm sürecini kronolojik bir şekilde anlatır. Eserde Roma’nın krallık dönemiyle başlayan tarihi, Cumhuriyet’in kuruluşu, siyasi kurumların gelişimi ve genişleme politikaları detaylı biçimde ele alınır. Julius Caesar, Augustus ve diğer önemli liderlerin yükselişiyle Roma’nın imparatorluk haline gelişi açıklanırken, aynı zamanda iç siyasi çekişmeler, sınıf mücadeleleri ve askeri reformlar da incelenir. Kitap, Roma’nın yalnızca savaş ve fetihlerle değil, hukuk sistemi, mühendislik başarıları ve kültürel mirasıyla da nasıl güçlü bir medeniyet haline geldiğini vurgular. Ayrıca imparatorluğun zamanla yaşadığı ekonomik sorunlar, dış saldırılar ve yönetim zayıflıkları üzerinden çöküş süreci analiz edilir. Böylece eser, Antik Roma’yı hem bir siyasi güç hem de Batı dünyasını şekillendiren bir uygarlık olarak kapsamlı biçimde okuyucuya sunar.', '35.00', 'assets/uploads/book_69e3a02236a5c4.54215943.jpg', 4, 4, '2026-04-18 15:15:45'),
(268, 'Ecce Romani', 71, 7, '0133610896', 'Latin dilini öğretmek için hazırlanmış ders kitabıdır. Hikâye temelli öğrenme yöntemi kullanır. Günlük Roma yaşamını konu alır. Dil öğretimi için yapılandırılmıştır.', 'Roma\'da yaşayan bir ailenin hikâyesini takip ederek Latin dilini adım adım öğretir. Her bölüm, dil bilgisi kurallarını ve yeni kelimeleri tanıtarak öğrencinin okuma ve anlama becerilerini geliştirir. Hikâyelerde yer alan günlük yaşam sahneleri, öğrencilerin dil bilgisini somut örneklerle pekiştirmesini sağlar. Öğrenci, Roma\'da geçen günlük aktivitelerle karşılaşırken, dilin yapısını doğal bir şekilde öğrenir. Bu yapılandırılmış yaklaşım, hem dil bilgisi hem de iletişim becerilerini aynı anda geliştirmeyi amaçlar.\r\n\r\nKitap, başlangıç seviyesinden ileri seviyeye kadar geniş bir öğrenci kitlesine hitap edebilecek şekilde tasarlanmıştır. Dil bilgisi kuralları ve kelime bilgisi, her hikâyeyle birlikte sunulmakta ve öğrenciye kolay anlaşılır bir şekilde öğretilmektedir. Eğitim odaklı bu sistem, Latin diline dair sağlam bir temel oluşturulmasını sağlar. \"Ecce Romani\", Latin dili öğrenmeye yeni başlayanlar için yaygın olarak kullanılan bir öğretim kaynağıdır ve oldukça etkili bir müfredat sunar.', '30.00', 'assets/uploads/book_69e3a0eb6f1fd1.45210483.jpg', 6, 6, '2026-04-18 15:19:06'),
(269, 'Wheelock’s Latin', 72, 7, '9780061997211', 'Latin dilini öğrenmek için en yaygın kullanılan akademik kitaptır. Sistemli bir gramer öğretimi sunar. Üniversitelerde temel kaynak olarak kullanılır. Kendi kendine öğrenmeye uygundur.', 'Latin dilini öğrenmeye yeni başlayanlar için kapsamlı ve sistemli bir kaynak sunar. Kitap, dilin temel gramer yapılarından başlayarak, öğrenciyi adım adım daha karmaşık yapılara yönlendirir. İlk bölümler, Latin dilinin temel kurallarını tanıtırken, ilerleyen bölümlerde bu kurallar daha ileri düzeydeki dil bilgisi yapılarıyla pekiştirilir. Her dersin ardından, öğrencinin öğrendiklerini uygulayabileceği örnek metinler ve alıştırmalar bulunur.\r\n\r\nKitap, öğrencilerin okuma ve çeviri becerilerini geliştirmeyi amaçlar. Latin dilinin yapısı ve kelime bilgisi, kitap boyunca çeşitli metinler aracılığıyla pekiştirilir. Bu metinler, öğrencinin klasik Latin metinleriyle bağlantı kurmasına yardımcı olur. Bu sayede öğrenciler, sadece dil bilgisi öğrenmekle kalmaz, aynı zamanda dilin kültürel ve tarihi bağlamına da hakim olurlar.\r\n\r\nWheelock’s Latin’in en önemli özelliklerinden biri, dil öğretimi için aktif öğrenme yöntemini benimsemesidir. Öğrenciler, sadece teorik bilgiyle değil, aynı zamanda aktif olarak dil üzerinde çalışarak öğrenirler. Dilin gramer yapıları ve kuralları, gerçek dünya metinleri ve örneklerle desteklenerek öğrencinin doğal bir şekilde öğrenmesine olanak tanır.', '25.00', 'assets/uploads/book_69e3a1ac3006b3.12898659.jpg', 3, 3, '2026-04-18 15:22:19'),
(270, 'İlahi Komedya', 73, 9, '9789750802945', 'İlahi Komedya, dünya edebiyatının en önemli eserlerinden biri kabul edilir. Eser üç bölümden oluşur: Cehennem, Araf ve Cennet. Dante bu eserinde hem Orta Çağ düşüncesini hem de insanın manevi yolculuğunu anlatır. Şiir biçiminde yazılmıştır ve çok sayıda sembol içerir. Din, ahlak, günah ve kurtuluş temaları kitabın merkezindedir.', 'Dante, yaşamında karanlık bir döneme girdiğinde kendisini büyük bir ormanda kaybolmuş halde bulur. Burada karşısına çıkan Roma şairi Vergilius ona rehberlik eder. İlk olarak cehennemin dokuz katını gezerler ve her katta farklı günahlar işlemiş insanların cezalarını görürler. Daha sonra araf dağına çıkarak insanların günahlarından arınma sürecine tanık olurlar. Son bölümde Dante’nin çocukluk aşkı Beatrice ona rehberlik eder ve birlikte cennete ulaşırlar. Dante burada insan ruhunun kurtuluşa nasıl erişebileceğini anlatır.', '45.00', 'assets/uploads/book_69e3dec2bcfb65.85823081.webp', 3, 3, '2026-04-18 19:41:12'),
(271, 'Decameron', 74, 17, '9789750738602', 'Decameron, İtalyan Rönesansı’nın en önemli eserlerinden biridir. Kitap, veba salgını sırasında Floransa’dan kaçan on gencin anlattığı hikâyelerden oluşur. İçerisinde aşk, para, din, dostluk ve insan ilişkileri üzerine pek çok farklı olay vardır. Eser hem eğlenceli hem de düşündürücü bir anlatıma sahiptir. İnsan doğasını gerçekçi biçimde göstermesiyle dikkat çeker.', 'Floransa’da büyük bir veba salgını yaşanırken yedi kadın ve üç erkek şehirden uzaklaşır. Kırsaldaki bir villaya yerleşen gençler, can sıkıntısını gidermek için her gün birbirlerine hikâyeler anlatmaya karar verir. On gün boyunca toplam yüz hikâye anlatılır. Bu hikâyelerde kimi zaman birbirine kavuşmaya çalışan âşıklar, kimi zaman açgözlü insanlar, kimi zaman da din adamlarının ikiyüzlülüğü anlatılır. Bazı hikâyeler komik, bazıları ise hüzünlüdür. Böylece kitap, insanların farklı yönlerini gösteren büyük bir hikâye koleksiyonuna dönüşür.', '40.00', 'assets/uploads/book_69e3df457cd366.71962500.webp', 4, 4, '2026-04-18 19:45:08'),
(272, 'Nişanlılar', 75, 1, '9789754589217', 'Nişanlılar, İtalyan edebiyatının en önemli tarihî romanlarından biridir. Roman, 17. yüzyıl İtalya’sında geçer ve dönemin toplumsal sorunlarını anlatır. Savaş, salgın, adaletsizlik ve sınıf ayrımı kitapta önemli yer tutar. Aynı zamanda iki gencin aşk hikâyesini merkeze alır. Hem tarihî hem de duygusal yönü güçlü bir eserdir.', 'Renzo ile Lucia birbirini seven iki gençtir ve evlenmek istemektedir. Ancak Don Rodrigo adındaki güçlü ve kötü niyetli bir soylu, Lucia’yı istediği için bu evliliğe engel olur. Bunun üzerine Renzo ve Lucia ayrı düşmek zorunda kalır. Renzo farklı şehirlere giderken Lucia bir manastıra sığınır. Bu sırada ülkede savaşlar, kıtlık ve veba salgını yaşanmaktadır. Uzun süre boyunca büyük zorluklarla mücadele eden çift, sonunda yeniden kavuşmayı başarır.', '35.00', 'assets/uploads/book_69e3e9af6aca86.01849519.webp', 5, 5, '2026-04-18 20:29:35'),
(273, 'Pinokyo', 76, 8, '9789750719380', 'Pinokyo, çocuk edebiyatının en tanınmış eserlerinden biridir. Ahşaptan yapılan bir kuklanın gerçek bir çocuğa dönüşme isteğini anlatır. Kitapta dürüstlük, çalışkanlık ve sorumluluk gibi değerler öne çıkar. Eğlenceli ve maceralı bir anlatımı vardır. Hem çocuklara hem de yetişkinlere hitap eden bir eserdir.', 'Marangoz Gepetto, tahtadan bir kukla yapar ve ona Pinokyo adını verir. Pinokyo canlanır ancak çok yaramaz ve söz dinlemeyen bir çocuktur. Okula gitmek yerine maceralara atılır, kötü insanların oyununa gelir ve sürekli başını belaya sokar. Yalan söylediğinde burnu uzar ve yaptığı hataların sonuçlarını yaşamaya başlar. Zamanla doğruyu söylemenin ve çalışmanın önemini öğrenir. Sonunda iyi bir çocuk olduğu için gerçek bir insana dönüşür.', '25.00', 'assets/uploads/book_69e3ea8aaa8623.44534841.jpg', 10, 10, '2026-04-18 20:33:14'),
(274, 'Gülün Adı', 77, 20, '9789750738600', '14.yüzyılda bir manastırda geçen roman, ardı ardına işlenen gizemli cinayetleri konu alır. Kitap hem polisiye hem de felsefi yönüyle dikkat çeker. Orta Çağ’ın karanlık atmosferi ayrıntılı biçimde işlenmiştir.', 'William of Baskerville adlı keşiş ve yardımcısı Adso, kuzey İtalya’daki bir manastıra gelir. Burada peş peşe yaşanan ölümler, manastırın büyük kütüphanesindeki sırlarla bağlantılıdır. William mantığını ve gözlem gücünü kullanarak cinayetleri çözmeye çalışır. Araştırma ilerledikçe din, bilgi ve güç arasındaki ilişki ortaya çıkar.', '55.00', 'assets/uploads/book_69e3ec259ebb29.31111377.webp', 8, 8, '2026-04-18 20:40:05'),
(275, 'Leopar', 78, 1, '9789750738396', '19.yüzyıl İtalya’sındaki toplumsal değişimi bir aristokrat ailenin gözünden anlatır. Roman, eski düzenin yavaş yavaş çöküşünü işler. İtalyan edebiyatının en güçlü klasiklerinden biridir.', 'Sicilyalı prens Don Fabrizio, İtalya’nın birleşme sürecinde toplumun hızla değiştiğini görür. Ailesinin ve sınıfının eski gücünü kaybetmeye başladığını fark eder. Genç kuşaklar yeni düzene uyum sağlarken, prens geçmişe bağlı kalır. Böylece eski ile yeni arasındaki çatışma romanın merkezini oluşturur.', '45.00', 'assets/uploads/book_69e3ecae34e422.61905738.jpg', 6, 6, '2026-04-18 20:42:21'),
(276, 'Benim Olağanüstü Akıllı Arkadaşım', 79, 1, '9786052991672', 'Napoli’de büyüyen iki kızın dostluğunu anlatan modern bir romandır. Kadınların hayatı, eğitim mücadelesi ve toplumsal baskılar ön plandadır. Ferrante’nin en ünlü eserlerinden biridir.', 'Elena ve Lila, yoksul bir Napoli mahallesinde birlikte büyür. İki arkadaş çok farklı karakterlere sahip olsa da birbirlerinden kopamazlar. Eğitim, aşk, aile ve rekabet onların ilişkisini sürekli değiştirir. Roman, çocukluktan yetişkinliğe uzanan karmaşık bir dostluk hikâyesini anlatır.', '38.00', 'assets/uploads/book_69e3ed26a80e46.80017209.jpg', 4, 4, '2026-04-18 20:44:22'),
(277, 'Eğer Bir Kış Gecesi Bir Yolcu', 80, 1, '9789750737221', 'Okuru doğrudan hikâyenin içine çeken sıra dışı bir romandır. Kitap, yarım kalan birçok hikâyeyi iç içe geçirir. Modern edebiyatın en yaratıcı eserlerinden biri sayılır.', 'Romanın başkahramanı aslında okurun kendisidir. Okur yeni aldığı kitabı okumaya başlar fakat her seferinde farklı bir hikâyeyle karşılaşır. Sürekli yarım kalan bu anlatılar, kitabın neden eksik olduğunu araştıran bir maceraya dönüşür. Böylece okuma deneyimi romanın temel konusu haline gelir.', '49.99', 'assets/uploads/book_69e3edbb6a6c01.15182745.jpg', 11, 11, '2026-04-18 20:46:51'),
(278, 'Altı Kişi Yazarını Arıyor', 84, 16, '9789750734381', 'Tiyatro tarihinin en yenilikçi oyunlarından biridir. Gerçek ile kurgu arasındaki sınırları sorgular. Modern tiyatronun gelişiminde büyük etkisi olmuştur.', 'Bir tiyatro provası sırasında sahneye altı kişi gelir. Bu kişiler, hikâyelerini tamamlayacak bir yazar aradıklarını söylerler. Oyuncularla bu karakterler arasında gerçeklik üzerine tartışmalar yaşanır. Sonunda seyirci, neyin gerçek neyin kurgu olduğunu ayırt etmekte zorlanır.', '35.00', 'assets/uploads/book_69e3ef11bbe084.28005468.jpg', 7, 7, '2026-04-18 20:52:33'),
(279, 'Kayıtsızlar', 85, 21, '9789750735074', 'Modern İtalyan toplumunun ahlaki çöküşünü ele alır. Karakterlerin duygusal boşlukları ve ilgisizlikleri ön plandadır. Moravia’nın en bilinen romanıdır.', 'Varlıklı bir ailenin üyeleri, hayatlarında hiçbir şeye gerçek anlamda bağlanamazlar. Anne, çocuklar ve çevrelerindeki insanlar çıkar ilişkileri içinde yaşamaktadır. Özellikle Michele adlı genç, bu yapay hayatın içinden çıkmaya çalışır. Roman, insanın içsel boşluğunu ve toplumsal yozlaşmayı anlatır.', '65.00', 'assets/uploads/book_69e3f03a57d540.33046403.jpg', 2, 2, '2026-04-18 20:57:30'),
(280, 'Zeno’nun Bilinci', 87, 21, '9789750735890', 'Psikolojik çözümlemeleriyle ünlü bir romandır. Kahramanın kendi hayatını ve alışkanlıklarını sorgulaması anlatılır. Özellikle bilinç akışı tekniğiyle dikkat çeker.', 'Zeno Cosini, psikiyatristinin isteğiyle hayatını yazmaya başlar. Çocukluğu, sigara bağımlılığı, evliliği ve iş yaşamı üzerine düşünür. Sürekli kendini kandırsa da gerçeklerle yüzleşmek zorunda kalır. Böylece insanın kendi iç dünyasını anlamasının ne kadar zor olduğu gösterilir.', '70.00', 'assets/uploads/book_69e3f0ca79baa2.22959116.jpg', 8, 8, '2026-04-18 20:59:15'),
(281, 'Ay ve Şenlik Ateşleri', 88, 1, '9789750738617', 'Uzun yıllar sonra doğduğu köye dönen bir adamın geçmişle yüzleşmesini anlatır. Roman, aidiyet ve yalnızlık temalarını işler. İtalyan taşrasını etkileyici şekilde yansıtır.', 'Amerika’da yıllarca yaşadıktan sonra ülkesine dönen Anguilla, çocukluğunu geçirdiği köye gider. Ancak her şeyin değiştiğini fark eder. Eski arkadaşları, savaşın bıraktığı izler ve kaybolan anılar onun için büyük bir hayal kırıklığı yaratır. Böylece geçmişe dönmenin her zaman mümkün olmadığı anlaşılır.', '40.00', 'assets/uploads/book_69e3f1b288fbd2.54852277.jpg', 12, 12, '2026-04-18 21:03:46'),
(282, 'İpek', 89, 1, '9789750739126', '19.yüzyılda geçen sade ama etkileyici bir aşk hikâyesidir. Kitap kısa olmasına rağmen duygusal yoğunluğu yüksektir. Baricco’nun en tanınmış eserlerinden biridir.', 'Hervé Joncour, ipek böceği yumurtaları bulmak için Japonya’ya giden bir tüccardır. Yolculukları sırasında gizemli bir kadına ilgi duymaya başlar. Bu ilgi zamanla sessiz ama güçlü bir aşka dönüşür. Ancak hiçbir zaman tam anlamıyla yakınlaşamazlar ve hikâye hüzünlü bir şekilde ilerler.', '64.99', 'assets/uploads/book_69e3f2328f8335.25130887.jpg', 7, 7, '2026-04-18 21:05:54'),
(283, 'Ben ve Sen', 93, 1, '9786050912921', 'Yalnız bir gencin kendini keşfetmesini anlatan kısa ve akıcı bir romandır. Özellikle genç okurlar arasında çok sevilmiştir', '14 yaşındaki Lorenzo, arkadaşlarıyla tatile gittiğini söyleyip evlerinin bodrumuna saklanır. Birkaç gün boyunca yalnız kalmak istemektedir. Ancak üvey ablası Olivia da oraya gelir. Birlikte geçirdikleri günler boyunca ikisi de birbirini daha iyi tanımaya başlar.', '55.00', 'assets/uploads/book_69e3f4ae82a4a2.93683814.jpg', 6, 6, '2026-04-18 21:16:30'),
(284, 'Tatar Çölü', 95, 1, '9789750737450', 'Hayatını büyük bir olayın gelmesini bekleyerek geçiren bir askerin hikâyesidir. Beklemek, yalnızlık ve zamanın boşa geçmesi üzerine kuruludur.', 'Subay Giovanni Drogo, uzak bir kaleye atanır. Burada bir gün düşmanın geleceği düşünülmektedir. Drogo kısa süre kalmayı planlasa da yıllarca orada kalır. Sonunda hayatını beklemekle geçirdiğini fark eder.', '30.00', 'assets/uploads/book_69e3f5a6ad1590.88336874.jpg', 6, 6, '2026-04-18 21:20:38'),
(285, 'Magtymguly goşgular', 96, 9, 'ISBN 5-8320-0391-8', 'Bu kitap, Magtymguly Pyragy’nin yazdığı şiirlerden oluşur. Şiirlerde aşk, insan hayatı, ahlak, din ve toplumun sorunları anlatılır. Şair, halkın birlik olması gerektiğini vurgular ve insanlara doğru, dürüst bir yaşam sürmeleri için öğütler verir. Aynı zamanda adaletsizlik ve zor yaşam koşulları da eleştirilir.', 'Bu kitap, Magtymguly Pyragy’nin yazdığı şiirlerden oluşur. Şiirlerde aşk, insan hayatı, ahlak, din ve toplumun sorunları anlatılır. Şair, halkın birlik olması gerektiğini vurgular ve insanlara doğru, dürüst bir yaşam sürmeleri için öğütler verir. Aynı zamanda adaletsizlik ve zor yaşam koşulları da eleştirilir.', '150.00', 'assets/uploads/book_69e7118f03a5a0.83343550.jpg', 1, 0, '2026-04-21 05:56:31'),
(286, 'Kör Baykuş', 97, 1, '9789750800078', 'Modern İran edebiyatının şah eseri kabul edilen bu roman, bir kalemdan nakkaşının afyon ve hayallerle örülü iç dünyasını anlatır. Ölüm, yalnızlık ve varoluş sancılarını sürrealist bir atmosferde işler.', '', '30.00', 'assets/uploads/book_69e7d037631296.25666130.jpg', 3, 3, '2026-04-21 19:29:59'),
(287, 'Şehname', 98, 3, '9786053320296', 'İran’ın ulusal destanıdır. Pers İmparatorluğu\'nun kuruluşundan İslamiyet’in kabulüne kadar olan süreci kahramanlık hikayeleri ve mitolojiyle harmanlayarak anlatan devasa bir manzum eserdir.', 'Firdevsî’nin yaklaşık 30 yılda tamamladığı 60 bin beyitlik devasa eseri Şehnâme, İran’ın mitolojik başlangıcından Sasani İmparatorluğu’nun çöküşüne kadar uzanan binlerce yıllık tarihi epik bir dille anlatır. Eser; medeniyetin doğuşu ve zalim Zahhak’a karşı verilen mücadelelerle başlayan mitolojik, kahraman Rüstem-i Zal’ın Turan ordularına karşı verdiği savaşları ve oğlu Sührab’ı yanlışlıkla öldürmesi gibi trajedileri barındıran destansı ve Büyük İskender’den İslamiyet’in yayılışına kadar olan süreci kapsayan tarihi olmak üzere üç ana bölümden oluşur. Fars dilini ve kültürünü koruma amacıyla saf bir dille kaleme alınan bu epik destan, iyilikle kötülüğün bitmeyen savaşını, adalet kavramını ve kaderin kaçınılmazlığını işleyerek dünya edebiyatının en köklü yapıtlarından biri haline gelmiştir.', '25.00', 'assets/uploads/book_69e7d1d7543559.68560028.jpg', 3, 3, '2026-04-21 19:36:55'),
(288, 'Mesnevi', 99, 4, '9789753443180', 'Farsça kaleme alınmış bu eser, tasavvuf düşüncesinin zirvesidir. Hikayeler üzerinden ahlaki, dini ve felsefi dersler verirken insanın ilahi aşka ulaşma yolculuğunu rehberlik eder.', 'Mevlânâ Celâleddîn-i Rûmî’nin 13. yüzyılda kaleme aldığı, yaklaşık 26.000 beyitten oluşan ve İslam tasavvufunun en önemli başyapıtı sayılan Mesnevi, insanın ilahi aslına dönme arzusunu ve nefsin terbiyesini işleyen didaktik bir eserdir. Ünlü \"Ney\" metaforuyla başlayarak insanın ruhsal ayrılığını ve Tanrı’ya duyduğu aşkı anlatan eser; iç içe geçmiş hikayeler, fıkralar, ayet ve hadis yorumları aracılığıyla ahlaki ve felsefi dersler verir. Sadece bir şiir kitabı değil, aynı zamanda bir yaşam rehberi olan bu eser, evrensel hoşgörüyü ve \"Hamdım, piştim, yandım\" düsturuyla sembolize edilen manevi olgunlaşma sürecini pedagojik bir dille sunarak hem Doğu hem de Batı dünyasında derin izler bırakmıştır.', '50.00', 'assets/uploads/book_69e7d3439646c1.69192330.jpg', 3, 3, '2026-04-21 19:42:59'),
(289, 'Gülistan', 100, 9, '9786053321583', 'Klasik Fars edebiyatının en etkileyici öğretici metinlerinden biridir. Şiir ve nesrin iç içe geçtiği bu eser, adalet, kanaat, sevgi ve edep üzerine bilgece öğütler içeren hikayelerden oluşur.', 'Sadi-i Şirazi’nin 13. yüzyılda kaleme aldığı Gülistan, hem nesir (düz yazı) hem de nazmın (şiir) iç içe geçtiği, İslam edebiyatının en temel ahlak ve edep kitaplarından biridir. Sekiz bölümden oluşan eser; kralların yaşayışından dervişlerin ahlakına, kanaatkârlıktan konuşma adabına ve aşkın doğasına kadar geniş bir yelpazede hikmetli öğütler sunar. Sadi, gerçek yaşamdan gözlemlerini ve seyahatlerinden edindiği tecrübeleri kısa hikayeler, nükteler ve özlü sözler aracılığıyla aktarırken; insan doğasının hem erdemli hem de zayıf yönlerini büyük bir ustalıkla sergiler. Yüzyıllardır bir başucu kitabı olarak kabul edilen Gülistan, sadece bir edebiyat eseri değil, aynı zamanda pratik yaşamda doğruyu ve güzeli bulmayı hedefleyen evrensel bir ahlak rehberidir.', '25.00', 'assets/uploads/book_69e7d3ae8098e0.82824851.jpg', 3, 3, '2026-04-21 19:44:46'),
(290, 'Hafız Divanı', 101, 4, '9786254447471', 'Gazel türünün en büyük ustası Hafız\'ın tüm şiirlerini toplar. Aşk, şarap, rintlik ve mistisizm temalarıyla örülü bu beyitler, İran kültüründe bugün bile fal bakmak için kullanılan kutsal bir değere sahiptir.', '14. yüzyılın en büyük lirik şairi kabul edilen Hafız-ı Şirazi’nin şiirlerinin toplandığı Hafız Divanı, Fars edebiyatının estetik zirvesi ve tasavvufi aşkın en lirik dışavurumudur. Eser, ağırlıklı olarak \"gazel\" formunda yazılmış şiirlerden oluşur ve merkezine ilahi aşk, şarap, gül, bülbül gibi sembollerle örülü derin bir sembolizmi yerleştirir. Hafız; dış görünüşe ve şekilciliğe önem veren zahitleri (sofuları) sert bir dille eleştirirken, samimiyeti ve gönül temizliğini savunur. Şiirlerinde anlam o kadar katmanlıdır ki okuyucu aynı beyitte hem dünyevi bir aşkı hem de Tanrı’ya duyulan derin bir iştiyakı bulabilir. İran kültüründe \"Lisanü’l-Gayb\" (Gizli dillerin sözcüsü) olarak anılan bu divan, sadece edebi bir metin değil, halk arasında niyet tutmak ve geleceğe dair ilham almak için (fâl-i Hafız) başvurulan kutsal bir rehber niteliği taşır.', '20.01', 'assets/uploads/book_69e7d97bcd92c0.64445285.jpg', 3, 3, '2026-04-21 20:09:31'),
(291, 'Suhreverdi\'nin Aklı', 102, 4, '9789753501064', 'İşrakilik felsefesinin kurucusu Suhreverdi\'nin düşüncelerini ve sembolik öykülerini barındırır. Nur (ışık) metaforu üzerinden hakikate giden yolu mistik ve felsefi bir dille açıklar.', 'İşrakilik felsefesinin kurucusu Şihabeddin Sühreverdî’nin düşünce sisteminde akıl, salt rasyonel bir araç olmaktan ziyade \"Nur\" (Işık) metafiziğiyle iç içe geçmiş bir kavramdır. Sühreverdî’ye göre evrenin kaynağı olan \"Nurlar Nuru\"ndan (Zat-ı Bari) sudur eden ilk varlık İlk Akıl’dır ve bu akıl, her biri bir göksel küreye ve birer melekût alemine karşılık gelen bir nurlar zincirini başlatır. Sühreverdî, Aristocu akıl yürütmeyi (meşşai felsefe) yetersiz görerek, gerçek bilgiye ancak aklın \"keşf\" ve \"işrak\" (doğrudan kalbe doğan manevi aydınlanma) ile birleşmesiyle ulaşılabileceğini savunur. Bu sistemde insan aklı, dünyevi karanlıktan kurtulup ilahi ışığa yöneldiği ölçüde \"Kutsal Akıl\" ile temas kurar; dolayısıyla akıl, sadece mantıksal bir süreç değil, ruhun kendi kaynağına, yani nur alemine yaptığı manevi bir yükseliş yolculuğudur.', '25.00', 'assets/uploads/book_69e7da6c68f2e4.61605596.jpg', 9, 9, '2026-04-21 20:13:32'),
(292, 'Savuşun', 103, 1, '9789750531231', 'İran edebiyatında bir kadın yazar tarafından yazılan ilk modern romandır. İkinci Dünya Savaşı sırasında İngiliz işgali altındaki Şiraz\'da geçen hikaye, direnişi ve toplumsal değişimi bir ailenin gözünden anlatır.', 'Eskimo edebiyatının ve Şamanist kültürün izlerini taşıyan, Danimarkalı yazar Jørn Riel tarafından kaleme alınan Savuşun (orijinal adıyla Savage), Kuzey Kutbu’nun sert ve acımasız doğasında hayatta kalmaya çalışan bir grubun fiziksel ve ruhsal mücadelesini anlatır. Hikaye, modern dünyanın karmaşasından uzakta, buzun ve yalnızlığın hüküm sürdüğü bir coğrafyada geçerken; kahramanların doğayla, açlıkla ve kendi iç dünyalarındaki \"vahşilikle\" yüzleşmelerini odağa alır. Eser, sömürgecilikten ziyade insanın en saf haliyle hayatta kalma güdüsünü, dostluğu ve doğanın karşısında insanın ne kadar küçük ama bir o kadar da dirençli olduğunu işler. Kitap, kendine has mizahı ve trajik unsurları harmanlayarak, medeniyetin dayattığı maskelerden sıyrılan insanın nasıl özüne yani \"savuşuna\" (vahşiliğine) döndüğünü etkileyici bir atmosferle sunar.', '30.00', 'assets/uploads/book_69e7daea565002.02740222.jpg', 5, 5, '2026-04-21 20:15:38'),
(293, 'Huzur Huzursuzluk', 104, 6, '9786055107932', 'İran\'ın Çehov\'u olarak bilinen yazarın etkileyici öykülerini içerir. Köy yaşamındaki batıl inançları, yoksulluğu ve psikolojik gerilimleri gerçekçi ama bir o kadar da tekinsiz bir dille aktarır.', 'Modern İran edebiyatının en önemli isimlerinden biri olan Gulam Hüseyin Sâedi’nin (Gevher Murad) eseri bağlamında sorduğunuz Huzur ve Huzursuzluk (bazı çevirilerde Tedirginlik veya Endişe olarak da geçebilir), yazarın toplumsal gerçekçilik ile psikolojik derinliği harmanladığı öykü ve oyunlarında sıkça işlediği bir temadır. Sâedi, bir psikiyatrist olmasının da etkisiyle, özellikle kırsal kesimdeki yoksul insanların batıl inançlar, cehalet ve ekonomik çaresizlik kıskacında yaşadıkları o bitmek bilmeyen \"huzursuzluk\" halini anlatır. Yazarın en bilinen eserlerinden biri olan Korku ve Titreme (Ters u Larz) bu \"huzur bulamama\" halinin zirvesidir; Basra Körfezi kıyısındaki ıssız bir köyde yaşayan insanların, bilmedikleri dış dünyadan veya doğaüstü sanılan olaylardan duydukları kolektif dehşeti ve bunun yarattığı derin toplumsal felci ele alır.', '25.00', 'assets/uploads/book_69e7db7af26fa9.16826298.jpg', 2, 2, '2026-04-21 20:18:03'),
(294, 'Herat\'ın Geceleri', 105, 17, '9789753554169', 'İranlı düşünür Şeriati\'nin yalnızlık ve varoluş üzerine kaleme aldığı edebi yönü güçlü metinlerdir. Çöl metaforu üzerinden insanın modern dünyadaki yabancılaşmasını ve özgürlük arayışını sorgular.', 'Afgan edebiyatının güçlü kalemlerinden Asıf Sultan-zâde\'nin (Asif Soltanzadeh) öykülerini içeren Herat’ın Geceleri, savaşın gölgesinde parçalanmış hayatları, göçü ve insanın en temel varoluş sancılarını sarsıcı bir dille anlatır. Kitaptaki öyküler, Afganistan\'ın yakın tarihindeki yıkımlardan kaçıp İran’a sığınan göçmenlerin maruz kaldığı dışlanmışlığı, kimlik kaybını ve geçmişin hayaletleriyle olan bitmek bilmeyen hesaplaşmalarını odağına alır. Sultan-zâde, sadece fiziksel bir savaşı değil, aynı zamanda karakterlerin iç dünyasındaki derin yaraları, geleneklerin ağırlığını ve adaletsizliği gerçeküstü unsurlarla harmanlanmış bir gerçekçilikle sunar. Eser, ismini aldığı o puslu ve karanlık Herat geceleri gibi, okuyucuyu hüzünlü bir coğrafyanın kaderine ortak ederken, en zorlu koşullarda bile insanın hayata tutunma çabasını ve hafızanın hem bir sığınak hem de bir hapishane oluşunu ustalıkla işler.', '10.00', 'assets/uploads/book_69e7dc216861f7.12336797.png', 1, 1, '2026-04-21 20:20:49'),
(295, 'Albay', 106, 1, '9786053607069', '1979 Devrimi sonrasında geçen, bir gecelik bir zaman dilimine sığdırılmış sarsıcı bir aile trajedisidir. İran\'ın yakın tarihindeki siyasi çalkantıları ve bu süreçte yok olan hayatları simgesel bir dille ele alır.', 'Mahmud Devletabadi’nin İran’da uzun süre yasaklı kalan ve dünya edebiyatında geniş yankı uyandıran başyapıtı Albay, İran’ın yakın tarihini bir ailenin trajedisi üzerinden anlatan sarsıcı bir dramdır. Roman, bir yağmurlu gecede iki polisin Albay’ın kapısını çalıp, işkenceyle öldürülen en küçük kızının cesedini teslim etmeleri ve onu gizlice gömmesini emretmeleriyle başlar. Albay, kızını defnetmek için çıktığı bu karanlık yolculukta; farklı siyasi görüşlere savrularak kimi infaz edilen, kimi hapse düşen, kimi de akıl sağlığını yitiren beş çocuğunun ve kendi geçmişinin muhasebesini yapar. Şah döneminin baskılarından 1979 Devrimi’ne ve sonrasındaki iç karışıklıklara kadar uzanan süreçte, bir babanın evlatlarını ideolojilere kurban vermesini işleyen eser; devrimin kendi çocuklarını yiyen acımasız yüzünü, vatan sevgisinin yarattığı hayal kırıklığını ve bir ulusun yaşadığı toplumsal travmayı Albay’ın vicdan azabı ve anıları eşliğinde derinden hissettirir.', '60.00', 'assets/uploads/book_69e7dc810269d3.11226540.jpg', 4, 4, '2026-04-21 20:22:25'),
(296, 'Benim Payım', 107, 10, '9786054454792', 'Yasaklandığı dönemlerde bile elden ele dolaşan bu roman, İranlı bir kadının çocukluğundan yaşlılığına kadar olan hayat mücadelesini anlatır. Geleneklerin ve siyasi baskıların gölgesinde kadının konumunu sorgular.', 'Parinoush Saniee’nin kaleminden çıkan ve İran’da defalarca yasaklanmasına rağmen fenomen haline gelen Benim Payım, 1979 Devrimi öncesi ve sonrası İran’da bir kadının var olma mücadelesini Masume karakterinin gözünden anlatan sarsıcı bir hayat hikayesidir. Henüz genç bir kızken kalbini bir eczacı çırağına kaptıran Masume, ailesinin bu durumu \"namus meselesi\" yapması üzerine şiddet görür ve tanımadığı, devrimci fikirleri olan bir adamla zorla evlendirilir. Roman, Masume\'nin ideolojik çatışmaların ortasında kalan eşi, hapse düşen akrabaları ve büyütmeye çalıştığı çocukları arasında geçen yarım asırlık ömrünü anlatırken; kadının kendi arzularından vazgeçip sürekli başkaları (babası, abileri, kocası ve çocukları) için \"feda edilen\" payına odaklanır. Masume’nin yaşlılığında bile kendi mutluluğunu seçmeye çalıştığında çocukları tarafından engellenmesi, toplumsal baskının ve ataerkil yapının kuşaklar boyu nasıl değişmediğini trajik bir şekilde gözler önüne serer. Eser, sadece bir kadının biyografisi değil, aynı zamanda İran’ın siyasi dönüşümünün aileler ve özellikle kadınlar üzerindeki yıkıcı etkisinin sosyolojik bir vesikasıdır.', '70.00', 'assets/uploads/book_69e7e76e25c493.52392623.jpg', 7, 7, '2026-04-21 21:09:02'),
(297, 'Mantıku\'t Tayr', 108, 4, '9789753551526', 'Kuşların padişahı Simurg\'u bulmak için çıktıkları yolculuğu anlatan sembolik bir mesnevidir. Yedi vadiden geçerek özünü keşfeden kuşların hikayesi, tasavvuftaki nefis terbiyesini temsil eder.', 'Feridüddin Attâr’ın 12. yüzyılda kaleme aldığı Mantıku’t Tayr (Kuşların Dili), tasavvuf edebiyatının en önemli alegorik eserlerinden biridir ve ruhun Allah’a olan manevi yolculuğunu kuşlar üzerinden anlatır. Dünyadaki tüm kuşlar, kendilerine bir padişah seçmek amacıyla toplanırlar ve bilge Hüthüt kuşunun rehberliğinde, efsanevi padişah Simurg’u bulmak için zorlu bir yolculuğa çıkarlar. Bu yolculuk sırasında kuşların birçoğu yorulup geri dönmek için çeşitli bahaneler uretir (kimi nefsine, kimi malına, kimi de sevgilisine takılır); ancak Hüthüt, her birine tasavvufi hakikatlerle cevap vererek onları ikna eder.\r\n\r\nYolculuğun en can alıcı kısmı, aşılması gereken yedi zorlu vadidir: İstek, Aşk, Marifet, İstigna (İhtiyaçsızlık), Tevhid, Hayret ve son olarak Yokluk (Fena) vadileri. Bu vadileri aşabilen sadece otuz kuş kalır; Kaf Dağı’na ulaşıp Simurg’un huzuruna çıktıklarında ise gördükleri manzara karşısında hayrete düşerler. \"Simurg\" kelime anlamı olarak Farsça \"si\" (otuz) ve \"murg\" (kuş) demektir; yani aslında aradıkları yüce varlığın, yansıyan kendi hakikatleri olduğunu anlarlar. Eser, \"kendini bilen Rabbini bilir\" düsturuyla, insanın ilahi özü kendi içinde bulacağı mesajıyla sona erer.', '80.00', 'assets/uploads/book_69e7e7d76182e0.41945976.jpg', 3, 3, '2026-04-21 21:10:47'),
(298, 'Küçük Kara Balık', 109, 17, '9786051416731', 'Çocuk kitabı görünümünde olsa da her yaştan okura hitap eden politik bir alegoridir. Kendi dünyasının sınırlarını aşmak isteyen küçük bir balığın özgürlük, cesaret ve fedakarlık dolu yolculuğunu anlatır.', 'Samed Behrengi’nin sadece çocuklara değil, yetişkinlere de hitap eden dünyaca ünlü eseri Küçük Kara Balık, kurulu düzenin sınırlarını zorlayan ve özgürlük arayışından vazgeçmeyen bir bireyin sembolik hikâyesidir. Yaşadığı küçük derede her gün aynı şeyleri yapmaktan sıkılan ve \"Dünya sadece bu dereden mi ibaret, yoksa başka bir sonu var mı?\" sorusunun peşine düşen Küçük Kara Balık, çevresindeki tüm balıkların ve muhafazakâr ailesinin \"tehlikeli, imkânsız\" uyarılarına rağmen denize ulaşmak için yola çıkar.\r\n\r\nYolculuğu boyunca kurbağalar, yengeçler ve kendisini yutmaya çalışan balıkçıllar gibi pek çok engelle karşılaşan kahramanımız, her adımda hayatın zorluklarını, dayanışmayı ve adaletsizliği öğrenir. Bir balıkçıl kuşunun midesindeyken bile teslim olmayıp yanındaki küçük balığı kurtararak fedakârlığın en büyüğünü sergiler. Eser, Küçük Kara Balık\'ın büyük denize ulaşıp ulaşmadığını bir gizem olarak bıraksa da, onun cesaret dolu hikâyesinin deredeki diğer on iki bin küçük balığın uykusunu kaçırmasıyla biter; bu da düşüncenin ve uyanışın bir kez başladığında asla durdurulamayacağını simgeler.', '15.00', 'assets/uploads/book_69e7e83ead36e7.94577879.jpg', 10, 10, '2026-04-21 21:12:30'),
(299, 'Hümayunname', 110, 4, '9786057639141', 'Beş büyük mesneviden oluşan \"Hamse\"nin bir parçasıdır. Klasik aşk hikayelerini derin bir psikolojik çözümleme ve felsefi alt metinlerle anlatarak yüzyıllarca Doğu edebiyatını etkilemiştir.', 'Eser, temelde devlet yönetimi, siyaset ve ahlak üzerine kurulu olup, hayvanların kahraman olduğu iç içe geçmiş alegorik hikâyeler aracılığıyla yöneticilere ve halka adalet, sadakat, basiret ve ihtiyat dersleri verir. Ali Çelebi, çeviri yaparken esere kendi edebi gücünü katmış; dönemin ağır ve süslü nesir üslubuyla hikâyeleri genişleterek eseri adeta bir \"siyasetname\" niteliğine büründürmüştür. Padişaha devlet idaresinde rehberlik etmesi amacıyla kaleme alınan Hümayunname, yüzyıllar boyunca Osmanlı bürokratları ve aydınları için hem bir ahlak el kitabı hem de belagat (güzel konuşma ve yazma) örneği olarak kabul edilmiştir. Kısaca eser; aslan (hükümdar), çakallar (vezirler/danışmanlar) ve diğer hayvanlar üzerinden insan karakterinin karmaşıklığını ve iktidar ilişkilerinin inceliklerini anlatan bir hikmetler hazinesidir.', '25.00', 'assets/uploads/book_69e7e903c206b7.25704254.jpg', 3, 3, '2026-04-21 21:15:47'),
(300, 'Leyla İle Mecnun', 111, 1, '9789753330657', 'Fars edebiyatının beş mücevheri olarak bilinen \"Hamse\"nin en ünlü parçasıdır. Beşerî aşkın ilahi aşka dönüşümünü anlatan bu epik eser, sadece İran değil, tüm Doğu edebiyatındaki aşk anlatılarını derinden etkilemiştir.', 'Nizamî Gencevî’nin 12. yüzyılda kaleme aldığı ve bu ünlü aşk hikâyesini ilk kez müstakil bir eser olarak destanlaştıran Leyla ile Mecnun, Arap yarımadasında doğan bir halk anlatısını yüksek bir edebiyat ve felsefe seviyesine taşır. Hikâye, Necid çöllerinde yaşayan iki kabile reisinin çocukları olan Kays ve Leyla’nın okulda birbirlerine aşık olmalarıyla başlar; ancak bu aşkın dilden dile yayılması üzerine Leyla’nın babası, \"namus\" gerekçesiyle kızını okuldan alır ve Kays’ın evlilik teklifini reddeder. Sevdiğine kavuşamayan Kays, acısından akli dengesini yitirerek çöllere düşer ve vahşi hayvanlarla dostluk kuran, \"çılgın\" anlamına gelen Mecnun lakabıyla anılmaya başlar.\r\n\r\nLeyla, istemediği bir adamla (İbn-i Selam) evlendirilse de kalbi hep Mecnun’da kalır ve evlendiği adama asla dokunmaz. Mecnun ise çölde maddi aşktan sıyrılıp, Leyla’yı artık ilahi bir tecelli olarak görmeye başladığı tasavvufi bir boyuta geçer; öyle ki Leyla karşısına geldiğinde bile \"Sen bendeki Leyla isen bu gelen kim, eğer o isen ben kimim?\" diyecek kadar kendinden geçer. Trajik bir sonla biten eserde, önce Leyla üzüntüden ölür; Mecnun ise onun mezarı başında can verir. Nizamî’nin bu eseri, aşkı sadece bir beşerî duygu değil, ruhun kemale erme ve Allah’a ulaşma yolculuğu olarak işleyerek kendisinden sonra gelen Fuzulî gibi pek çok şairi derinden etkilemiştir.', '100.00', 'assets/uploads/book_69e7e9d7b591a6.14715178.jpg', 1, 1, '2026-04-21 21:19:19'),
(301, 'Siyasetname', 112, 3, '9789752981324', 'Büyük Selçuklu İmparatorluğu\'nun ünlü veziri tarafından kaleme alınmış bir devlet yönetimi rehberidir. Adalet, devlet yapısı ve hükümdarlık vasıfları üzerine verilen öğütler, tarihi anekdotlarla harmanlanarak sunulur.', 'Büyük Selçuklu İmparatorluğu\'nun efsanevi veziri Nizamülmülk tarafından Sultan Melikşah\'a sunulmak üzere kaleme alınan Siyasetnâme, Türk-İslam devlet geleneğinin temel taşlarını ve ideal bir hükümdarın vasıflarını belirleyen kapsamlı bir yönetim rehberidir. Eser, devletin bekasının ancak \"adalet\" ile mümkün olabileceğini, zulmün ise iktidarı temelinden sarsacağını savunurken; güçlü bir merkezi otorite, liyakate dayalı bürokrasi ve etkin bir istihbarat teşkilatının gerekliliğini yaşanmış tarihi olaylar ve kıssalarla temellendirir. Memur atamalarından ordunun düzenine, halkın şikâyetlerinin bizzat dinlenmesinden Batınîlik gibi iç tehditlerle mücadeleye kadar geniş bir yelpazede stratejik tavsiyeler sunan kitap, sadece bir siyaset kuramı metni değil, aynı zamanda yüzyıllarca Osmanlı dahil pek çok devletin yönetim felsefesini şekillendiren pratik bir anayasa taslağı niteliği taşır.', '75.00', 'assets/uploads/book_69e7ea55da24c0.24630037.jpg', 6, 6, '2026-04-21 21:21:26'),
(302, 'İçimdeki Kız', 113, 1, '9786257608596', 'Çağdaş İran edebiyatının ödüllü yazarlarından Rukiye Kebiri’nin bu eseri, on altı kısa öyküden oluşur. Kitap, farklı karakterlere sahip kadınların dünyasına odaklanarak onların yaşam mücadelelerini, umutlarını ve içsel yolculuklarını derinlemesine ve etkileyici bir dille ele alır.', 'Rukiye Kebîri’nin modern İran ve Güney Azerbaycan edebiyatında yankı uyandıran eseri İçimdeki Kız, bir kadının toplumsal baskılar, gelenekler ve ataerkil yapının yarattığı engeller karşısında kendi kimliğini ve özgürlüğünü bulma çabasını lirik ve sembolik bir dille anlatır. Roman, kahramanın iç dünyasındaki karmaşayı ve susturulmuş duygularını \"içindeki kız\" metaforu üzerinden somutlaştırırken; çocukluktan yetişkinliğe uzanan süreçte kadın olmanın getirdiği yükleri, bastırılmış arzuları ve toplumsal normların birey üzerindeki yıkıcı etkisini derin bir psikolojik tahlille ele alır. Yazar, sadece bireysel bir hikâye sunmakla kalmayıp, aynı zamanda coğrafyanın kültürel kodlarını ve dilin sınırlamalarını da sorgulayarak, sessizliğe zorlanan bir kadının kendi sesini keşfetme yolculuğunu cesur ve etkileyici bir atmosferle okuyucuya sunar.', '45.00', 'assets/uploads/book_69e7ec48e4dfb0.94631506.jpg', 10, 10, '2026-04-21 21:29:45'),
(303, 'Erkeksiz Kadınlar', 114, 1, '9789750530746', 'İran edebiyatının en önemli modern klasiklerinden biri olan bu eser, farklı toplumsal sınıflardan gelen beş kadının hayatının \"bahçe\" metaforu etrafında kesişmesini anlatır. Büyülü gerçekçilik ögeleriyle bezeli roman; özgürlük, cinsellik ve kadın kimliği gibi konuları baskıcı bir toplumsal yapının içinde sorguladığı için uzun yıllar İran\'da yasaklı kalmıştır.', 'İranlı yazar Şehrnuş Parsipur’un 1989 yılında yayımlanan ve yayımlandıktan kısa bir süre sonra İran\'da yasaklanan kültürel devrim niteliğindeki eseri Erkeksiz Kadınlar, farklı toplumsal sınıflardan gelen beş kadının hayatlarının, Tahran yakınlarındaki Karaj’da bulunan mistik bir bahçede kesişmesini anlatan büyülü gerçekçi bir romandır. Orta yaşlı bir ev hanımı olan Munis, bekâret takıntısı ve baskıcı erkek kardeşiyle boğulan Faize, fahişelik yapan Zerrinkülah, evde kalmış olan Ferruhliğa ve özgür ruhlu Mahduht; ataerkil toplumun dayattığı şiddet, tecavüz ve hapis hayatından kaçarak bu metaforik bahçeye sığınırlar. Parsipur, kadınların bu bahçede kendi kimliklerini, bedenlerini ve arzularını keşfetme süreçlerini anlatırken; bekâret tabusu üzerinden kadının toplumsal konumunu sarsıcı bir dille eleştirir ve karakterlerin ağaca dönüşmek gibi fantastik dönüşümler geçirmesiyle özgürleşme isteğini gerçeküstü bir boyuta taşır. Eser, kadınların erkek egemen sistemin baskısından kurtulup bir dayanışma alanı yaratma çabasını işleyen, hem siyasi hem de feminist bir manifesto niteliği taşımaktadır.', '50.00', 'assets/uploads/book_69e7ed1df002f9.85788741.jpg', 5, 5, '2026-04-21 21:33:18'),
(304, 'Suç ve Ceza', 115, 24, '9789750739156', 'Psikolojik, Polisiye ve Felsefi Roman türünde bir dünya klasiğidir', 'Maddi zorluklar çeken hukuk öğrencisi Raskolnikov, \"üstün insan\" teorisini kanıtlamak için bir tefeciyi öldürür. Ancak cinayet sonrası yaşadığı ağır vicdan azabı ve toplumsal baskı, onu ruhsal bir çöküşe sürükler. Roman, suçun psikolojisini ve vicdanın mahkemesini derinlemesine işler.', '34.99', 'assets/uploads/book_69e9e88494c8f1.53946372.jpg', 5, 5, '2026-04-23 09:38:11'),
(305, 'Anna Karenina', 116, 1, '9789750506314', 'Sosyal Dram ve Romantik Trajedi türünde bir eserdir.', 'Aristokrat Anna\'nın, Kont Vronski ile yaşadığı yasak aşk nedeniyle toplumdan dışlanışını anlatır. Anna\'nın trajik yıkımı ile çiftçi Levin\'in anlam arayışı içindeki huzurlu hayatı karşılaştırılarak; sadakat, aile ve toplumsal ikiyüzlülük temaları işlenir.', '44.99', 'assets/uploads/book_69e9e9f8914499.00779819.jpg', 8, 8, '2026-04-23 09:44:23'),
(306, 'Karamazov Kardeşler', 115, 4, '9789750510526', 'Felsefi, Aile Dramı ve Psikolojik Roman türünde bir başyapıttır.', 'Bir baba cinayeti etrafında şekillenen hikaye; inançlı Alyoşa, ateist İvan ve tutkulu Dimitri üzerinden insan ruhunun en karanlık ve en aydınlık köşelerini keşfeder. Tanrı\'nın varlığı, adalet ve ahlak kavramları üzerine edebiyat tarihinin en derin tartışmalarını sunar.', '45.00', 'assets/uploads/book_69e9eaea626d45.53697246.webp', 7, 7, '2026-04-23 09:48:25'),
(307, 'Savaş ve Barış', 116, 25, '9786053321552', 'Tarihi, Epik ve Dram türünde yazılmış dev bir dünya klasiğidir.', 'Napolyon\'un Rusya işgali döneminde beş soylu ailenin kaderini ele alır. Savaşın dehşeti ile Moskova ve Petersburg\'un ihtişamlı salon hayatı arasındaki zıtlığı işleyen eser, tarihin akışını ve bireyin bu akıştaki rolünü felsefi bir derinlikle sorgular.', '50.00', 'assets/uploads/book_69e9eb75695e38.03872200.jpg', 5, 5, '2026-04-23 09:50:44'),
(308, 'Babalar ve Oğullar', 117, 26, '9789750739163', 'Fikir Romanı ve Sosyal Eleştiri türünde bir klasiktir.', 'Nihilist genç Bazarov ile geleneksel değerlere bağlı eski kuşak arasındaki çatışmayı konu alır. Rusya\'nın değişim sancılarını ve gençliğin otoriteye olan başkaldırısını anlatan eser, nihilizm kavramının dünya edebiyatındaki en güçlü temsilidir.', '25.00', 'assets/uploads/book_69e9ec0ef11128.78514319.jpg', 6, 6, '2026-04-23 09:53:18'),
(309, 'Ölü Canlar', 118, 27, '9789754580556', 'Satirik (Hiciv) ve Sosyal Eleştiri türünde bir romandır.', 'Çiçikov adındaki kurnaz bir adamın, vergi oyunları yapmak için ölmüş kölelerin haklarını satın alarak Rus taşrasını dolaşmasını anlatır. Bu yolculuk sırasında karşılaştığı karakterler üzerinden Rus bürokrasisi ve taşra hayatı sert bir dille eleştirilir.', '30.00', 'assets/uploads/book_69e9ec7d42b570.07741286.jpg', 4, 4, '2026-04-23 09:55:08'),
(310, 'Usta ve Margarita', 119, 28, '9789750731051', 'Büyülü Gerçekçilik, Fantastik ve Politik Hiciv türündedir.', 'Şeytan\'ın 1930\'ların Sovyet Moskova\'sına yaptığı ziyaretle başlayan olaylar zinciridir. Bir yanda baskıcı rejimin saçmalıkları hicvedilirken, diğer yanda bir yazarın (Usta) ve sevgilisinin (Margarita) sonsuz aşkı fantastik bir atmosferde anlatılır.', '35.00', 'assets/uploads/book_69e9ed107ab046.38395507.jpg', 5, 5, '2026-04-23 09:57:35'),
(311, 'Oblomov', 117, 26, '9789754586947', 'Psikolojik ve Sosyal Dram türünde bir karakter romanıdır', 'Hayatın getirdiği sorumluluklardan kaçan ve günlerini yatağında hayal kurarak geçiren İlya İlyiç Oblomov\'un hikayesidir. Karakterin içindeki uyuşukluk ve eylemsizlik, hem bireysel bir trajediyi hem de çökmekte olan bir sınıfı temsil eder.', '30.00', 'assets/uploads/book_69e9edd16a61f5.70904753.jpg', 6, 6, '2026-04-23 10:00:48'),
(312, 'Palto', 118, 29, '9786051717272', 'Sosyal Gerçekçi ve Dram türünde bir uzun öyküdür.', 'Sıradan bir memur olan Akakiy Akakiyeviç\'in, zar zor diktirdiği yeni paltosunun çalınmasıyla yıkılan dünyasını anlatır. \"Küçük insan\"ın toplumdaki çaresizliğini ve sistemin acımasızlığını işleyen en etkileyici Rus eserlerinden biridir.', '20.00', NULL, 10, 10, '2026-04-23 10:05:01'),
(313, 'Yeraltından Notlar', 115, 4, '9786053321156', 'Varoluşçu ve Psikolojik Roman türünde bir başyapıttır.', 'Modern bireyin toplumdan kopuşunu ve kendi \"yeraltı\" dünyasında verdiği iç savaşı konu alır. İnsanın rasyonel olmadığını, aksine kendi zararına bile olsa özgürce hareket etmek istediğini savunan sarsıcı bir iç dökümdür.', '25.00', 'assets/uploads/book_69e9f1825f67a6.27667745.jpg', 12, 12, '2026-04-23 10:16:33'),
(314, 'Kumarbaz', 115, 26, '9786053320142', 'Psikolojik Dram ve Sosyal Roman türündedir.', 'Aleksey İvanoviç\'in bir aile yanında çalışırken rulet masasına ve tutkulu bir aşka olan bağımlılığını anlatır. Kumar hırsının insan iradesini nasıl ele geçirdiğini ve mantığın bittiği noktayı muazzam bir gözlemle sunar.', '25.00', 'assets/uploads/book_69e9f6fda330e1.48356301.jpg', 5, 5, '2026-04-23 10:39:57'),
(315, 'Doktor Jivago', 40, 1, '9789750808586', 'Tarihi Dram, Epik ve Romantik türde bir eserdir.', 'Rus Devrimi\'nin kaosunda şair ve doktor olan Yuri Jivago\'nun hayatını, savaşın ortasındaki büyük aşkı Lara\'yı ve değişen dünya düzeninde bireyin ruhunu koruma çabasını işleyen epik bir romandır.', '40.00', 'assets/uploads/book_69e9f79bc12ef6.05298022.jpg', 3, 3, '2026-04-23 10:42:35'),
(316, 'Biz', 122, 30, '9786053754909', 'Bilimkurgu ve Distopya türünde öncü bir eserdir.', 'İnsanların numara olarak görüldüğü, her şeyin şeffaf olduğu totaliter bir gelecekte geçer. Mühendis D-503\'ün bir kadına aşık olmasıyla başlayan hayal gücü uyanışını ve sisteme karşı verdiği bireysel mücadeleyi anlatır.', '30.00', 'assets/uploads/book_69e9f809040b08.00010591.webp', 5, 5, '2026-04-23 10:44:24'),
(317, 'Diriliş', 116, 26, '9789754580570', 'Sosyal Eleştiri ve Dram türünde bir romandır.', 'Prens Nehludov\'un, bir mahkemede jüri üyesiyken, haksız yere suçlanan eski sevgilisi Katyuşa\'yı görmesiyle başlar. Nehludov\'un vicdan azabı ve ruhsal uyanışı üzerinden Rus hukuk ve kilise sistemi eleştirilir.', '35.00', 'assets/uploads/book_69e9f8841931b6.46008895.jpg', 4, 4, '2026-04-23 10:46:27'),
(318, 'İnsancıklar', 115, 31, '9789750724596', 'Mektup Roman ve Sosyal Dram türündedir.', 'Fakir memur Makar ile genç Varenka\'nın yoksulluk içindeki yaşamlarını ve birbirlerine olan masum sevgilerini mektuplar aracılığıyla anlatır. Dostoyevski\'nin ilk eseri olup \"küçük insan\"ın onur mücadelesini yansıtır.', '20.00', 'assets/uploads/book_69e9f8e69f32a8.75742634.jpg', 6, 6, '2026-04-23 10:48:06'),
(319, 'Vişne Bahçesi', 123, 16, '9789754581249', 'Dram ve Komedi öğeleri içeren bir Tiyatro Oyunudur.', 'Köklü ama borç içindeki bir asilzade ailesinin, çocukluk anılarıyla dolu vişne bahçesinin satılmasını engelleyemeyişini anlatır. Eski düzenin çöküşü ile yeni tüccar sınıfın yükselişini hüzünlü ve mizahi bir dille işler.', '15.00', 'assets/uploads/book_69e9f98ebdca86.93976999.jpg', 3, 3, '2026-04-23 10:50:54'),
(320, 'Bir Delinin Hatıra Defteri', 118, 29, '9789754580587', 'Psikolojik ve Satirik türde bir uzun öyküdür.', 'Küçük bir memurun platonik aşkı ve hiyerarşik sistemdeki ezilmişliği sonucu akıl sağlığını yitirmesini konu alır. Kendini İspanya Kralı sanmaya başlamasıyla gelişen delilik süreci, toplumsal statü saplantısını eleştirir.', '20.00', 'assets/uploads/book_69ea113f3d2074.17161371.jpg', 5, 5, '2026-04-23 12:31:59'),
(321, 'Yüzbaşının Kızı', 124, 25, '9789754586923', 'Tarihi Roman ve Macera türündedir.', 'Pugatçov ayaklanması sırasında geçen bir aşk ve onur hikayesidir. Genç subay Pyotr Grinyov\'un hem devlete olan sadakati hem de sevdiği kadını korumak için girdiği mücadeleyi Puşkin\'in sade diliyle anlatır.', '25.00', 'assets/uploads/book_69ea11994b41d4.33124784.jpg', 5, 5, '2026-04-23 12:33:29');
INSERT INTO `books` (`id`, `title`, `author_id`, `category_id`, `isbn`, `description`, `summary`, `price`, `image_path`, `total_copies`, `available_copies`, `created_at`) VALUES
(322, 'İvan İlyiç\'in Ölümü', 116, 26, '9786053322146', 'Psikolojik Dram ve Felsefi türde bir eserdir.', 'Başarılı bir yargıç olan İvan İlyiç\'in, hastalığı sırasında ölümle burun buruna gelmesini anlatır. Hayatı boyunca önemli sandığı unvan ve eşyaların ölüm karşısında ne kadar anlamsız olduğunu keşfedişini sarsıcı bir dille aktarır.', '15.00', 'assets/uploads/book_69ea11f06be199.23761871.jpg', 6, 6, '2026-04-23 12:34:56'),
(323, 'Petersburg Hikâyeleri', 118, 29, '9789750504785', 'Sosyal Eleştiri, Fantastik ve Dram türündeki hikayeler bütünüdür.', 'Petersburg\'un sisli sokaklarında geçen; Burun, Palto gibi ünlü hikayeleri barındıran bir eserdir. Gerçeklik ile hayalin iç içe geçtiği bu hikayelerde, şehir hayatının insan ruhu üzerindeki grotesk etkileri anlatılır.', '25.00', 'assets/uploads/book_69ea128d007be9.46513303.jpg', 4, 4, '2026-04-23 12:37:33'),
(324, 'İnce Memed', 125, 1, '9789750803774', 'Anadolu’da ağalık düzenine başkaldıran bir gencin hikâyesidir. Toplumsal adaletsizlik güçlü bir dille anlatılır. Türk edebiyatının en önemli eserlerinden biridir.', 'Memed, zalim Abdi Ağa’nın baskılarından kaçarak eşkıya olur. Ancak amacı sadece kaçmak değil adaleti sağlamaktır. Köylüler için bir umut haline gelir. Bireysel başkaldırı ile toplumsal direniş iç içe işlenir.', '45.00', 'assets/uploads/book_69ea836006a0a8.38227021.jpg', 25, 25, '2026-04-23 20:38:55'),
(325, 'Tutunamayanlar', 126, 1, '9789754700116', 'Modern bireyin yalnızlığı ve toplumla uyumsuzluğu derinlemesine ele alınır. Postmodern anlatım teknikleri kullanılmıştır. Dil ve kurgu açısından oldukça yenilikçi bir eserdir. Yer yer mizahi, yer yer trajik bir ton hâkimdir. Okuyucuyu düşünmeye zorlayan bir yapıya sahiptir. Türk edebiyatında kült statüsündedir.', 'Turgut Özben, yakın arkadaşı Selim Işık’ın intihar haberini aldıktan sonra onun hayatını araştırmaya başlar. Bu süreçte Selim’in düşünce dünyası, hayal kırıklıkları ve toplumla olan çatışmaları ortaya çıkar. Turgut, Selim’i anlamaya çalışırken aslında kendi hayatını da sorgulamaya başlar. Roman boyunca farklı anlatım teknikleri ve metinler kullanılır. Bireyin toplum içindeki yabancılaşması, kimlik arayışı ve varoluşsal sorgulamaları ön plana çıkar. Sonunda Turgut’un da bir dönüşüm geçirdiği görülür.', '75.00', 'assets/uploads/book_69ea8410a0c8a7.37539925.webp', 21, 21, '2026-04-23 20:41:52'),
(326, 'Saatleri Ayarlama Enstitüsü', 127, 1, '9789753638021', 'Doğu ile Batı arasındaki kültürel çatışma ironik bir şekilde ele alınır. Bürokrasi ve modernleşme eleştirilir. Mizahi diliyle dikkat çeker. Toplumsal yapının absürtlüğü gözler önüne serilir. Oldukça özgün bir kurguya sahiptir. Düşündürürken güldüren bir romandır.', 'Hayri İrdal’ın sıradan hayatı, Halit Ayarcı ile tanışmasıyla değişir. Birlikte “Saatleri Ayarlama Enstitüsü” adlı garip bir kurum kurarlar. Bu kurum, aslında modernleşmenin anlamsız yönlerini temsil eder. Hayri’nin geçmişi, anıları ve çevresi üzerinden toplumun değişimi anlatılır. Enstitü büyüdükçe işler daha da absürt bir hal alır. Roman, bireyin modern dünyadaki yerini sorgularken aynı zamanda toplumsal eleştiri sunar.', '45.00', 'assets/uploads/book_69ea84a97a62a6.56805751.jpg', 17, 17, '2026-04-23 20:44:25'),
(327, 'Safahat', 128, 9, '9789754379027', 'Toplumsal sorunları ve ahlaki değerleri şiirlerle anlatır. Dönemin sosyal yapısını yansıtır. Didaktik yönü güçlüdür. Dili sade ve etkilidir. Milli ve manevi değerleri ön plana çıkarır. Türk şiirinin önemli eserlerindendir.', 'Safahat, farklı şiir kitaplarından oluşan bir külliyattır. Mehmet Akif, toplumun sorunlarını, yoksulluğu ve ahlaki çöküşü eleştirir. Aynı zamanda umut ve direniş mesajları verir. Şiirlerde birey ve toplum ilişkisi işlenir. Milli mücadele ruhu hissedilir. Eser, dönemin panoramasını sunar.', '35.00', 'assets/uploads/book_69ea8539c0ca68.68338175.jpg', 12, 12, '2026-04-23 20:46:49'),
(328, 'Nutuk', 129, 32, '9789751601881', 'Türkiye Cumhuriyeti’nin kuruluş sürecini anlatır. Tarihi bir belgedir. Açık ve etkileyici bir anlatımı vardır. Liderlik ve strateji açısından önemlidir. Milli mücadele sürecini detaylı aktarır. Temel eserlerden biridir.', 'Atatürk, Samsun’a çıkıştan Cumhuriyet’in ilanına kadar olan süreci anlatır. Yaşanan zorluklar, savaşlar ve alınan kararlar detaylı şekilde aktarılır. Milli mücadelenin nasıl kazanıldığı açıklanır. Aynı zamanda gençliğe hitap edilir. Eser, tarihsel bir rehber niteliğindedir.', '60.00', 'assets/uploads/book_69ea85a95841c3.88622638.jpg', 30, 30, '2026-04-23 20:48:40'),
(329, 'Şu Çılgın Türkler', 131, 20, '9789752202056', 'Kurtuluş Savaşı’nı sürükleyici bir dille anlatır. Tarihi olayları romanlaştırır. Okuyucuyu içine çeker. Bilgilendirici ve etkileyicidir. Geniş kitlelere hitap eder.', 'Anadolu halkının işgale karşı verdiği mücadele anlatılır. Farklı karakterler üzerinden savaşın etkileri gösterilir. Cephede ve halk arasında yaşananlar detaylandırılır. Birlik ve direniş ön plana çıkar. Tarihi olaylar canlı bir şekilde aktarılır.', '55.00', 'assets/uploads/book_69ea96a7ba4f67.17460642.jpg', 10, 10, '2026-04-23 20:51:21'),
(330, 'Garip', 132, 9, '9789753638052', 'Geleneksel şiir anlayışına karşı çıkar. Günlük dili şiire taşır. Sade ve anlaşılırdır. Yenilikçi bir akım başlatmıştır. Şiirde özgürlük vurgulanır.', 'Orhan Veli, sıradan insanın hayatını şiire konu eder. Mizahi ve sade bir dil kullanır. Geleneksel kalıpları reddeder. Şiirlerinde gündelik yaşam öne çıkar. Okuyucuya farklı bir bakış açısı sunar.', '35.00', 'assets/uploads/book_69ea86b8ad9be0.28249089.jpg', 9, 9, '2026-04-23 20:53:12'),
(331, 'Kendi Gök Kubbemiz', 133, 9, '9789754379034', 'Klasik Türk şiiri geleneğini modernleştirir. Estetik diliyle dikkat çeker. Tarih ve kültür temaları işlenir. Lirik bir anlatımı vardır.', 'Şair, geçmiş ile bugünü şiirlerinde birleştirir. İstanbul sevgisi ön plandadır. Milli ve kültürel değerler işlenir. Şiirler estetik bir bütünlük sunar.', '35.00', 'assets/uploads/book_69ea87112aba37.30865683.jpeg', 5, 5, '2026-04-23 20:54:40'),
(332, 'Keşanlı Ali Destanı', 134, 16, '9789753638076', 'Toplumsal yapıyı mizahi şekilde eleştirir. Epik tiyatro örneğidir. Eğlenceli ve düşündürücüdür.', 'Ali, bir anda kahraman ilan edilir. Ancak bu durum aslında toplumun algısıyla ilgilidir. Olaylar mizahi bir şekilde gelişir. Toplum eleştirisi ön plandadır.', '25.00', 'assets/uploads/book_69ea8793bc3654.28202621.jpg', 6, 6, '2026-04-23 20:56:51'),
(333, 'Sergüzeşt', 136, 1, '9789751026585', 'Esaret ve özgürlük teması işlenir. Duygusal yönü güçlüdür. Realist bir anlatımı vardır.', 'Dilber’in köle olarak yaşadığı zorluklar anlatılır. Özgürlük arzusu ön plandadır. Trajik bir yaşam hikâyesi sunulur.', '35.00', 'assets/uploads/book_69ea88199951e9.74889372.webp', 17, 17, '2026-04-23 20:59:05'),
(334, 'Vatan Yahut Silistre', 137, 16, '9789751026592', 'Vatan sevgisi ön plandadır. Milli duyguları harekete geçirir. Etkileyici bir tiyatro eseridir.', 'Silistre savunması sırasında yaşanan olaylar anlatılır. Kahramanlık ve fedakârlık ön plandadır. Vatan sevgisi güçlü şekilde işlenir.', '30.00', 'assets/uploads/book_69ea88609866c0.71873063.webp', 11, 11, '2026-04-23 21:00:16'),
(335, 'Çile', 138, 9, '9789758180204', 'Varoluşsal sorgulamalar içerir. Derin ve yoğun bir dili vardır. Felsefi yönü güçlüdür.', 'Şairin iç dünyası ve arayışları anlatılır. İnsan, hayat ve inanç temaları işlenir. Şiirler derin anlamlar içerir.', '35.00', 'assets/uploads/book_69ea88eab04597.00355043.jpg', 7, 7, '2026-04-23 21:02:34'),
(336, 'Memleket Hikâyeleri', 139, 17, '9789751026608', 'Anadolu insanını anlatır. Gerçekçi ve sade bir dili vardır. Gözlem gücü yüksektir.', 'Farklı şehirlerde geçen hikâyeler anlatılır. İnsanların günlük yaşamı ve sorunları işlenir. Toplumun genel yapısı yansıtılır.', '30.00', 'assets/uploads/book_69ea8952bc1807.78951235.webp', 13, 13, '2026-04-23 21:04:18'),
(337, 'Ateşten Gömlek', 140, 1, '9789751026615', 'Kurtuluş Savaşı’nı anlatır. Milli duygular ön plandadır. Etkileyici bir anlatımı vardır.', 'Savaşın bireyler üzerindeki etkisi anlatılır. Aşk ve mücadele iç içe işlenir. Kahramanlık teması öne çıkar.', '40.00', 'assets/uploads/book_69ea8996ea3274.33848799.jpg', 15, 15, '2026-04-23 21:05:26'),
(338, 'Kuyucaklı Yusuf', 141, 1, '9789753638090', 'Toplum baskısı ve adaletsizlik temaları işlenir. Karakter odaklı bir romandır. Duygusal derinliği oldukça fazladır. Anadolu yaşamı gerçekçi şekilde yansıtılır. Aşk ve çatışma ön plandadır. Akıcı bir dili vardır. Türk edebiyatının önemli eserlerinden biridir.', 'Yusuf, küçük yaşta ailesini kaybettikten sonra kaymakam tarafından büyütülür. Zamanla güçlü ve içine kapanık bir karakter haline gelir. Muazzez ile yaşadığı aşk, toplum baskısı nedeniyle zorluklarla karşılaşır. Çevresindeki insanlar ve sosyal yapı onun hayatını etkiler. Adaletsizlik ve güç ilişkileri ön plana çıkar. Yusuf’un içsel çatışmaları giderek artar. Hikâye trajik bir sona ulaşır.', '35.00', 'assets/uploads/book_69ea8a64910138.00431382.jpg', 18, 18, '2026-04-23 21:08:52'),
(339, 'Türk’ün Ateşle İmtihanı', 140, 34, '9789751026622', 'Kurtuluş Savaşı sürecini birebir anlatan bir anı kitabıdır. Tarihi bir belge niteliği taşır. Yazarın gözlemleri oldukça değerlidir. Akıcı ve etkileyici bir dili vardır. Milli mücadele ruhunu yansıtır. Gerçek olaylara dayanır. Okuyucuya tarih bilinci kazandırır.', 'Halide Edib, savaş sırasında yaşadıklarını ve gözlemlerini detaylı şekilde aktarır. Cephede ve halk arasında yaşananlar anlatılır. Mücadele sürecinin zorlukları açıkça ortaya konur. İnsanların fedakârlıkları ve direnişi ön plana çıkar. Yazar, olaylara kendi bakış açısından yaklaşır. Okuyucuya dönemi yaşatan bir anlatım sunar. Eser, Kurtuluş Savaşı’nı anlamak için önemli bir kaynaktır.', '40.00', 'assets/uploads/book_69ea8d0f2b5ce7.47869527.webp', 12, 12, '2026-04-23 21:20:14'),
(340, 'Huzur', 127, 1, '9789753638106', 'Bireyin iç dünyası ve huzur arayışı ele alınır. Estetik ve güçlü bir dili vardır. Felsefi yönü ön plandadır. İstanbul’un atmosferi detaylı şekilde betimlenir. Zaman ve bilinç temaları işlenir. Karakterler derinliklidir. Türk edebiyatının önemli romanlarındandır.', 'Mümtaz’ın içsel dünyası ve yaşadığı aşk anlatılır. Nuran ile olan ilişkisi onun hayatında önemli bir yer tutar. Geçmiş ve gelecek arasında sıkışmış bir ruh hali vardır. İstanbul’un kültürel yapısı roman boyunca hissedilir. Karakterlerin içsel çatışmaları ön plana çıkar. Huzur arayışı sürekli sorgulanır. Roman, bireyin varoluşsal sorunlarını derinlemesine ele alır.', '35.00', 'assets/uploads/book_69ea8e414f3a58.29801396.jpg', 9, 9, '2026-04-23 21:25:20'),
(341, 'Mai ve Siyah', 145, 1, '9789750501472', 'Hayaller ve gerçekler arasındaki çatışmayı ele alır. Servet-i Fünun döneminin önemli eserlerindendir. Psikolojik yönü güçlüdür. Edebiyat tutkusu ön plandadır. Gerçekçi bir anlatımı vardır. Dönemin aydınlarını yansıtır. Türk romanının gelişiminde önemli bir yere sahiptir.', 'Ahmet Cemil, edebiyata tutkun genç bir yazardır ve büyük hayaller kurar. Zengin ve başarılı bir hayatın hayalini kurarken gerçeklerle yüzleşmek zorunda kalır. Aşk, umut ve hayal kırıklıkları hayatında önemli yer tutar. Yaşadığı olaylar onu derinden etkiler ve değiştirir. Hayallerinin yıkılmasıyla büyük bir boşluğa düşer. Toplumun beklentileri ve bireysel arzular arasında sıkışır. Roman, hayal ile gerçek arasındaki uçurumu etkileyici şekilde anlatır.', '45.00', 'assets/uploads/book_69ea8f6f24b481.22642461.jpeg', 14, 14, '2026-04-23 21:30:22'),
(342, 'Eylül', 146, 21, '9789753638019', 'Türk edebiyatının ilk psikolojik romanlarından biridir. Duygusal ve içsel çatışmalar ön plandadır. Aşk teması derinlemesine işlenir. Karakterlerin ruh halleri detaylı şekilde anlatılır. Melankolik bir atmosfer hâkimdir. Dili akıcı ve etkileyicidir. Dönemi için oldukça yenilikçi bir eserdir.', 'Suat ve Necip arasında gelişen duygusal yakınlık anlatılır. Suat evli olmasına rağmen Necip’e karşı hisler beslemeye başlar. Bu durum karakterler arasında derin bir içsel çatışma yaratır. Yasak aşk duygusu giderek büyür ve onları psikolojik olarak zorlar. Her karakter kendi içinde büyük bir mücadele verir. Olaylar trajik bir sona doğru ilerler. Roman, insanın iç dünyasını ve duygusal karmaşasını derinlemesine ele alır.', '35.00', 'assets/uploads/book_69ea8fcc972419.18598031.webp', 7, 7, '2026-04-23 21:31:56'),
(343, 'Araba Sevdası', 147, 1, '9789751026639', 'Batılılaşma sürecini eleştiren önemli bir eserdir. Yanlış batılılaşma mizahi bir şekilde anlatılır. Dönemin sosyal yapısını yansıtır. Karakterler abartılı şekilde çizilmiştir. Toplumsal eleştiri ön plandadır. Akıcı ve eğlenceli bir anlatımı vardır. Türk edebiyatının ilk realist romanlarından biridir.', 'Bihruz Bey, Batılı yaşam tarzına özenen zengin bir gençtir. Gösterişe ve lükse düşkün bir hayat sürer. Gerçeklerden kopuk bir yaşamı vardır. Periveş adlı bir kadına âşık olur ancak bu aşk hayalden ibarettir. Yaşadığı olaylar onun ne kadar yüzeysel bir karakter olduğunu ortaya çıkarır. Yanlış batılılaşmanın komik ve trajik yönleri anlatılır. Roman, dönemin sosyal yapısını eleştiren önemli bir eserdir.', '35.00', 'assets/uploads/book_69ea905764dac7.44054581.png', 9, 9, '2026-04-23 21:34:14'),
(344, 'Felatun Bey ile Rakım Efendi', 148, 1, '9789751026646', 'Doğu-Batı çatışmasını ele alan önemli bir romandır. İki zıt karakter üzerinden toplum eleştirisi yapılır. Eğitimin önemi vurgulanır. Yanlış batılılaşma eleştirilir. Öğretici yönü güçlüdür. Akıcı ve sade bir dili vardır. Türk romanının erken dönem örneklerindendir.', 'Felatun Bey yüzeysel bir batılılaşmayı temsil ederken Rakım Efendi çalışkan ve bilinçli bir karakterdir. İki karakterin yaşam tarzları karşılaştırılır. Felatun Bey savurgan ve sorumsuz bir hayat sürerken Rakım Efendi disiplinli ve başarılıdır. Zamanla Felatun Bey’in hayatı kötüye gider. Rakım Efendi ise başarılı bir hayat kurar. Roman, doğru ve yanlış yaşam tarzlarını karşılaştırır. Okuyucuya ders niteliğinde mesajlar verir.', '55.00', 'assets/uploads/book_69ea90babaa014.51414445.webp', 3, 3, '2026-04-23 21:35:54'),
(345, 'Anayurt Oteli', 149, 21, '9789754700139', 'Zebercet’in otel odasında geçen yalnızlığını anlatır. Bireyin içsel çöküşünü çarpıcı bir şekilde işler. Roman, psikolojik çözümlemeleriyle dikkat çeker. Türk edebiyatında modern psikolojik roman örneğidir.', 'Zebercet, Anayurt Oteli’nde monoton bir hayat sürer. Bir kadın müşterinin gelişi, onun hayatını değiştirir. Roman, bireyin yalnızlığını ve içsel çöküşünü işler. Yusuf Atılgan, psikolojik çözümlemeleri derinleştirir. Eser, bireyin toplumla uyumsuzluğunu gösterir. Zebercet’in içsel çatışmaları, romanın merkezindedir. Türk edebiyatında modern psikolojik romanın öncüsü olmuştur.', '55.00', 'assets/uploads/book_69ea91b7745099.90013306.jpg', 10, 10, '2026-04-23 21:40:07'),
(346, 'Benim Adım Kırmızı', 150, 1, '9789754700153', 'Osmanlı nakkaşlarının dünyasında geçen roman, sanat, aşk ve cinayet ekseninde kültürel çatışmaları işler. Doğu ve Batı sanat anlayışının karşılaşması, romanın merkezinde yer alır. Çok sesli anlatımıyla dikkat çeker. Pamuk’a uluslararası ödüller kazandırmıştır.', '16. yüzyıl İstanbul’unda nakkaşların dünyası, bir cinayetle sarsılır. Anlatıcıların sürekli değiştiği roman, sanatın ve kimliğin sorgulandığı bir yapıya sahiptir. Aşk, entrika ve kültürel çatışmalar iç içe geçer. Osmanlı minyatür geleneği ile Batı resim anlayışı karşı karşıya gelir. Pamuk, tarihsel arka planı bireysel dramlarla birleştirir. Eser, Türk edebiyatının dünya çapında en bilinen romanlarından biri olmuştur.', '60.00', 'assets/uploads/book_69ea9231eb6a87.76296521.jpg', 7, 7, '2026-04-23 21:42:09'),
(347, 'Aşk-ı Memnu', 145, 1, '9789754700160', 'Osmanlı yüksek sosyetesinde geçen yasak aşkın trajik hikâyesini anlatır. Bihter ve Behlül’ün ilişkisi, ahlaki çelişkileri gözler önüne serer. Realist üslubuyla dönemin toplumsal yapısını işler. Türk edebiyatının klasiklerinden biridir.', 'Bihter, annesinin baskıcı hayatından kaçarak zengin Adnan Bey ile evlenir. Ancak Behlül ile yaşadığı yasak aşk, trajik bir sona doğru ilerler. Roman, bireysel tutkular ile toplumsal değerlerin çatışmasını işler. Halit Ziya, realist bir üslupla dönemin sosyetesini tasvir eder. Aşk-ı Memnu, bireyin arzuları ile toplumun kuralları arasındaki gerilimi çarpıcı bir şekilde ortaya koyar. Eser, Türk edebiyatında modern romanın öncülerinden biri olarak kabul edilir.', '60.00', 'assets/uploads/book_69ea928882d125.08796508.jpg', 16, 16, '2026-04-23 21:43:36'),
(348, 'Bereketli Topraklar Üzerinde', 151, 1, '9789754700184', 'Çukurova’ya iş bulmaya gelen köylülerin yaşam mücadelesini anlatır. İşçi sınıfının sorunlarını ve umutlarını gözler önüne serer. Roman, sınıfsal çatışmaları gerçekçi bir üslupla işler. Orhan Kemal’in en bilinen eserlerinden biridir.', 'Üç köylü genç, iş bulmak için Çukurova’ya gelir. Fabrikalarda ve tarlalarda çalışırken sınıfsal çatışmalarla karşılaşırlar. Roman, işçi sınıfının yaşam mücadelesini ve umutlarını işler. Orhan Kemal, toplumsal gerçekçiliği güçlü bir şekilde yansıtır. Çukurova’nın doğası, karakterlerin dramlarıyla birleşir. Bereketli Topraklar Üzerinde, Türk edebiyatında işçi sınıfının en çarpıcı romanlarından biri olarak kabul edilir.', '60.00', 'assets/uploads/book_69ea92d3d2ac75.96406000.webp', 17, 17, '2026-04-23 21:44:51');

-- --------------------------------------------------------

--
-- Table structure for table `book_reviews`
--

CREATE TABLE `book_reviews` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `book_reviews`
--

INSERT INTO `book_reviews` (`id`, `book_id`, `user_id`, `rating`, `comment`, `created_at`) VALUES
(9, 232, 12, 5, 'Çok etkileyici bir kitap', '2026-04-18 14:47:39'),
(10, 256, 7, 4, 'güzel kitap.', '2026-04-18 20:27:02'),
(11, 285, 16, 5, '.', '2026-04-21 06:54:58');

-- --------------------------------------------------------

--
-- Table structure for table `borrows`
--

CREATE TABLE `borrows` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `rental_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `overdue_penalty_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `penalty_last_charged_date` date DEFAULT NULL,
  `returned_at` datetime DEFAULT NULL,
  `status` enum('borrowed','returned') NOT NULL DEFAULT 'borrowed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `borrows`
--

INSERT INTO `borrows` (`id`, `user_id`, `book_id`, `borrow_date`, `due_date`, `rental_price`, `overdue_penalty_total`, `penalty_last_charged_date`, `returned_at`, `status`, `created_at`) VALUES
(36, 16, 232, '2026-04-18', '2032-10-02', '3931.67', '0.00', NULL, '2026-04-20 22:59:49', 'returned', '2026-04-18 18:24:13'),
(37, 16, 238, '2026-04-18', '2126-04-26', '36532.00', '0.00', NULL, '2026-04-20 22:59:50', 'returned', '2026-04-18 18:28:13'),
(38, 16, 285, '2026-04-20', '2026-05-05', '70.00', '0.00', NULL, NULL, 'borrowed', '2026-04-21 06:54:25'),
(39, 12, 232, '2026-04-27', '2026-05-12', '23.33', '0.00', NULL, NULL, 'borrowed', '2026-04-28 06:50:17');

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`id`, `user_id`, `book_id`, `created_at`) VALUES
(118, 14, 232, '2026-04-22 18:04:27'),
(120, 17, 251, '2026-04-29 15:22:32'),
(121, 17, 232, '2026-04-29 17:27:45'),
(122, 17, 267, '2026-04-29 17:27:46'),
(123, 17, 239, '2026-04-29 17:27:50'),
(124, 17, 262, '2026-04-29 17:27:52'),
(125, 20, 232, '2026-04-29 17:30:20'),
(126, 20, 248, '2026-04-29 17:30:52');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(34, 'Anı'),
(2, 'Bilim'),
(10, 'Biyografi'),
(8, 'Cocuk'),
(7, 'Egitim'),
(4, 'Felsefe'),
(17, 'Hikaye'),
(23, 'İran Edebiyatı'),
(19, 'Macera'),
(29, 'Öykü'),
(6, 'Psikoloji'),
(24, 'psikoloji, polisiye'),
(21, 'Psikolojik Roman'),
(1, 'Roman'),
(30, 'Rus Edebiyatı / Distopya'),
(27, 'Rus Edebiyatı / Hiciv'),
(26, 'Rus Edebiyatı / Klasik'),
(31, 'Rus Edebiyatı / Mektup Roman'),
(28, 'Rus Edebiyatı / Modern Klasik'),
(25, 'Rus Edebiyatı / Tarihi Roman'),
(9, 'Siir'),
(32, 'Söylev / Tarih'),
(3, 'Tarih'),
(20, 'Tarihi Roman'),
(5, 'Teknoloji'),
(11, 'Teknoloji / Biyografi'),
(12, 'Teknoloji / Gelecek'),
(15, 'Teknoloji / Mobil Teknolojiler'),
(13, 'Teknoloji / Yapay Zeka'),
(16, 'Tiyatro');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `username` varchar(60) NOT NULL,
  `email` varchar(120) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','member') NOT NULL DEFAULT 'member',
  `remember_token_hash` varchar(64) DEFAULT NULL,
  `remember_token_expires_at` datetime DEFAULT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `phone`, `address`, `password_hash`, `role`, `remember_token_hash`, `remember_token_expires_at`, `balance`, `created_at`) VALUES
(1, 'Admin', 'admin', 'admin@gmail.com', NULL, NULL, '$2y$12$5Z6oiR6JBb7zck3gzmEX/eFDmYtg7IlbA8rRi2pMKABXtcyQe3Cye', 'admin', NULL, NULL, '500.00', '2026-04-13 20:54:49'),
(7, 'ABC', 'Abc', 'abc@gmail.com', '4444444445', 'asjkdbakcja', '$2y$10$w8dK/9aW0mYVTae9jsVnWuqAhzn0xu5/1VbBqc2zKV5H7uEoht0KS', 'member', NULL, NULL, '600.00', '2026-04-13 09:56:57'),
(12, 'SEYRAN HUSEYNOV', 'seyran', 'seyranhuseynov@gmail.com', '05555555555', 'X', '$2y$10$Zbuv9fB6o4ZKOfm7KtEvE.T4Tc1rGcPbkGkizquMHXjhSutTifr76', 'member', '67d8aa7154681192818de1017f091197c91794f77f8833baeea72349fdf155ed', '2026-06-03 17:44:47', '54.50', '2026-04-15 18:14:27'),
(13, 'ERDI DUMAN', 'Dmnerdi', 'erdidmn34@gmail.com', '(546) 486 58 34', 'İstanbul', '$2y$10$gskNu8DXdLwqKKrl7AMMA.jRikrjZttsSzlw.wrUE3ckkafBwqfKy', 'member', 'bbc095d9dc33e1970f968c67abe882cb841b6722f2a8075c7ed843ef14ff49a8', '2026-05-15 15:33:28', '0.00', '2026-04-15 19:33:20'),
(14, 'Medinebanu', 'Banu', 'medinerozy@gmail.com', '5555555555', 'Florya', '$2y$10$9PhOlN6.YYBxxXyu9a0I4Ob.VrCYkZuRwh66ZRFFHp14NZ5xkE7my', 'member', NULL, NULL, '0.00', '2026-04-15 19:34:20'),
(15, 'DYLDRM', 'Doğukan YILDIRIM', 'dyldirim@gmail.com', '12334576890', 'istanbul', '$2y$10$0Pz64YwwHijYYn3rMWWC3.GVD9Ma/BVVnY.oOpK6XrXR9D/hCDUiO', 'member', NULL, NULL, '0.00', '2026-04-15 19:54:16'),
(16, 'ANVAR', 'Anvar', 'fghh@gmail.com', '+90567889999', 'Vbnb', '$2y$10$w/q93avW15BS9fCQgzrMdOBBo/17PCTMdSS7/CGaSi9jDAPgmYGua', 'member', '6767bd528dddfe91752df5611e4a306ceba5222f8f3a4eaf66c2aac465f9f197', '2026-05-29 13:15:31', '99959466.32', '2026-04-16 06:14:01'),
(17, 'EMRE UZTAŞ', 'Emre', 'emre.uztas58@gmail.com', '5061448343', 'Tuzla/istanbul', '$2y$10$ei8q41AT.hbVsswmxGdirezRPthzZcPFHavmKHrpP3XGTDtbA0Tbu', 'member', NULL, NULL, '780.00', '2026-04-17 14:22:31'),
(18, 'İNCI ELIF BOZBULUT', 'incibozbulut', 'incielifbozbulut05@gmail.com', '05057871355', 'Küçükçekmece', '$2y$10$GOEy0D51C6GxwGiC.V3Qieuh.gUCSeeDHgigZBearuD1pZWNLmVfe', 'member', NULL, NULL, '0.00', '2026-04-18 16:04:11'),
(20, 'YELIZ KILINÇ', 'yeliz', 'klnccyelizs@gmail.com', '05314695962', 'İstanbul', '$2y$10$luoFb4TUwgMCpqmnXSJeUuOfSMgO5..Kiplyh.K4HkkpGu55ALB6S', 'member', NULL, NULL, '0.00', '2026-04-29 17:30:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_announcements_active_id` (`is_active`,`id`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`),
  ADD KEY `fk_books_author` (`author_id`),
  ADD KEY `fk_books_category` (`category_id`),
  ADD KEY `idx_books_title` (`title`),
  ADD KEY `idx_books_filter` (`category_id`,`author_id`,`price`,`available_copies`);

--
-- Indexes for table `book_reviews`
--
ALTER TABLE `book_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_book_reviews_book_id` (`book_id`),
  ADD KEY `idx_book_reviews_user_id` (`user_id`),
  ADD KEY `idx_book_reviews_book_rating` (`book_id`,`rating`);

--
-- Indexes for table `borrows`
--
ALTER TABLE `borrows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_borrows_user` (`user_id`),
  ADD KEY `fk_borrows_book` (`book_id`),
  ADD KEY `idx_borrows_overdue_scan` (`status`,`due_date`,`penalty_last_charged_date`),
  ADD KEY `idx_borrows_overdue_penalty` (`status`,`due_date`,`penalty_last_charged_date`),
  ADD KEY `idx_borrows_user_status_book` (`user_id`,`status`,`book_id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_user_book` (`user_id`,`book_id`),
  ADD KEY `fk_cart_book` (`book_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_remember_token` (`remember_token_hash`,`remember_token_expires_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=349;

--
-- AUTO_INCREMENT for table `book_reviews`
--
ALTER TABLE `book_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `borrows`
--
ALTER TABLE `borrows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `fk_books_author` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_books_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `book_reviews`
--
ALTER TABLE `book_reviews`
  ADD CONSTRAINT `fk_book_reviews_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_book_reviews_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `borrows`
--
ALTER TABLE `borrows`
  ADD CONSTRAINT `fk_borrows_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_borrows_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `fk_cart_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
