<?php
declare(strict_types=1);

define('APP_NAME', 'Kutuphane Sistemi');

define('DB_HOST', 'sql113.infinityfree.com');
define('DB_NAME', 'if0_41646798_library_system');
define('DB_USER', 'if0_41646798');
define('DB_PASS', 'Huseynov06');

define('REMEMBER_COOKIE_NAME', 'library_remember');
define('REMEMBER_COOKIE_DAYS', 30);

define('OVERDUE_DAILY_PENALTY', 5.00);
define('BOOKS_PER_PAGE', 18);
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024);
define('ASSET_VERSION', 'professional-20260504');

$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
$baseUrl = rtrim($scriptDir === '/' ? '' : $scriptDir, '/');
define('BASE_URL', $baseUrl);
