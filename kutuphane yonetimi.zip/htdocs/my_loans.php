<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_login();

$user = current_user(true);
$penaltySummary = user_overdue_penalty_summary((int) $user['id']);

$stmt = db()->prepare(
    'SELECT
        br.id,
        br.borrow_date,
        br.due_date,
        br.returned_at,
        br.rental_price,
        br.overdue_penalty_total,
        br.penalty_last_charged_date,
        br.status,
        b.title,
        b.isbn,
        a.name AS author_name,
        c.name AS category_name
     FROM borrows br
     INNER JOIN books b ON b.id = br.book_id
     INNER JOIN authors a ON a.id = b.author_id
     INNER JOIN categories c ON c.id = b.category_id
     WHERE br.user_id = :user_id
     ORDER BY
        CASE WHEN br.status = "borrowed" AND br.due_date < CURDATE() THEN 0
             WHEN br.status = "borrowed" THEN 1
             ELSE 2 END,
        br.due_date ASC,
        br.id DESC'
);
$stmt->execute(['user_id' => (int) $user['id']]);
$loans = $stmt->fetchAll();

require_once __DIR__ . '/partials/header.php';
?>

<section class="hero">
    <div class="hero-content">
        <h1>Kiralamalarım</h1>
        <p class="muted">Aktif ve geçmiş kiralamalarını buradan takip edebilirsin.</p>
    </div>
</section>

<?php if ((int) $penaltySummary['active_overdue_count'] > 0): ?>
    <section class="overdue-alert overdue-alert-page" role="alert">
        <div class="overdue-alert-title">⚠ Gecikmiş kitap uyarısı</div>
        <div class="overdue-alert-text">
            <?= e($penaltySummary['active_overdue_count']) ?> kitabın teslim günü geçti.
            Toplam <?= e($penaltySummary['active_overdue_days']) ?> gün gecikme var.
            Bakiyenden bugüne kadar <strong><?= e(format_money($penaltySummary['active_penalty'])) ?></strong> gecikme cezası düşüldü.
        </div>
        <div class="overdue-alert-rule"><?= e(overdue_penalty_rule_text()) ?></div>
    </section>
<?php endif; ?>

<section>
    <?php if (!$loans): ?>
        <div class="empty-state">Henüz kiraladığınız bir kitap bulunmuyor.</div>
    <?php else: ?>
        <div class="loan-list">
            <?php foreach ($loans as $loan): ?>
                <?php
                $isReturned = $loan['status'] === 'returned';
                $overdueDays = (!$isReturned && $loan['due_date'] < date('Y-m-d'))
                    ? overdue_days_until_today((string) $loan['due_date'])
                    : 0;
                $isOverdue = $overdueDays > 0;
                $penaltyTotal = (float) ($loan['overdue_penalty_total'] ?? 0);
                ?>
                <article class="loan-card <?= $isOverdue ? 'overdue-loan-card' : '' ?>">
                    <h3><?= e($loan['title']) ?></h3>

                    <div class="meta-row">
                        <span class="badge">Yazar: <?= e($loan['author_name']) ?></span>
                        <span class="badge">Kategori: <?= e($loan['category_name']) ?></span>
                        <span class="badge">ISBN: <?= e($loan['isbn']) ?></span>
                        <span class="badge badge-warning">Kiralama Ücreti: <?= e(format_money($loan['rental_price'])) ?></span>

                        <?php if ($isReturned): ?>
                            <span class="badge badge-success">İade edildi</span>
                        <?php elseif ($isOverdue): ?>
                            <span class="badge badge-danger">Gecikmiş kitap: <?= e($overdueDays) ?> gün geçti</span>
                        <?php else: ?>
                            <span class="badge badge-warning">Aktif kiralama</span>
                        <?php endif; ?>

                        <?php if ($penaltyTotal > 0): ?>
                            <span class="badge badge-danger">Kesilen ceza: <?= e(format_money($penaltyTotal)) ?></span>
                        <?php endif; ?>
                    </div>

                    <p class="muted">
                        Alış Tarihi: <strong><?= e($loan['borrow_date']) ?></strong><br>
                        Teslim Tarihi: <strong><?= e($loan['due_date']) ?></strong><br>
                        İade Tarihi: <strong><?= e($loan['returned_at'] ?: '-') ?></strong>
                    </p>

                    <?php if ($isOverdue): ?>
                        <div class="overdue-inline-warning">
                            <strong>Bu kitabın teslim günü geçti.</strong><br>
                            <?= e($overdueDays) ?> gün gecikme görünüyor. Bugüne kadar bu kitap için bakiyenden
                            <strong><?= e(format_money($penaltyTotal)) ?></strong> düşüldü.
                            <span><?= e(overdue_penalty_rule_text()) ?></span>
                        </div>
                    <?php elseif ($isReturned && $penaltyTotal > 0): ?>
                        <div class="overdue-paid-note">
                            Bu kiralama iade edildi. Bu kitap için kesilen toplam gecikme cezası:
                            <strong><?= e(format_money($penaltyTotal)) ?></strong>.
                        </div>
                    <?php endif; ?>

                    <?php if (!$isReturned): ?>
                        <form method="post" action="<?= e(url('return_book.php')) ?>">
                            <input type="hidden" name="borrow_id" value="<?= e($loan['id']) ?>">
                            <button class="btn btn-success" type="submit">Kitabı İade Et</button>
                        </form>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>
<?php require_once __DIR__ . '/partials/footer.php'; ?>
