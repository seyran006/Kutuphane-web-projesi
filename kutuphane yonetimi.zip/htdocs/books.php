<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_login();

$user = current_user();
$isAdmin = ($user['role'] ?? '') === 'admin';

if (!function_exists('format_money')) {
    function format_money(float|int|string $amount): string
    {
        return number_format((float) $amount, 2, ',', '.') . ' TL';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_to_cart') {
    $bookId = (int) ($_POST['book_id'] ?? 0);
    $response = [
        'success' => false,
        'message' => 'İşlem yapılamadı.',
        'cart_url' => url('cart.php'),
    ];

    if ($isAdmin) {
        $response['message'] = 'Admin hesapları sepet işlemi yapamaz.';
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    try {
        $stmt = db()->prepare(
            'SELECT b.id, b.available_copies,
                    EXISTS(SELECT 1 FROM borrows br WHERE br.user_id = :user_id AND br.book_id = b.id AND br.status = "borrowed") AS already_borrowed,
                    EXISTS(SELECT 1 FROM cart_items ci WHERE ci.user_id = :user_id AND ci.book_id = b.id) AS already_in_cart
             FROM books b
             WHERE b.id = :id
             LIMIT 1'
        );
        $stmt->execute([
            'id' => $bookId,
            'user_id' => (int) $user['id'],
        ]);
        $book = $stmt->fetch();

        if (!$book) {
            throw new RuntimeException('Kitap bulunamadı.');
        }

        if ((int) $book['already_borrowed'] === 1) {
            throw new RuntimeException('Bu kitap zaten hesabınızda ödünç görünüyor.');
        }

        if ((int) $book['already_in_cart'] === 1) {
            throw new RuntimeException('Bu kitap zaten sepetinizde.');
        }

        if ((int) $book['available_copies'] < 1) {
            throw new RuntimeException('Bu kitap için stok yok.');
        }

        $insertStmt = db()->prepare('INSERT INTO cart_items (user_id, book_id) VALUES (:user_id, :book_id)');
        $insertStmt->execute([
            'user_id' => (int) $user['id'],
            'book_id' => $bookId,
        ]);

        $response['success'] = true;
        $response['message'] = 'Kitap sepete eklendi.';
    } catch (Throwable $exception) {
        $response['message'] = $exception->getMessage();
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$q = trim((string) ($_GET['q'] ?? ''));
$categoryId = (int) ($_GET['category_id'] ?? 0);
$authorId = (int) ($_GET['author_id'] ?? 0);
$minStock = trim((string) ($_GET['min_stock'] ?? ''));
$maxStock = trim((string) ($_GET['max_stock'] ?? ''));
$minPrice = trim((string) ($_GET['min_price'] ?? ''));
$maxPrice = trim((string) ($_GET['max_price'] ?? ''));
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = defined('BOOKS_PER_PAGE') ? (int) BOOKS_PER_PAGE : 18;
$perPage = max(6, min(48, $perPage));

$hasActiveFilters = (
    $q !== ''
    || $categoryId > 0
    || $authorId > 0
    || $minStock !== ''
    || $maxStock !== ''
    || $minPrice !== ''
    || $maxPrice !== ''
);

if (!function_exists('books_page_url')) {
    function books_page_url(int $page): string
    {
        $query = $_GET;
        if ($page <= 1) {
            unset($query['page']);
        } else {
            $query['page'] = $page;
        }

        return url('books.php' . ($query ? '?' . http_build_query($query) : ''));
    }
}

$categories = db()->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$authors = db()->query('SELECT id, name FROM authors ORDER BY name')->fetchAll();

$whereSql = ' WHERE 1 = 1';
$params = [];

if ($q !== '') {
    $whereSql .= ' AND (b.title LIKE :q_title OR a.name LIKE :q_author OR b.isbn LIKE :q_isbn)';
    $searchTerm = '%' . $q . '%';
    $params['q_title'] = $searchTerm;
    $params['q_author'] = $searchTerm;
    $params['q_isbn'] = $searchTerm;
}

if ($categoryId > 0) {
    $whereSql .= ' AND b.category_id = :category_id';
    $params['category_id'] = $categoryId;
}

if ($authorId > 0) {
    $whereSql .= ' AND b.author_id = :author_id';
    $params['author_id'] = $authorId;
}

if ($minStock !== '' && is_numeric($minStock)) {
    $whereSql .= ' AND b.available_copies >= :min_stock';
    $params['min_stock'] = (int) $minStock;
}

if ($maxStock !== '' && is_numeric($maxStock)) {
    $whereSql .= ' AND b.available_copies <= :max_stock';
    $params['max_stock'] = (int) $maxStock;
}

if ($minPrice !== '' && is_numeric($minPrice)) {
    $whereSql .= ' AND b.price >= :min_price';
    $params['min_price'] = (float) $minPrice;
}

if ($maxPrice !== '' && is_numeric($maxPrice)) {
    $whereSql .= ' AND b.price <= :max_price';
    $params['max_price'] = (float) $maxPrice;
}

$countSql = '
    SELECT COUNT(*)
    FROM books b
    INNER JOIN authors a ON a.id = b.author_id
    INNER JOIN categories c ON c.id = b.category_id
' . $whereSql;
$countStmt = db()->prepare($countSql);
$countStmt->execute($params);
$totalResults = (int) $countStmt->fetchColumn();
$totalPages = max(1, (int) ceil($totalResults / $perPage));

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset = ($page - 1) * $perPage;
$showingFrom = $totalResults > 0 ? $offset + 1 : 0;
$showingTo = min($offset + $perPage, $totalResults);

$dataSql = '
    SELECT
        b.id,
        b.title,
        b.author_id,
        b.category_id,
        b.isbn,
        b.description,
        b.summary,
        b.price,
        COALESCE(b.image_path, "") AS image_path,
        b.total_copies,
        b.available_copies,
        b.created_at,
        a.name AS author_name,
        c.name AS category_name
    FROM books b
    INNER JOIN authors a ON a.id = b.author_id
    INNER JOIN categories c ON c.id = b.category_id
' . $whereSql . '
    ORDER BY b.title ASC, b.id ASC
    LIMIT ' . $perPage . ' OFFSET ' . $offset;

$stmt = db()->prepare($dataSql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$pageBookIds = array_map('intval', array_column($books, 'id'));

foreach ($books as &$book) {
    $book['average_rating'] = 0;
    $book['review_count'] = 0;
}
unset($book);

if ($pageBookIds) {
    $placeholders = implode(',', array_fill(0, count($pageBookIds), '?'));
    $ratingsStmt = db()->prepare(
        'SELECT book_id, AVG(rating) AS average_rating, COUNT(*) AS review_count
         FROM book_reviews
         WHERE book_id IN (' . $placeholders . ')
         GROUP BY book_id'
    );
    $ratingsStmt->execute($pageBookIds);
    $ratingsByBookId = [];

    foreach ($ratingsStmt->fetchAll() as $ratingRow) {
        $ratingsByBookId[(int) $ratingRow['book_id']] = $ratingRow;
    }

    foreach ($books as &$book) {
        $bookIdForRating = (int) $book['id'];
        if (isset($ratingsByBookId[$bookIdForRating])) {
            $book['average_rating'] = (float) $ratingsByBookId[$bookIdForRating]['average_rating'];
            $book['review_count'] = (int) $ratingsByBookId[$bookIdForRating]['review_count'];
        }
    }
    unset($book);
}

$borrowedBookIds = [];
$cartBookIds = [];

if (!$isAdmin && $pageBookIds) {
    $placeholders = implode(',', array_fill(0, count($pageBookIds), '?'));

    $borrowedStmt = db()->prepare(
        'SELECT book_id
         FROM borrows
         WHERE user_id = ? AND status = "borrowed" AND book_id IN (' . $placeholders . ')'
    );
    $borrowedStmt->execute(array_merge([(int) $user['id']], $pageBookIds));
    $borrowedBookIds = array_map('intval', array_column($borrowedStmt->fetchAll(), 'book_id'));

    $cartIdsStmt = db()->prepare(
        'SELECT book_id
         FROM cart_items
         WHERE user_id = ? AND book_id IN (' . $placeholders . ')'
    );
    $cartIdsStmt->execute(array_merge([(int) $user['id']], $pageBookIds));
    $cartBookIds = array_map('intval', array_column($cartIdsStmt->fetchAll(), 'book_id'));
}

require_once __DIR__ . '/partials/header.php';
?>


<div id="ajax-flash" style="margin: 0 0 20px 0;"></div>

<section class="filter-card filter-collapsible">
    <details <?= $hasActiveFilters ? 'open' : '' ?>>
        <summary class="filter-summary">
            <span>Filtreleme</span>
            <small>Kitap / yazar / kategori ara</small>
        </summary>

    <form method="get" action="">
        <div class="form-row">
            <div class="form-group">
                <label for="q">Kitap / Yazar / ISBN</label>
                <input class="form-control" id="q" name="q" type="text" value="<?= e($q) ?>" placeholder="Örnek: Roman 12 veya Sabahattin Ali">
            </div>

            <div class="form-group">
                <label for="category_id">Kategori</label>
                <select id="category_id" name="category_id">
                    <option value="0">Tüm kategoriler</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= e($category['id']) ?>" <?= $categoryId === (int) $category['id'] ? 'selected' : '' ?>>
                            <?= e($category['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="author_id">Yazar</label>
                <select id="author_id" name="author_id">
                    <option value="0">Tüm yazarlar</option>
                    <?php foreach ($authors as $author): ?>
                        <option value="<?= e($author['id']) ?>" <?= $authorId === (int) $author['id'] ? 'selected' : '' ?>>
                            <?= e($author['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="min_stock">Minimum Stok</label>
                <input class="form-control" id="min_stock" name="min_stock" type="number" min="0" value="<?= e($minStock) ?>" placeholder="Örn: 1">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="max_stock">Maksimum Stok</label>
                <input class="form-control" id="max_stock" name="max_stock" type="number" min="0" value="<?= e($maxStock) ?>" placeholder="Örn: 10">
            </div>

            <div class="form-group">
                <label for="min_price">Minimum Fiyat</label>
                <input class="form-control" id="min_price" name="min_price" type="number" min="0" step="0.01" value="<?= e($minPrice) ?>" placeholder="Örn: 25">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="max_price">Maksimum Fiyat</label>
                <input class="form-control" id="max_price" name="max_price" type="number" min="0" step="0.01" value="<?= e($maxPrice) ?>" placeholder="Örn: 100">
            </div>

            <div class="form-group">
                <label>&nbsp;</label>
                <div class="form-actions">
                    <button type="submit">Filtrele</button>
                   <a class="btn btn-secondary books-preview-btn" href="<?= e(url('books.php')) ?>">
    Kitapları Gör

    <span class="book-preview">
        <img src="<?= e(url('assets/uploads/book_69ea91b7745099.90013306.jpg')) ?>" alt="" loading="lazy" decoding="async">
        <img src="<?= e(url('assets/uploads/book_69e39b1990ca05.53518561.jpg')) ?>" alt="" loading="lazy" decoding="async">
        <img src="<?= e(url('assets/uploads/book_69ea128d007be9.46513303.jpg')) ?>" alt="" loading="lazy" decoding="async">
        <img src="<?= e(url('assets/uploads/book_69e3ef11bbe084.28005468.jpg')) ?>" alt="" loading="lazy" decoding="async">
    </span>
</a>
                </div>
            </div>
        </div>
    </form>
    </details>
</section>



<section style="margin-top:20px;">

    <?php if (!$books): ?>
        <div class="empty-state">Bu filtrelere uygun kitap bulunamadı.</div>
    <?php else: ?>
        <div class="book-list" id="book-list-wrap">
            <?php foreach ($books as $book): ?>
                <?php
                $bookId = (int) $book['id'];
                $isBorrowed = in_array($bookId, $borrowedBookIds, true);
                $inCart = in_array($bookId, $cartBookIds, true);
                $available = (int) $book['available_copies'] > 0;
                $imagePath = trim((string) ($book['image_path'] ?? ''));
                ?>
                <article class="book-card" data-book-id="<?= e($bookId) ?>">
                    <div class="book-card-layout">
                        <div class="book-cover">
                            <a href="<?= e(url('book_details.php?id=' . $bookId)) ?>">
                                <?php if ($imagePath !== ''): ?>
                                    <img src="<?= e(url($imagePath)) ?>" alt="<?= e($book['title']) ?>" loading="lazy" decoding="async">
                                <?php else: ?>
                                    <span>Kapak görseli<br>sonra<br>eklenecek</span>
                                <?php endif; ?>
                            </a>
                        </div>

                        <div class="book-content">
                            <h3>
                                <a class="book-title-link" href="<?= e(url('book_details.php?id=' . $bookId)) ?>">
                                    <?= e($book['title']) ?>
                                </a>
                            </h3>

                            <div class="rating-row">
                                <span class="stars" aria-label="Puan: <?= e(number_format((float) $book['average_rating'], 1)) ?> / 5">
                                    <?php
                                    $roundedAverage = (int) round((float) $book['average_rating']);
                                    for ($star = 1; $star <= 5; $star++):
                                        echo $star <= $roundedAverage ? '★' : '☆';
                                    endfor;
                                    ?>
                                </span>
                                <span class="rating-text">
                                    <?= e(number_format((float) $book['average_rating'], 1)) ?> / 5
                                    (<?= e((int) $book['review_count']) ?> yorum)
                                </span>
                            </div>

                            <p class="muted book-description-clamp"><?= e($book['description']) ?></p>

                            <div class="meta-row">
                                <span class="badge">Yazar: <?= e($book['author_name']) ?></span>
                                <span class="badge">Kategori: <?= e($book['category_name']) ?></span>
                                <span class="badge">ISBN: <?= e($book['isbn']) ?></span>
                                <span class="badge badge-warning">Aylık Fiyatı: <?= e(format_money($book['price'] ?? 0)) ?></span>

                                <?php if ($available): ?>
                                    <span class="badge badge-success">Stok: <?= e($book['available_copies']) ?></span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Stok yok</span>
                                <?php endif; ?>
                            </div>

                            <?php if (!$isAdmin): ?>
                                <div class="form-actions book-actions action-pair-row cart-action-group">
                                    <a class="btn btn-success action-pair-item book-detail-btn" href="<?= e(url('book_details.php?id=' . $bookId)) ?>">Kitap detaylarını gör</a>

                                    <?php if ($isBorrowed): ?>
                                        <button type="button" class="action-pair-item" disabled>Zaten ödünçte</button>

                                    <?php elseif (!$available): ?>
                                        <button type="button" class="action-pair-item" disabled>Stok yok</button>

                                    <?php elseif ($inCart): ?>
                                        <a class="btn btn-cart-link action-pair-item" href="<?= e(url('cart.php')) ?>">Sepete Git</a>

                                    <?php else: ?>
                                        <form method="post" action="" class="js-add-to-cart-form action-pair-item" style="margin:0;">
                                            <input type="hidden" name="action" value="add_to_cart">
                                            <input type="hidden" name="book_id" value="<?= e($bookId) ?>">
                                            <button type="submit" class="btn js-add-to-cart-button">Sepete Ekle</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="form-actions book-actions admin-actions">
                                    <form method="get" action="<?= e(url('guncelle.php')) ?>" style="margin:0;">
                                        <input type="hidden" name="id" value="<?= e($bookId) ?>">
                                        <button type="submit" class="btn btn-primary">Güncelle</button>
                                    </form>

                                    <form method="post" action="<?= e(url('sil.php')) ?>" style="margin:0;" onsubmit="return confirm('Bu kitabı silmek istediğine emin misin?');">
                                        <input type="hidden" name="book_id" value="<?= e($bookId) ?>">
                                        <button type="submit" class="btn btn-danger">Sil</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <?php
            $paginationStart = max(1, $page - 2);
            $paginationEnd = min($totalPages, $page + 2);
            ?>
            <nav class="pagination" aria-label="Kitap sayfaları">
                <?php if ($page > 1): ?>
                    <a href="<?= e(books_page_url($page - 1)) ?>">‹ Önceki</a>
                <?php endif; ?>

                <?php if ($paginationStart > 1): ?>
                    <a href="<?= e(books_page_url(1)) ?>">1</a>
                    <?php if ($paginationStart > 2): ?><span>…</span><?php endif; ?>
                <?php endif; ?>

                <?php for ($i = $paginationStart; $i <= $paginationEnd; $i++): ?>
                    <?php if ($i === $page): ?>
                        <span class="is-active"><?= e($i) ?></span>
                    <?php else: ?>
                        <a href="<?= e(books_page_url($i)) ?>"><?= e($i) ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($paginationEnd < $totalPages): ?>
                    <?php if ($paginationEnd < $totalPages - 1): ?><span>…</span><?php endif; ?>
                    <a href="<?= e(books_page_url($totalPages)) ?>"><?= e($totalPages) ?></a>
                <?php endif; ?>

                <?php if ($page < $totalPages): ?>
                    <a href="<?= e(books_page_url($page + 1)) ?>">Sonraki ›</a>
                <?php endif; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>

<?php if (!$isAdmin): ?>
<script>
(function () {
    const flashWrap = document.getElementById('ajax-flash');

    function showFlash(message, type) {
        if (!flashWrap) return;
        flashWrap.innerHTML = '<div class="flash flash-' + type + '">' + message + '</div>';
        window.setTimeout(function () {
            const flash = flashWrap.querySelector('.flash');
            if (flash) {
                flash.style.transition = 'opacity .25s ease';
                flash.style.opacity = '0';
                window.setTimeout(function () {
                    flashWrap.innerHTML = '';
                }, 250);
            }
        }, 2200);
    }

    function buildCartLink(url) {
        const link = document.createElement('a');
        link.href = url;
        link.className = 'btn btn-cart-link action-pair-item';
        link.textContent = 'Sepete Git';
        return link;
    }

    document.querySelectorAll('.js-add-to-cart-form').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();

            const button = form.querySelector('.js-add-to-cart-button');
            const actionWrap = form.closest('.cart-action-group');

            if (button) {
                button.disabled = true;
                button.dataset.originalText = button.textContent;
                button.textContent = 'Ekleniyor...';
            }

            fetch(window.location.pathname + window.location.search, {
                method: 'POST',
                body: new FormData(form),
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
                .then(function (response) { return response.json(); })
                .then(function (data) {
                    if (data.success) {
                        showFlash(data.message || 'Kitap sepete eklendi.', 'success');

                        if (button) {
                            button.textContent = 'Sepette';
                            button.classList.add('btn-secondary');
                            button.disabled = true;
                        }

                        if (actionWrap && !actionWrap.querySelector('.btn-cart-link')) {
                            actionWrap.appendChild(buildCartLink(data.cart_url || 'cart.php'));
                        }
                    } else {
                        showFlash(data.message || 'İşlem başarısız.', 'error');
                        if (button) {
                            button.disabled = false;
                            button.textContent = button.dataset.originalText || 'Sepete Ekle';
                        }
                    }
                })
                .catch(function () {
                    showFlash('İşlem sırasında bir hata oluştu.', 'error');
                    if (button) {
                        button.disabled = false;
                        button.textContent = button.dataset.originalText || 'Sepete Ekle';
                    }
                });
        });
    });
})();
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/partials/footer.php'; ?>