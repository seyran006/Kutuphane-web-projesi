<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

function url(string $path = ''): string
{
    $prefix = BASE_URL !== '' ? BASE_URL : '';

    if ($path === '') {
        return $prefix !== '' ? $prefix : '/';
    }

    return $prefix . '/' . ltrim($path, '/');
}

function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

function display_flash(): string
{
    if (!isset($_SESSION['flash'])) {
        return '';
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);

    return '<div class="flash flash-' . e($flash['type']) . '">' . e($flash['message']) . '</div>';
}

function login_side_data(string $page = 'login'): array
{
    $loginSideContent = [
        'login' => [
            'badge' => APP_NAME,
            'title' => 'Kütüphane Yönetimi',
            'text' => 'Kitapları takip et, ödünç işlemlerini kolayca yönet ve hesabına hızlıca eriş.',
            'features' => [
                [
                    'title' => 'Hızlı erişim',
                    'text' => 'Giriş yaptıktan sonra panel, kitaplar ve hesap bölümlerine doğrudan ulaşabilirsin.',
                ],
                [
                    'title' => 'Kolay takip',
                    'text' => 'Ödünç alınan kitaplar, teslim tarihleri ve kişisel işlemler tek ekranda düzenli görünür.',
                ],
            ],
            'stats' => [
                ['value' => '7/24', 'label' => 'erişim'],
                ['value' => 'Güvenli', 'label' => 'oturum'],
                ['value' => 'Kolay', 'label' => 'kullanım'],
            ],
        ],
        'register' => [
            'badge' => APP_NAME,
            'title' => 'Üye Kaydı',
            'text' => 'Kütüphaneye hızlıca katıl, kitapları takip et ve hesabını güvenle yönet.',
            'features' => [
                [
                    'title' => 'Kolay kayıt',
                    'text' => 'Hızlı form ile üyeliğini hemen aktif edebilirsin.',
                ],
                [
                    'title' => 'Güvenli oturum',
                    'text' => 'Kişisel bilgilerin güvende tutulur ve hesap girişin korunur.',
                ],
            ],
            'stats' => [
                ['value' => '5 adım', 'label' => 'kayıt'],
                ['value' => 'Güvenli', 'label' => 'hesap'],
                ['value' => 'Hızlı', 'label' => 'başlangıç'],
            ],
        ],
    ];

    return $loginSideContent[$page] ?? $loginSideContent['login'];
}

function render_login_side(string $page = 'login'): string
{
    $loginSide = login_side_data($page);

    $html = '<div class="login-side">';
    $html .= '<div class="login-side-content">';
    $html .= '<div>'; 
    $html .= '<div class="login-badge">' . e($loginSide['badge']) . '</div>';
    $html .= '<h1 class="login-side-title">' . e($loginSide['title']) . '</h1>';
    $html .= '<p class="login-side-text">' . e($loginSide['text']) . '</p>';
    $html .= '</div>';

    $html .= '<div class="login-feature-grid">';
    foreach ($loginSide['features'] as $feature) {
        $html .= '<div class="login-feature-card">';
        $html .= '<strong>' . e($feature['title']) . '</strong>';
        $html .= '<span>' . e($feature['text']) . '</span>';
        $html .= '</div>';
    }
    $html .= '</div>';

    $html .= '<div class="login-stat-grid">';
    foreach ($loginSide['stats'] as $stat) {
        $html .= '<div class="login-stat-box">';
        $html .= '<div class="login-stat-value">' . e($stat['value']) . '</div>';
        $html .= '<div class="login-stat-label">' . e($stat['label']) . '</div>';
        $html .= '</div>';
    }
    $html .= '</div>';

    $html .= '</div>';
    $html .= '</div>';

    return $html;
}

function login_panel_data(string $page = 'login'): array
{
    $loginPanelContent = [
        'login' => [
            'title' => 'Giriş Yap',
            'text' => 'Site açıldıgında önce giriş ekrani gelir. Beni Hatırla seçeneği sayesinde tekrar giriş yapmanıza gerek kalmaz!',
            'form_action' => '',
            'fields' => [
                [
                    'name' => 'identity',
                    'label' => 'Kullanıcı adı veya e-posta',
                    'type' => 'text',
                    'required' => true,
                    'value' => $_POST['identity'] ?? '',
                ],
                [
                    'name' => 'password',
                    'label' => 'Şifre',
                    'type' => 'password',
                    'required' => true,
                ],
            ],
            'checkbox' => [
                'name' => 'remember',
                'label' => 'Beni hatırla (30 gün)',
                'checked' => true,
            ],
            'buttons' => [
                [
                    'type' => 'submit',
                    'text' => 'Giriş Yap',
                    'class' => '',
                ],
                [
                    'href' => url('register.php'),
                    'text' => 'Yeni Hesap Oluştur',
                    'class' => 'btn-secondary',
                ],
            ],
        ],
        'register' => [
            'title' => 'Kayıt Ol',
            'text' => 'Kütüphane sistemine üye hesabını oluştur.',
            'form_action' => '',
            'fields' => [
                [
                    'name' => 'full_name',
                    'label' => 'Ad Soyad',
                    'type' => 'text',
                    'required' => true,
                    'value' => $_POST['full_name'] ?? '',
                ],
                [
                    'name' => 'username',
                    'label' => 'Kullanıcı Adı',
                    'type' => 'text',
                    'required' => true,
                    'value' => $_POST['username'] ?? '',
                ],
                [
                    'name' => 'email',
                    'label' => 'E-posta',
                    'type' => 'email',
                    'required' => true,
                    'value' => $_POST['email'] ?? '',
                ],
                [
                    'name' => 'phone',
                    'label' => 'Telefon Numarası',
                    'type' => 'text',
                    'required' => true,
                    'placeholder' => 'Örn: 05051234567',
                    'value' => $_POST['phone'] ?? '',
                ],
                [
                    'name' => 'address',
                    'label' => 'Adres',
                    'type' => 'text',
                    'required' => true,
                    'placeholder' => 'Adresinizi girin',
                    'value' => $_POST['address'] ?? '',
                ],
                [
                    'name' => 'password',
                    'label' => 'Şifre',
                    'type' => 'password',
                    'required' => true,
                ],
                [
                    'name' => 'password_confirm',
                    'label' => 'Şifre Tekrar',
                    'type' => 'password',
                    'required' => true,
                ],
            ],
            'buttons' => [
                [
                    'type' => 'submit',
                    'text' => 'Hesap Oluştur',
                    'class' => '',
                ],
                [
                    'href' => url('login.php'),
                    'text' => 'Giriş Sayfasına Dön',
                    'class' => 'btn-secondary',
                ],
            ],
        ],
    ];

    return $loginPanelContent[$page] ?? $loginPanelContent['login'];
}

function render_login_panel(string $page = 'login', string $error = ''): string
{
    $panelData = login_panel_data($page);

    $html = '<div class="login-panel">';
    $html .= '<div class="login-panel-inner">';

    $html .= display_flash();

    $html .= '<h1>' . e($panelData['title']) . '</h1>';
    $html .= '<p class="muted">' . e($panelData['text']) . '</p>';

    if ($error !== '') {
        $html .= '<div class="flash flash-error">' . e($error) . '</div>';
    }

    $html .= '<form method="post" action="' . e($panelData['form_action']) . '">';

    // Handle different field layouts
    if ($page === 'register') {
        // Single fields
        foreach ($panelData['fields'] as $field) {
            if (in_array($field['name'], ['full_name', 'username', 'email'])) {
                $html .= '<div class="form-group">';
                $html .= '<label for="' . e($field['name']) . '">' . e($field['label']) . '</label>';
                $html .= '<input class="form-control" id="' . e($field['name']) . '" name="' . e($field['name']) . '" type="' . e($field['type']) . '"';
                if (isset($field['value'])) $html .= ' value="' . e($field['value']) . '"';
                if (isset($field['placeholder'])) $html .= ' placeholder="' . e($field['placeholder']) . '"';
                if ($field['required']) $html .= ' required';
                $html .= '>';
                $html .= '</div>';
            }
        }

        // Row fields
        $html .= '<div class="form-row">';
        foreach ($panelData['fields'] as $field) {
            if (in_array($field['name'], ['phone', 'address'])) {
                $html .= '<div class="form-group">';
                $html .= '<label for="' . e($field['name']) . '">' . e($field['label']) . '</label>';
                $html .= '<input class="form-control" id="' . e($field['name']) . '" name="' . e($field['name']) . '" type="' . e($field['type']) . '"';
                if (isset($field['value'])) $html .= ' value="' . e($field['value']) . '"';
                if (isset($field['placeholder'])) $html .= ' placeholder="' . e($field['placeholder']) . '"';
                if ($field['required']) $html .= ' required';
                $html .= '>';
                $html .= '</div>';
            }
        }
        $html .= '</div>';

        $html .= '<div class="form-row">';
        foreach ($panelData['fields'] as $field) {
            if (in_array($field['name'], ['password', 'password_confirm'])) {
                $html .= '<div class="form-group">';
                $html .= '<label for="' . e($field['name']) . '">' . e($field['label']) . '</label>';
                $html .= '<input class="form-control" id="' . e($field['name']) . '" name="' . e($field['name']) . '" type="' . e($field['type']) . '"';
                if ($field['required']) $html .= ' required';
                $html .= '>';
                $html .= '</div>';
            }
        }
        $html .= '</div>';
    } else {
        // Login fields
        foreach ($panelData['fields'] as $field) {
            $html .= '<div class="form-group">';
            $html .= '<label for="' . e($field['name']) . '">' . e($field['label']) . '</label>';
            $html .= '<input class="form-control" id="' . e($field['name']) . '" name="' . e($field['name']) . '" type="' . e($field['type']) . '"';
            if (isset($field['value'])) $html .= ' value="' . e($field['value']) . '"';
            if ($field['required']) $html .= ' required';
            $html .= '>';
            $html .= '</div>';
        }

        if (isset($panelData['checkbox'])) {
            $html .= '<label class="checkbox-line small">';
            $html .= '<input type="checkbox" name="' . e($panelData['checkbox']['name']) . '"';
            if ($panelData['checkbox']['checked']) $html .= ' checked';
            $html .= '>';
            $html .= e($panelData['checkbox']['label']);
            $html .= '</label>';
        }
    }

    $html .= '<div class="form-actions">';
    foreach ($panelData['buttons'] as $button) {
        if (isset($button['type']) && $button['type'] === 'submit') {
            $html .= '<button type="submit"';
            if ($button['class'] !== '') $html .= ' class="' . e($button['class']) . '"';
            $html .= '>' . e($button['text']) . '</button>';
        } else {
            $html .= '<a class="btn';
            if ($button['class'] !== '') $html .= ' ' . e($button['class']);
            $html .= '" href="' . e($button['href']) . '">' . e($button['text']) . '</a>';
        }
    }
    $html .= '</div>';

    $html .= '</form>';

    $html .= '</div>';
    $html .= '</div>';

    return $html;
}

function format_money(float|int|string $amount): string
{
    return number_format((float) $amount, 2, ',', '.') . ' TL';
}

function app_asset_version(): string
{
    return defined('ASSET_VERSION') ? (string) ASSET_VERSION : (string) time();
}

function save_book_cover_upload(array $file, string &$error): ?string
{
    $uploadError = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);

    if ($uploadError === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($uploadError !== UPLOAD_ERR_OK) {
        $error = 'Kapak görseli yüklenemedi. Lütfen daha küçük veya farklı bir görsel deneyin.';
        return null;
    }

    $tmpName = (string) ($file['tmp_name'] ?? '');
    $fileSize = (int) ($file['size'] ?? 0);
    $maxUploadBytes = defined('MAX_UPLOAD_BYTES') ? (int) MAX_UPLOAD_BYTES : (5 * 1024 * 1024);

    if ($tmpName === '' || !is_uploaded_file($tmpName)) {
        $error = 'Yüklenen görsel doğrulanamadı.';
        return null;
    }

    if ($fileSize <= 0 || $fileSize > $maxUploadBytes) {
        $error = 'Kapak görseli en fazla ' . number_format($maxUploadBytes / 1024 / 1024, 0, ',', '.') . ' MB olabilir.';
        return null;
    }

    $detectedMime = '';
    if (function_exists('mime_content_type')) {
        $detectedMime = (string) mime_content_type($tmpName);
    }

    if ($detectedMime === '') {
        $imageInfo = @getimagesize($tmpName);
        $detectedMime = is_array($imageInfo) ? (string) ($imageInfo['mime'] ?? '') : '';
    }

    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];

    if (!isset($allowedMimeTypes[$detectedMime])) {
        $error = 'Sadece jpg, jpeg, png, webp ve gif kapak görselleri yüklenebilir.';
        return null;
    }

    $uploadDir = __DIR__ . '/assets/uploads';

    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
        $error = 'Yükleme klasörü oluşturulamadı.';
        return null;
    }

    $fileName = uniqid('book_', true) . '.' . $allowedMimeTypes[$detectedMime];
    $targetPath = $uploadDir . '/' . $fileName;

    if (!move_uploaded_file($tmpName, $targetPath)) {
        $error = 'Kapak görseli kaydedilemedi.';
        return null;
    }

    @chmod($targetPath, 0644);

    return 'assets/uploads/' . $fileName;
}


function overdue_daily_penalty_amount(): float
{
    if (!defined('OVERDUE_DAILY_PENALTY')) {
        define('OVERDUE_DAILY_PENALTY', 5.00);
    }

    return round((float) OVERDUE_DAILY_PENALTY, 2);
}

// Eski dosyalardan çağrı kalırsa uyumlu çalışsın.
function overdue_penalty_daily_amount(float|int|string $monthlyPrice = 0): float
{
    return overdue_daily_penalty_amount();
}

function overdue_penalty_cap(float|int|string $monthlyPrice = 0): float
{
    return 999999999.00;
}

function overdue_penalty_rule_text(): string
{
    return 'Teslim tarihi geçen her aktif kitap için günlük ' . format_money(overdue_daily_penalty_amount())
        . ' gecikme cezası bakiyeden düşer. Aynı kitap için aynı gün ikinci kez ceza kesilmez.';
}

function overdue_days_between(string $fromDate, string $toDate): int
{
    $from = DateTimeImmutable::createFromFormat('!Y-m-d', $fromDate);
    $to = DateTimeImmutable::createFromFormat('!Y-m-d', $toDate);

    if (!$from || !$to || $to <= $from) {
        return 0;
    }

    return (int) $from->diff($to)->days;
}

function overdue_days_until_today(string $dueDate, ?string $today = null): int
{
    return overdue_days_between($dueDate, $today ?: date('Y-m-d'));
}

function ensure_overdue_penalty_schema(): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $checked = true;

    $columnStmt = db()->prepare(
        'SELECT COLUMN_NAME
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = :table_name
           AND COLUMN_NAME IN ("overdue_penalty_total", "penalty_last_charged_date")'
    );
    $columnStmt->execute(['table_name' => 'borrows']);
    $existingColumns = array_flip(array_column($columnStmt->fetchAll(), 'COLUMN_NAME'));

    if (!isset($existingColumns['overdue_penalty_total'])) {
        db()->exec('ALTER TABLE borrows ADD COLUMN overdue_penalty_total DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER rental_price');
    }

    if (!isset($existingColumns['penalty_last_charged_date'])) {
        db()->exec('ALTER TABLE borrows ADD COLUMN penalty_last_charged_date DATE DEFAULT NULL AFTER overdue_penalty_total');
    }

    $indexStmt = db()->prepare(
        'SELECT INDEX_NAME
         FROM INFORMATION_SCHEMA.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = :table_name
           AND INDEX_NAME = :index_name
         LIMIT 1'
    );
    $indexStmt->execute([
        'table_name' => 'borrows',
        'index_name' => 'idx_borrows_overdue_penalty',
    ]);

    if (!$indexStmt->fetchColumn()) {
        db()->exec('ALTER TABLE borrows ADD INDEX idx_borrows_overdue_penalty (status, due_date, penalty_last_charged_date)');
    }
}

function calculate_overdue_penalty_amount(string $dueDate, ?string $lastChargedDate, ?string $chargeThroughDate = null): array
{
    $chargeThroughDate = $chargeThroughDate ?: date('Y-m-d');
    $startDate = $lastChargedDate ?: $dueDate;

    if ($startDate < $dueDate) {
        $startDate = $dueDate;
    }

    $daysToCharge = overdue_days_between($startDate, $chargeThroughDate);
    $dailyAmount = overdue_daily_penalty_amount();
    $chargeAmount = round($daysToCharge * $dailyAmount, 2);

    return [
        'days_to_charge' => $daysToCharge,
        'daily_amount' => $dailyAmount,
        'charge_amount' => $chargeAmount,
        'charge_through_date' => $chargeThroughDate,
    ];
}

function apply_overdue_penalties_for_user(int $userId, ?string $chargeThroughDate = null): array
{
    ensure_overdue_penalty_schema();

    $chargeThroughDate = $chargeThroughDate ?: date('Y-m-d');
    $result = [
        'charged_amount' => 0.0,
        'charged_loans' => 0,
        'charged_days' => 0,
        'details' => [],
    ];

    if ($userId <= 0) {
        return $result;
    }

    db()->beginTransaction();

    try {
        $userStmt = db()->prepare('SELECT id, role FROM users WHERE id = :id LIMIT 1 FOR UPDATE');
        $userStmt->execute(['id' => $userId]);
        $user = $userStmt->fetch();

        if (!$user || ($user['role'] ?? '') === 'admin') {
            db()->commit();
            return $result;
        }

        $loanStmt = db()->prepare(
            'SELECT
                br.id,
                br.due_date,
                br.overdue_penalty_total,
                br.penalty_last_charged_date,
                b.title
             FROM borrows br
             INNER JOIN books b ON b.id = br.book_id
             WHERE br.user_id = :user_id
               AND br.status = "borrowed"
               AND br.due_date < :charge_through_date
             ORDER BY br.due_date ASC, br.id ASC
             FOR UPDATE'
        );
        $loanStmt->execute([
            'user_id' => $userId,
            'charge_through_date' => $chargeThroughDate,
        ]);
        $loans = $loanStmt->fetchAll();

        $updateLoanStmt = db()->prepare(
            'UPDATE borrows
             SET overdue_penalty_total = overdue_penalty_total + :charge_amount,
                 penalty_last_charged_date = :charge_through_date
             WHERE id = :id'
        );

        foreach ($loans as $loan) {
            $calculation = calculate_overdue_penalty_amount(
                (string) $loan['due_date'],
                $loan['penalty_last_charged_date'] !== null ? (string) $loan['penalty_last_charged_date'] : null,
                $chargeThroughDate
            );

            if ((int) $calculation['days_to_charge'] <= 0) {
                continue;
            }

            $chargeAmount = (float) $calculation['charge_amount'];

            $updateLoanStmt->execute([
                'charge_amount' => $chargeAmount,
                'charge_through_date' => $chargeThroughDate,
                'id' => (int) $loan['id'],
            ]);

            if ($chargeAmount > 0) {
                $result['charged_amount'] = round((float) $result['charged_amount'] + $chargeAmount, 2);
                $result['charged_loans']++;
                $result['charged_days'] += (int) $calculation['days_to_charge'];
                $result['details'][] = [
                    'borrow_id' => (int) $loan['id'],
                    'title' => (string) $loan['title'],
                    'days' => (int) $calculation['days_to_charge'],
                    'daily_amount' => (float) $calculation['daily_amount'],
                    'amount' => $chargeAmount,
                ];
            }
        }

        if ((float) $result['charged_amount'] > 0) {
            $balanceStmt = db()->prepare('UPDATE users SET balance = balance - :amount WHERE id = :id');
            $balanceStmt->execute([
                'amount' => (float) $result['charged_amount'],
                'id' => $userId,
            ]);
        }

        db()->commit();
    } catch (Throwable $exception) {
        if (db()->inTransaction()) {
            db()->rollBack();
        }

        throw $exception;
    }

    return $result;
}

function apply_overdue_penalties_for_current_user(): array
{
    static $applied = [];

    $user = current_user();

    if (!$user || ($user['role'] ?? '') === 'admin') {
        return [
            'charged_amount' => 0.0,
            'charged_loans' => 0,
            'charged_days' => 0,
            'details' => [],
        ];
    }

    $key = (int) $user['id'] . ':' . date('Y-m-d');

    if (isset($applied[$key])) {
        return $applied[$key];
    }

    $applied[$key] = apply_overdue_penalties_for_user((int) $user['id']);

    if ((float) $applied[$key]['charged_amount'] > 0) {
        current_user(true);
    }

    return $applied[$key];
}

function apply_overdue_penalties_for_all_members(?string $chargeThroughDate = null): array
{
    static $applied = [];

    $chargeThroughDate = $chargeThroughDate ?: date('Y-m-d');

    if (isset($applied[$chargeThroughDate])) {
        return $applied[$chargeThroughDate];
    }

    ensure_overdue_penalty_schema();

    $memberStmt = db()->query('SELECT id FROM users WHERE role = "member" ORDER BY id ASC');
    $memberIds = array_map('intval', array_column($memberStmt->fetchAll(), 'id'));
    $summary = [
        'charged_amount' => 0.0,
        'charged_users' => 0,
        'charged_loans' => 0,
        'charged_days' => 0,
    ];

    foreach ($memberIds as $memberId) {
        $result = apply_overdue_penalties_for_user($memberId, $chargeThroughDate);

        if ((float) $result['charged_amount'] > 0) {
            $summary['charged_amount'] = round((float) $summary['charged_amount'] + (float) $result['charged_amount'], 2);
            $summary['charged_users']++;
            $summary['charged_loans'] += (int) $result['charged_loans'];
            $summary['charged_days'] += (int) $result['charged_days'];
        }
    }

    $applied[$chargeThroughDate] = $summary;

    return $summary;
}

function user_overdue_penalty_summary(int $userId): array
{
    ensure_overdue_penalty_schema();

    $stmt = db()->prepare(
        'SELECT
            COUNT(CASE WHEN status = "borrowed" AND due_date < CURDATE() THEN 1 END) AS active_overdue_count,
            COALESCE(SUM(CASE WHEN status = "borrowed" AND due_date < CURDATE() THEN DATEDIFF(CURDATE(), due_date) ELSE 0 END), 0) AS active_overdue_days,
            COALESCE(SUM(overdue_penalty_total), 0) AS total_penalty,
            COALESCE(SUM(CASE WHEN status = "borrowed" THEN overdue_penalty_total ELSE 0 END), 0) AS active_penalty
         FROM borrows
         WHERE user_id = :user_id'
    );
    $stmt->execute(['user_id' => $userId]);
    $summary = $stmt->fetch() ?: [];

    return [
        'active_overdue_count' => (int) ($summary['active_overdue_count'] ?? 0),
        'active_overdue_days' => (int) ($summary['active_overdue_days'] ?? 0),
        'total_penalty' => round((float) ($summary['total_penalty'] ?? 0), 2),
        'active_penalty' => round((float) ($summary['active_penalty'] ?? 0), 2),
    ];
}

function active_overdue_loans_for_user(int $userId, int $limit = 10): array
{
    ensure_overdue_penalty_schema();

    $limit = max(1, min(50, $limit));
    $stmt = db()->prepare(
        'SELECT
            br.id,
            br.due_date,
            br.rental_price,
            br.overdue_penalty_total,
            br.penalty_last_charged_date,
            DATEDIFF(CURDATE(), br.due_date) AS overdue_days,
            b.title,
            b.isbn
         FROM borrows br
         INNER JOIN books b ON b.id = br.book_id
         WHERE br.user_id = :user_id
           AND br.status = "borrowed"
           AND br.due_date < CURDATE()
         ORDER BY br.due_date ASC, br.id ASC
         LIMIT ' . $limit
    );
    $stmt->execute(['user_id' => $userId]);

    return $stmt->fetchAll();
}

function recent_user_penalty_loans(int $userId, int $limit = 5): array
{
    ensure_overdue_penalty_schema();

    $limit = max(1, min(20, $limit));
    $stmt = db()->prepare(
        'SELECT
            br.id,
            br.due_date,
            br.returned_at,
            br.status,
            br.overdue_penalty_total,
            br.penalty_last_charged_date,
            b.title
         FROM borrows br
         INNER JOIN books b ON b.id = br.book_id
         WHERE br.user_id = :user_id
           AND br.overdue_penalty_total > 0
         ORDER BY br.penalty_last_charged_date DESC, br.id DESC
         LIMIT ' . $limit
    );
    $stmt->execute(['user_id' => $userId]);

    return $stmt->fetchAll();
}

function login_session(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['user_role'] = $user['role'];
}

function remember_user(int $userId): void
{
    $token = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $token);
    $expiresTimestamp = time() + (REMEMBER_COOKIE_DAYS * 86400);
    $expiresAt = date('Y-m-d H:i:s', $expiresTimestamp);

    $stmt = db()->prepare('UPDATE users SET remember_token_hash = :token_hash, remember_token_expires_at = :expires_at WHERE id = :id');
    $stmt->execute([
        'token_hash' => $tokenHash,
        'expires_at' => $expiresAt,
        'id' => $userId,
    ]);

    setcookie(
        REMEMBER_COOKIE_NAME,
        $token,
        [
            'expires' => $expiresTimestamp,
            'path' => '/',
            'httponly' => true,
            'secure' => false,
            'samesite' => 'Lax',
        ]
    );
}

function clear_remember_cookie(): void
{
    setcookie(
        REMEMBER_COOKIE_NAME,
        '',
        [
            'expires' => time() - 3600,
            'path' => '/',
            'httponly' => true,
            'secure' => false,
            'samesite' => 'Lax',
        ]
    );
}

function current_user(bool $forceRefresh = false): ?array
{
    static $cachedUser = null;
    static $checked = false;

    if ($forceRefresh) {
        $cachedUser = null;
        $checked = false;
    }

    if ($checked) {
        return $cachedUser;
    }

    $checked = true;

    if (isset($_SESSION['user_id'])) {
        $stmt = db()->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => (int) $_SESSION['user_id']]);
        $cachedUser = $stmt->fetch() ?: null;

        if ($cachedUser !== null) {
            return $cachedUser;
        }

        unset($_SESSION['user_id'], $_SESSION['user_role']);
    }

    if (!empty($_COOKIE[REMEMBER_COOKIE_NAME])) {
        $token = $_COOKIE[REMEMBER_COOKIE_NAME];

        if (preg_match('/^[a-f0-9]{64}$/', $token) === 1) {
            $stmt = db()->prepare('SELECT * FROM users WHERE remember_token_hash = :token_hash AND remember_token_expires_at > NOW() LIMIT 1');
            $stmt->execute([
                'token_hash' => hash('sha256', $token),
            ]);

            $user = $stmt->fetch();

            if ($user) {
                login_session($user);
                $cachedUser = $user;

                return $cachedUser;
            }
        }

        clear_remember_cookie();
    }

    return null;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function require_login(): void
{
    if (!is_logged_in()) {
        set_flash('error', 'Devam etmek için giriş yapın.');
        redirect('login.php');
    }

    apply_overdue_penalties_for_current_user();
}

function require_admin(): void
{
    require_login();

    $user = current_user();

    if (!$user || $user['role'] !== 'admin') {
        set_flash('error', 'Bu sayfaya sadece admin erişebilir.');
        redirect('dashboard.php');
    }
}

function attempt_login(string $identity, string $password, bool $remember = true): bool
{
    $stmt = db()->prepare('SELECT * FROM users WHERE username = :identity OR email = :identity LIMIT 1');
    $stmt->execute(['identity' => $identity]);
    $user = $stmt->fetch();

    if (!$user) {
        return false;
    }

    if (!password_verify($password, $user['password_hash'])) {
        return false;
    }

    login_session($user);

    if ($remember) {
        remember_user((int) $user['id']);
    }

    return true;
}

function logout_user(): void
{
    $user = current_user();

    if ($user) {
        $stmt = db()->prepare('UPDATE users SET remember_token_hash = NULL, remember_token_expires_at = NULL WHERE id = :id');
        $stmt->execute(['id' => (int) $user['id']]);
    }

    $_SESSION = [];

    if (session_id() !== '' || isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 42000, '/');
    }

    clear_remember_cookie();
    session_destroy();
}

function count_row(string $sql, array $params = []): int
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);

    return (int) $stmt->fetchColumn();
}

function current_cart_count(int $userId): int
{
    return count_row('SELECT COUNT(*) FROM cart_items WHERE user_id = :user_id', ['user_id' => $userId]);
}
