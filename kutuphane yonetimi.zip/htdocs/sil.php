<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    set_flash('error', 'Geçersiz istek.');
    redirect('books.php');
}

$bookId = (int) ($_POST['book_id'] ?? 0);

if ($bookId <= 0) {
    set_flash('error', 'Geçersiz kitap seçimi.');
    redirect('books.php');
}

try {
    $stmt = db()->prepare('SELECT id, title FROM books WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $bookId]);
    $book = $stmt->fetch();

    if (!$book) {
        throw new RuntimeException('Kitap bulunamadı.');
    }

    $activeLoanCount = count_row(
        'SELECT COUNT(*) FROM borrows WHERE book_id = :book_id AND status = :status',
        ['book_id' => $bookId, 'status' => 'borrowed']
    );

    if ($activeLoanCount > 0) {
        throw new RuntimeException('Bu kitap şu an ödünçte olduğu için silinemez. Önce iade işlemleri tamamlanmalı.');
    }

    $deleteStmt = db()->prepare('DELETE FROM books WHERE id = :id');
    $deleteStmt->execute(['id' => $bookId]);

    set_flash('success', (string) $book['title'] . ' kitabı silindi.');
} catch (Throwable $exception) {
    set_flash('error', 'Kitap silinemedi: ' . $exception->getMessage());
}

redirect('books.php');
